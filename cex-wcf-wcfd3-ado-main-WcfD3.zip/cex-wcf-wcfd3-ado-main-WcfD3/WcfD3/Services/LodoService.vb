﻿Imports System.Collections.Generic
Imports System.Configuration
Imports System.Diagnostics
Imports System.Security.Principal
Imports System.ServiceModel
Imports System.Threading.Tasks

Imports Arvest.Authentication
Imports Arvest.Authentication.DataAccess.S1
Imports Arvest.Authentication.DataContracts.Responses

Imports Arvest.Common
Imports Arvest.Common.WCF

Imports Arvest.ServiceReferences.AA
Imports Arvest.ServiceReferences.Axm

Imports Arvest.WCF.D3.DataContract.Lodo

Imports AxmLockedUserException = Arvest.ServiceReferences.Axm.LockedUserException
Imports AxmUserNotFoundException = Arvest.ServiceReferences.Axm.UserNotFoundException
Imports AxmInvalidPasswordException = Arvest.ServiceReferences.Axm.InvalidPasswordException
Imports System.Text.RegularExpressions

<ServiceBehavior(Namespace:="http://arvest.com/", ConcurrencyMode:=ConcurrencyMode.Multiple)>
Public Class LodoService
    Implements ILodoContract

    Private Shared log As New ArvestTraceSource(GetType(LodoService))

    Private Shared systemPassword As String = ConfigurationManager.AppSettings("systemPassword")

    Private Shared wcfCsrId As String = WindowsIdentity.GetCurrent().Name.ToString()

    Public Sub New()
        Trace.CorrelationManager.ActivityId = Guid.NewGuid
    End Sub

    Public Function IsServerAlive() As Boolean Implements IWCFContract.IsServerAlive
        Return True
    End Function

    Public Function AuthenticateUser(ByVal request As AuthenticateUserRequest) As LodoResponse Implements ILodoContract.AuthenticateUser
        Return AuthenticateSystem(request, Function() AuthenticateUser(request.UserName, request.Password))
    End Function

    Private Shared Function AuthenticateUser(userName As String, password As String) As LodoResponse
        If String.IsNullOrEmpty(userName) Then
            Return LodoResponseFactory.UserDoesntExist
        End If

        If String.IsNullOrEmpty(password) Then
            Return LodoResponseFactory.InvalidPassword
        End If

        Try
            Authenticator.AuthenticateUser(userName, password)

            Return LodoResponseFactory.Create()
        Catch ex As AxmUserNotFoundException
            Return LodoResponseFactory.UserDoesntExist
        Catch ex As AxmInvalidPasswordException
            Return LodoResponseFactory.InvalidPassword
        Catch ex As ExpiredPasswordException
            Return LodoResponseFactory.ExpiredPassword
        Catch ex As ExpiredAccountException
            Return LodoResponseFactory.ExpiredAccount
        Catch ex As AxmLockedUserException
            Return LodoResponseFactory.LockedUser
        End Try
    End Function

    Public Function AuthenticateUserRsa(ByVal request As AuthenticateUserRsaRequest) As AuthenticateUserRsaResponse Implements ILodoContract.AuthenticateUserRsa
        Return AuthenticateSystem(request, Function() AuthenticateUserRsa(request.UserId))
    End Function

    Friend Shared Function AuthenticateUserRsa(userid As String) As AuthenticateUserRsaResponse
        If String.IsNullOrEmpty(userid) Then
            Return LodoResponseFactory(Of AuthenticateUserRsaResponse).UserDoesntExist
        End If

        Dim user As VerifyUserResponse = Authenticator.VerifyUser(userid)

        If user Is Nothing Then
            Return LodoResponseFactory(Of AuthenticateUserRsaResponse).UserDoesntExist
        End If

        Return New AuthenticateUserRsaResponse With
               {
                   .DirectId = user.MapId.ToString,
                   .RsaId = user.AdaptiveAuthId
               }
    End Function

    Public Function LockUser(request As LockUserRequest) As LodoResponse Implements ILodoContract.LockUser
        Return AuthenticateSystem(request,
                                  Sub(axmClient As AxMAdminWSClient, aaClient As AdaptiveAuthenticationInterfaceClient)
                                      LockUser(axmClient, aaClient, request.UserId)
                                  End Sub)
    End Function

    Public Function UnLockUser(request As LockUserRequest) As LodoResponse Implements ILodoContract.UnlockUser
        Return AuthenticateSystem(request,
                                  Sub(axmClient As AxMAdminWSClient, aaClient As AdaptiveAuthenticationInterfaceClient)
                                      UnlockUser(axmClient, aaClient, request.UserId)
                                  End Sub)
    End Function

    Private Shared Sub LockUser(axmClient As AxMAdminWSClient, aaClient As AdaptiveAuthenticationInterfaceClient, userId As String)
        Parallel.Invoke(Sub() axmClient.LockUser(userId),
                        Sub()
                            Try
                                aaClient.LockUser(CreateRequest(axmClient, userId))
                            Catch ex As NotEnrolledException
                                'Ignore if the user doesn't exist in AA yet.
                            End Try
                        End Sub)
    End Sub

    Private Shared Sub UnlockUser(axmClient As AxMAdminWSClient, aaClient As AdaptiveAuthenticationInterfaceClient, userId As String)
        Parallel.Invoke(Sub() axmClient.UnlockUser(userId),
                        Sub()
                            Try
                                aaClient.UnlockUser(CreateRequest(axmClient, userId))
                            Catch ex As NotEnrolledException
                                'Ignore if the user doesn't exist in AA yet.
                            End Try
                        End Sub)
    End Sub

    Private Shared Function CreateRequest(axmClient As AxMAdminWSClient, userId As String) As AARequest
        Return New AARequest With
                            {
                                .AdaptiveAuthId = axmClient.GetRsaId(userId),
                                .UserLogOnName = userId
                            }
    End Function

    Private Shared Sub UseAxMAndAAClients(axmClient As AxMAdminWSClient, aaClient As AdaptiveAuthenticationInterfaceClient,
                                          action As Action(Of AxMAdminWSClient, AdaptiveAuthenticationInterfaceClient))
        UseAxMAndAAClients(axmClient, aaClient, {axmClient, aaClient}, action)
    End Sub

    Private Shared Sub UseAxMAndAAClients(axmClient As AxMAdminWSClient, aaClient As AdaptiveAuthenticationInterfaceClient,
                                          clients() As ICommunicationObject, action As Action(Of AxMAdminWSClient, AdaptiveAuthenticationInterfaceClient))
        clients.UseClients(Sub() action(axmClient, aaClient))
    End Sub

    Public Function IsLocked(request As LockUserRequest) As IsLockedResponse Implements ILodoContract.IsLocked
        Dim user As VerifyUserResponse = Authenticator.VerifyUser(request.UserId)

        Return AuthenticateSystem(request,
                                  Function() As IsLockedResponse
                                      Try
                                          Return New IsLockedResponse With
                                                 {
                                                     .IsLocked = (AxMAdminWSClient.Use(Function(client) client.IsLocked(request.UserId))) _
                                                                 OrElse
                                                                 (AxMAdminWSClient.Use(Function(client) client.IsAdminLocked(request.UserId))) _
                                                                 OrElse
                                                                 (AxMAdminWSClient.Use(Function(client) client.IsInD3Group(request.UserId)) <> True) _
                                                                 OrElse
                                                                 (AxMAdminWSClient.Use(Function(client) client.IsInGroup(request.UserId, "NO-D3"))) _
                                                                 OrElse
                                                                 (AxMAdminWSClient.Use(Function(client) client.isAccountExpired(request.UserId))) _
                                                                 OrElse
                                                                 (AdaptiveAuthenticationInterfaceClient.Use(Function(aaClient) aaClient.IsLocked(New AARequest() With {.AdaptiveAuthId = user.AdaptiveAuthId})))
                                                   }



                                      Catch ex As AxmUserNotFoundException
                                          Return LodoResponseFactory(Of IsLockedResponse).UserDoesntExist
                                      End Try
                                  End Function)
    End Function

    Public Function ChangePassword(request As Credentials) As LodoResponse Implements ILodoContract.ChangePassword
        ChangePassword = AuthenticateSystem(request,
                                            Function() As LodoResponse
                                                If String.IsNullOrEmpty(request.UserName) Then
                                                    Return LodoResponseFactory.UserDoesntExist
                                                End If

                                                If String.IsNullOrEmpty(request.Password) Then
                                                    Return LodoResponseFactory.InvalidPassword
                                                End If
                                                '-------------
                                                'Must NOT contain &*()<>^ or space
                                                Dim badchar_regex As String = ("^*[\s&*()<>^]")
                                                If Regex.Match(request.Password, badchar_regex).Success Then
                                                    Return LodoResponseFactory.InvalidPassword
                                                End If
                                                ' Must contain at least one number.
                                                Dim isnum_regex As String = ("[0-9]+")
                                                If Not Regex.Match(request.Password, isnum_regex).Success Then
                                                    Return LodoResponseFactory.InvalidPassword
                                                End If
                                                'Must be at least 8 characters long
                                                If request.Password.Length <= 7 Then
                                                    Return LodoResponseFactory.InvalidPassword
                                                End If
                                                'Max of 64 characters long
                                                If request.Password.Length >= 37 Then
                                                    Return LodoResponseFactory.InvalidPassword
                                                End If

                                                '-------------
                                                'If Regex.Match(request.Password, _regex).Success Then
                                                '   "([a-zA-Z0-9\~\!\@\#\$\%\-\=\_\+\?\\\/\`\;\:""''\,\.][^\s&*()<>\^]{7,31})").Success Then
                                                '    Return LodoResponseFactory.InvalidPassword
                                                'End If

                                                Try
                                                    AxMAdminWSClient.Use(Sub(client) client.SetPassword(request.UserName, request.Password))
                                                Catch ex As ArgumentException When ex.ParamName = "password"
                                                    Return LodoResponseFactory.IllegalPassword(ex.Message)
                                                Catch ex As AxmUserNotFoundException
                                                    Return LodoResponseFactory.UserDoesntExist
                                                End Try

                                                Return LodoResponseFactory.Create
                                            End Function)

        Dim success As Boolean = ChangePassword.Success

        LogAction(D3Action.AOB_Password_Reset,
                  request.UserName,
                  If(success OrElse Not IsErrorUserDoesntExist(ChangePassword.Err), request.UserName, Nothing),
                  {"AxmPassword"},
                  {New String("*"c, If(request.Password Is Nothing, 0, request.Password.Length))},
                  success,
                  request.ClientIp,
                  ChangePassword.Err)

        Return ChangePassword
    End Function

    Private Shared Function AuthenticateSystem(request As SystemAuth, action As Action(Of AxMAdminWSClient, AdaptiveAuthenticationInterfaceClient)) As LodoResponse
        Return AuthenticateSystem(request, Function() As LodoResponse
                                               Try
                                                   UseAxMAndAAClients(AxMAdminWSClient.GetClient, AdaptiveAuthenticationInterfaceClient.GetClient, action)
                                               Catch ex As AggregateException When TypeOf ex.InnerException Is AxmUserNotFoundException
                                                   Return LodoResponseFactory.UserDoesntExist
                                               End Try

                                               Return LodoResponseFactory.Create()
                                           End Function)
    End Function

    Public Function ChangeUserId(request As ChangeUserIdRequest) As LodoResponse Implements ILodoContract.ChangeUserId
        ChangeUserId = AuthenticateSystem(request, Function() ChangeUserId(request.UserId, request.NewUserId))

        Dim success As Boolean = ChangeUserId.Success

        LogAction(D3Action.AOB_Login_ID_Changed,
                  request.UserId,
                  If(success, request.NewUserId, If(IsErrorUserDoesntExist(ChangeUserId.Err), Nothing, request.UserId)),
                  {"AxmLogin"},
                  {request.NewUserId},
                  success,
                  request.ClientIp,
                  ChangeUserId.Err)

        Return ChangeUserId
    End Function

    Private Shared Function ChangeUserId(userId As String, newUserId As String) As LodoResponse
        If String.IsNullOrEmpty(userId) Then
            Return LodoResponseFactory.UserDoesntExist
        End If

        Dim mapId As Long = AxMAdminWSClient.Use(Function(client As AxMAdminWSClient) As Long
                                                     Return client.GetMapId(userId)
                                                 End Function)

        If Not mapId > 0 Then
            Return LodoResponseFactory.UserDoesntExist
        End If

        If String.IsNullOrEmpty(newUserId) OrElse Authenticator.UserIdExists(mapId.ToString(), userId, newUserId) Then
            Return LodoResponseFactory.DuplicateUserId
        End If

        Try
            AxMAdminWSClient.Use(Sub(client As AxMAdminWSClient) client.SetUserId(userId, newUserId))

            Return New LodoResponse
        Catch ex As AxmUserNotFoundException
            Return LodoResponseFactory.UserDoesntExist
        Catch ex As DuplicateObjectException
            Return LodoResponseFactory.DuplicateUserId
        End Try
    End Function

    Private Shared Function IsErrorUserDoesntExist([error] As LodoError) As Boolean
        Return [error].Code = LodoResponseFactory.UserDoesntExist.Err.Code
    End Function

    Private Shared Function AuthenticateSystem(Of TResult As {New, LodoResponse})(request As SystemAuth, func As Func(Of TResult)) As TResult
        ThrowIfNull(request, "request")

        If Not systemPassword = request.SystemPassword Then
            Return LodoResponseFactory(Of TResult).InvalidSysPassword
        End If

        Try
            Return func()
        Catch ex As Exception
            If ex.CanTrace Then
                log.TraceError(ex.GetStackTraces)
            End If

            Return LodoResponseFactory(Of TResult).Create(ex)
        End Try
    End Function

    Private Shared Function GetMapId(logonId As String) As Long
        If logonId Is Nothing Then
            Return 0
        End If

        Try
            Return AxMAdminWSClient.GetMapIdUsed(logonId)
        Catch ex As AxmUserNotFoundException
            'Ignore
        Catch ex As Exception
            ex.Data.Add("logonId", logonId)

            log.TraceError(ex.GetStackTraces)
        End Try

        Return 0
    End Function

    Private Shared Sub LogAction(action As D3Action, logonId As String, axmId As String, properties As IEnumerable(Of String),
                                 propertyValues As IEnumerable(Of String), success As Boolean, clientIp As String, err As LodoError)

        Dim messageCode As String = Nothing
        Dim message As String = Nothing

        If Not success Then
            messageCode = err.Code.ToString
            message = err.Message
        End If

        D3Admin.LogAction(action, wcfCsrId, logonId, GetMapId(axmId).ToString, properties, propertyValues, success, clientIp, messageCode, message, Nothing)
    End Sub
End Class
