﻿Imports System.Configuration
Imports Arvest.Common.DataAccess.DB2i
Imports Arvest.Common.WCF
Imports Arvest.WCF.D3.DataAccess
Imports Arvest.WCF.D3.DataContract

Public Class ArvestGoService
    Implements IArvestGoService

    Private Shared hostTimeout As TimeSpan = TimeSpan.FromSeconds(Integer.Parse(ConfigurationManager.AppSettings("hostTimeout")))

    Private Shared connSwitch As New ConnectionSwitch(New ConnectionInfo With {.ConnectionStringSettings = ConfigurationManager.ConnectionStrings("AS400"),
                                                                               .Schema = "ABOLIB"},
                                                      New ConnectionInfo With {.ConnectionStringSettings = ConfigurationManager.ConnectionStrings("AS400ATM"),
                                                                               .Schema = "ABOSERVICE"},
                                                      TimeSpan.FromSeconds(Integer.Parse(ConfigurationManager.AppSettings("connectionSwitchInterval"))))

    Public Function GetCheckDepositLimit(request As ArvestGoRequest) As GetCheckDepositLimitResponse _
        Implements IArvestGoService.GetCheckDepositLimit

        Dim hostResp As CheckDepositLimitResponse = As400Client.GetMobileDepositLimits(request.UserId)

        Return New GetCheckDepositLimitResponse With {.Error = New ArvestGoError With {.ErrorCode = hostResp.Code,
                                                                                       .ErrorMessage = hostResp.Message},
                                                      .LimitLastBusinessDay = hostResp.Limit1,
                                                      .LimitLast30Days = hostResp.Limit30,
                                                      .UsageLastBusinessDay = hostResp.Usage1,
                                                      .UsageLast30Days = hostResp.Usage30}
    End Function

    Public Function IsServerAlive() As Boolean _
        Implements IWCFContract.IsServerAlive

        Return True
    End Function
End Class
