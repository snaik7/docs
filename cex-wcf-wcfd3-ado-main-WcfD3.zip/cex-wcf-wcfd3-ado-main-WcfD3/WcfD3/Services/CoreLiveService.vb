﻿Imports System.ServiceModel
Imports System.Diagnostics

Imports Arvest.Common
Imports Arvest.Common.WCF

Imports Arvest.WCF.D3.DataAccess
Imports Arvest.WCF.D3.DataContract.CoreLive
Imports Arvest.WCF.D3.Domain

Imports Arvest.WCF.D3.DataAccess.Daos.Wrappers
Imports System.Configuration
Imports Arvest.WCF.D3.ArvestMortgageDivisionEstatements

<ServiceBehavior(Namespace:="http://d3banking.d3connect.corelive", ConcurrencyMode:=ConcurrencyMode.Multiple)>
Public Class CoreLiveService
    Implements ICoreLive

    Private Shared amdEstatements As String = ConfigurationManager.AppSettings("mortgageDataEndpointName")
    Private Shared coreLiveCsrId As String = "CoreLiveService"
    Private Shared mortgageDataServicePassword As String = "3qem9y1f3k0b"

    Public Sub New()
        Trace.CorrelationManager.ActivityId = Guid.NewGuid
    End Sub

    Public Function IsServerAlive() As Boolean Implements IWCFContract.IsServerAlive
        Return True
    End Function

    Public Function InitiateIntraDay(request As IntraDayRequest) As IntraDayResponse Implements ICoreLive.InitiateIntraDay
        Return CoreLiveMapper.Map(As400Client.D3Connect(Of IntraDayResponseWrap)(CoreLiveMapper.Map(request), "IntraDay", "coreLive"))
    End Function

    Public Function InitiateOnDemand(request As OnDemandRequest) As OnDemandResponse Implements ICoreLive.InitiateOnDemand
        Return CoreLiveMapper.Map(As400Client.D3Connect(Of OnDemandResponseWrap)(CoreLiveMapper.Map(request), "OnDemand", "coreLive"))
    End Function

    Public Function Ping(request As PingRequest) As PingResponse Implements ICoreLive.Ping
        ThrowIfNull(request, "request")

        Return New PingResponse With
               {
                   .Header = request.Header,
                   .Fields = New CoreLiveResponse With
                             {
                                 .Status = If(As400Client.Ping(), 200, 500)
                             }
               }
    End Function

    Public Function StopPayment(request As StopPaymentRequest) As StopPaymentResponse Implements ICoreLive.StopPayment
        ThrowIfNull(request, "request")

        Return StopPayment(request.Header)
    End Function

    Private Shared Function StopPayment(header As Header) As StopPaymentResponse
        Return New StopPaymentResponse With
               {
                   .Header = header,
                   .Fields = CreateResponse(header.RequestId)
               }
    End Function

    Public Function TransferFunds(request As TransferRequest) As TransferResponse Implements ICoreLive.TransferFunds
        Return CoreLiveMapper.Map(As400Client.D3Connect(Of TransferResponseWrap)(CoreLiveMapper.Map(request), "Transfer", "coreLive"))
    End Function

    Public Function UpdateProfile(request As ProfileUpdateRequest) As ProfileUpdateResponse Implements ICoreLive.UpdateProfile
        Return CoreLiveMapper.Map(As400Client.D3Connect(Of ProfileUpdateResponseWrap)(CoreLiveMapper.Map(request), "ProfileUpdate", "coreLive"))
    End Function

    Public Function EnrollEstatements(request As EnrollEstatementsRequest) As EnrollEstatementsResponse Implements ICoreLive.EnrollEstatements
        ' If the account is a mortgage account, send the enrollment request through Mortgage Data instead.
        If Left(request.Fields.AccountId, 1) = "M" Then
            Dim client As New ArvestMortgageDivisionEstatements.StatementsClient(amdEstatements)

            Dim response As UpdateOptinStatusResponse = client.OptinStatements(New ArvestMortgageDivisionEstatements.UpdateOptinStatusRequest With {
                                                                                .AxMId = "",
                                                                                .CsrId = coreLiveCsrId,
                                                                                .EmailAddress = "",
                                                                                .LoanId = Right(request.Fields.AccountId, 16),
                                                                                .LogonId = request.Header.Authentication.UserName,
                                                                                .ServicePassword = mortgageDataServicePassword
                                                                               })

            Return New EnrollEstatementsResponse With {
                .Fields = New CoreLiveResponse With {
                            .Status = If(response.Success, 200, 501)
                          },
                .Header = request.Header
            }
        End If

        ' If the account is not a mortgage account, send it to the host for processing.
        Return CoreLiveMapper.Map(As400Client.D3Connect(Of EnrollEstatementsResponseWrap)(CoreLiveMapper.Map(request), "EnrollEstatements", "coreLive"))
    End Function

    Private Shared Function GetStatus(requestId As String) As Integer
        If Integer.TryParse(Left(requestId, 3), GetStatus) Then
            Return GetStatus
        End If

        Return 0
    End Function

    Private Shared Function CreateResponse(requestId As String) As Response
        Return New Response With
               {
                   .Status = GetStatus(requestId),
                   .ConfirmationNumber = CreateRandom.Next(Integer.MaxValue).ToString,
                   .InformationalText = "test info"
               }
    End Function
End Class