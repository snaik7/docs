﻿Imports System.Runtime.Serialization

Namespace DataContract.CoreLive
    <DataContract(Namespace:="http://d3banking.d3connect.corelive")>
    Public Class CoreLiveThrowable

        <DataMember>
        Property Throwable As Object
    End Class
End Namespace
