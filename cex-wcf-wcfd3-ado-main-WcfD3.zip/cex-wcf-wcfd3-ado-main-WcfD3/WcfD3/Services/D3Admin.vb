﻿Imports System.Collections.Generic
Imports System.Diagnostics
Imports System.ServiceModel
Imports System.Threading.Tasks

Imports Arvest.Authentication

Imports Arvest.Common
Imports Arvest.Common.WCF

Imports Arvest.DataAccess.Camp

Imports Arvest.ServiceReferences.AA
Imports Arvest.ServiceReferences.Axm

Imports Arvest.WCF.D3.DataAccess
Imports Arvest.WCF.D3.DataContract
Imports Arvest.WCF.D3.DataContract.D3Admin
Imports Arvest.WCF.D3.ServiceReferences.ArvestUser

Imports AxmUserNotFoundException = Arvest.ServiceReferences.Axm.UserNotFoundException

<ServiceBehavior(Namespace:="http://arvest.com/")>
Public Class D3Admin
    Implements ID3Admin

    Private Shared log As New ArvestTraceSource(GetType(D3Admin))

    Private Shared campClient As New CampDatabaseClient(CampDatabaseClient.D3)

    Public Sub New()
        Trace.CorrelationManager.ActivityId = Guid.NewGuid
    End Sub

    Public Function IsServerAlive() As Boolean Implements ID3Admin.IsServerAlive
        Return True
    End Function

    Function ResetD3PasswordWithLogging(ByVal request As D3AdminRequest) As D3AdminResponse Implements ID3Admin.ResetD3Password
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Password_Reset, request, {"AxmPassword"}, {New String("*"c, 8)}, AddressOf ResetD3Password)
    End Function

    Private Shared Function ResetD3Password(ByVal request As D3AdminRequest) As D3AdminResponse
        Dim axmId As Long

        If String.IsNullOrEmpty(request.AxmId) OrElse Not Long.TryParse(request.AxmId, axmId) Then
            Return D3AdminResponse.InvalidAxMId
        ElseIf String.IsNullOrEmpty(request.CsrId) Then
            Return D3AdminResponse.EmptyCsrId
        ElseIf String.IsNullOrEmpty(request.Tin) Then
            Return D3AdminResponse.InvalidTin
        End If

        Try
            Dim userId As String = Nothing

            AxMAdminWSClient.Use(Sub(client)
                                     userId = client.LookupUserIdByMapId(axmId)

                                     client.ForcePassword(userId, CreateDefaultPassword(request.Tin), Date.UtcNow.AddDays(-1))

                                     client.SetS1PasswordHash(userId, " ")

                                     client.SetDefaultPasswordFlag(userId, True)

                                     client.ClearIndefiniteLock(userId)
                                 End Sub)
        Catch ex As AxmUserNotFoundException
            Return D3AccountResponse.InvalidAxMId
        End Try

        Return D3AdminResponse.ResetPasswordSuccessful
    End Function

    Function ResetPasswordAdminWithLogging(ByVal request As D3AdminRequest) As D3AdminResponse Implements ID3Admin.ResetPasswordAdmin
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Password_Reset, request, {"AxmPassword"}, {New String("*"c, 8)}, AddressOf ResetPasswordAdmin)
    End Function

    Private Shared Function ResetPasswordAdmin(ByVal request As D3AdminRequest) As D3AdminResponse
        Dim axmId As Long

        If String.IsNullOrEmpty(request.AxmId) OrElse Not Long.TryParse(request.AxmId, axmId) Then
            Return D3AdminResponse.InvalidAxMId
        ElseIf String.IsNullOrEmpty(request.CsrId) Then
            Return D3AdminResponse.EmptyCsrId
        ElseIf String.IsNullOrEmpty(request.Tin) Then
            Return D3AdminResponse.InvalidTin
        End If

        Try
            Dim userId As String = Nothing

            AxMAdminWSClient.Use(Sub(client)
                                     userId = client.LookupUserIdByMapId(axmId)

                                     client.ForcePasswordAdmin(userId, CreateDefaultPassword(request.Tin), Date.UtcNow.AddDays(-1))

                                     client.SetS1PasswordHash(userId, " ")

                                     client.SetDefaultPasswordFlag(userId, True)

                                     client.ClearIndefiniteLock(userId)
                                 End Sub)
        Catch ex As AxmUserNotFoundException
            Return D3AccountResponse.InvalidAxMId
        End Try

        Return D3AdminResponse.ResetPasswordSuccessful
    End Function

    Function RetreiveD3AccountsWithLogging(ByVal request As D3AdminRequest) As D3AccountResponse Implements ID3Admin.RetreiveD3Accounts
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Retrieve_Account_List, request, Nothing, Nothing, AddressOf RetreiveD3Accounts)
    End Function

    Private Shared Function RetreiveD3Accounts(ByVal request As D3AdminRequest) As D3AccountResponse
        If String.IsNullOrEmpty(request.AxmId) Then
            Return D3AccountResponse.InvalidAxMId
        ElseIf String.IsNullOrEmpty(request.CsrId) Then
            Return D3AccountResponse.EmptyCsrId
        End If

        request.Function = D3AdminRequest.MapRetrieve

        Return As400Client.CallAxmService(Of D3AccountResponse)(request)
    End Function

    Function AddAccountWithLogging(ByVal request As D3AccountRequest) As D3AccountResponse Implements ID3Admin.AddAccount
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Bank_Account_Enabled, request, GetAccountNumbers(request.Accounts), Repeat("REGISTERED", request.Accounts), AddressOf AddAccount)
    End Function

    Private Shared Function GetAccountNumbers(accounts As IEnumerable(Of Account)) As IEnumerable(Of String)
        If accounts Is Nothing Then
            Return Nothing
        End If

        Return (From account As Account In accounts
                Select account.AccountNumber).ToList
    End Function

    Private Shared Function Repeat(element As String, accounts As IEnumerable(Of Account)) As IEnumerable(Of String)
        If accounts Is Nothing Then
            Return Nothing
        End If

        Return Enumerable.Repeat(element, accounts.Count).ToList
    End Function

    Private Shared Function AddAccount(ByVal request As D3AccountRequest) As D3AccountResponse
        If Not request.HasAccountData Then
            Return D3AccountResponse.NoAccounts
        ElseIf String.IsNullOrEmpty(request.AxmId) Then
            Return D3AccountResponse.InvalidAxMId
        ElseIf String.IsNullOrEmpty(request.Tin) Then
            Return D3AccountResponse.InvalidTin
        ElseIf String.IsNullOrEmpty(request.CsrId) Then
            Return D3AccountResponse.EmptyCsrId
        End If

        request.Function = D3AdminRequest.MapAdd

        Return As400Client.CallAxmService(Of D3AccountResponse)(request)
    End Function

    Function RemoveAccountWithLogging(ByVal request As D3AccountRequest) As D3AccountResponse Implements ID3Admin.RemoveAccount
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Bank_Account_Disabled, request, GetAccountNumbers(request.Accounts), Repeat("UNREGISTERED", request.Accounts), AddressOf RemoveAccount)
    End Function

    Private Shared Function RemoveAccount(ByVal request As D3AccountRequest) As D3AccountResponse
        If Not request.HasAccountData Then
            Return D3AccountResponse.NoAccounts
        ElseIf String.IsNullOrEmpty(request.AxmId) Then
            Return D3AccountResponse.InvalidAxMId
        ElseIf String.IsNullOrEmpty(request.Tin) Then
            Return D3AccountResponse.InvalidTin
        ElseIf String.IsNullOrEmpty(request.CsrId) Then
            Return D3AccountResponse.EmptyCsrId
        End If

        request.Function = D3AdminRequest.MapRemove

        Return As400Client.CallAxmService(Of D3AccountResponse)(request)
    End Function

    Function AuthorizeUserWithLogging(ByVal request As AuthorizeCsrRequest) As AuthorizeCsrResponse Implements ID3Admin.AuthorizeUser
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Authorize_CSR, request, Nothing, Nothing, AddressOf AuthorizeUser)
    End Function

    Private Shared Function AuthorizeUser(ByVal request As AuthorizeCsrRequest) As AuthorizeCsrResponse
        If String.IsNullOrEmpty(request.CsrId) Then
            Return AuthorizeCsrResponse.EmptyCsrId
        End If

        Dim resp As ADGroupsResponse = Nothing
        Dim applicationGroups As IEnumerable(Of Dao.ApplicationGroup) = Nothing

        Parallel.Invoke(Sub() resp = (New LookupClient).UseClient(Function(client As LookupClient) client.GetADGroups(request.Domain, request.UserName)),
                        Sub() applicationGroups = campClient.GetApplicationGroups())

        If resp.err Then
            Return AuthorizeCsrResponse.CreateError("020", resp.errMessage)
        End If

        AuthorizeUser = AuthorizeCsrResponse.Successful
        AuthorizeUser.Privileges = GetPrivileges(resp.Groups, applicationGroups)
    End Function

    Private Shared Function GetPrivileges(groups As IEnumerable(Of String), applicationGroups As IEnumerable(Of Dao.ApplicationGroup)) As IEnumerable(Of D3Action)
        Dim privileges As New HashSet(Of String)

        For Each adGroup As String In groups
            For Each appGroup As Dao.ApplicationGroup In applicationGroups
                If adGroup.ToLower = appGroup.GroupName.ToLower Then
                    privileges.UnionWith(appGroup.Privileges)
                End If
            Next
        Next

        Return (From privilege As String In privileges
                Select CType([Enum].Parse(GetType(D3Action), privilege), D3Action)).ToList
    End Function

    Function RevokeD3PrivilegeWithLogging(ByVal request As D3PrivilegeRequest) As D3AdminResponse Implements ID3Admin.RevokeD3Privilege
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_CSR_Privilege_Revoked, request, {"AD Group", "Privilege"}, {request.AdGroup, request.SelectedPrivilege.ToString()}, AddressOf RevokeD3Privilege)
    End Function

    Private Shared Function RevokeD3Privilege(ByVal request As D3PrivilegeRequest) As D3AdminResponse
        If String.IsNullOrEmpty(request.CsrId) Then
            Return CheckD3LockResponse.EmptyCsrId
        End If

        campClient.RemovePrivilege(request.AdGroup, request.SelectedPrivilege.ToString)

        Return D3AdminResponse.Successful
    End Function

    Function AddD3PrivilegeWithLogging(ByVal request As D3PrivilegeRequest) As D3AdminResponse Implements ID3Admin.AddD3Privilege
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_CSR_Privilege_Granted, request, {"AD Group", "Privilege"}, {request.AdGroup, request.SelectedPrivilege.ToString()}, AddressOf AddD3Privilege)
    End Function

    Private Shared Function AddD3Privilege(ByVal request As D3PrivilegeRequest) As D3AdminResponse
        If String.IsNullOrEmpty(request.CsrId) Then
            Return CheckD3LockResponse.EmptyCsrId
        End If

        campClient.AddPrivilege(request.AdGroup, request.SelectedPrivilege.ToString)

        Return D3AdminResponse.Successful
    End Function

    Function CheckD3LockWithLogging(ByVal request As D3AdminRequest) As CheckD3LockResponse Implements ID3Admin.CheckD3Lock
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Check_Password_Lock, request, Nothing, Nothing, Function() CheckD3Lock(request))
    End Function

    Private Shared Function CheckD3Lock(ByVal request As D3AdminRequest) As CheckD3LockResponse
        If String.IsNullOrEmpty(request.AxmId) Then
            Return CheckD3LockResponse.InvalidAxmId
        ElseIf String.IsNullOrEmpty(request.CsrId) Then
            Return CheckD3LockResponse.EmptyCsrId
        End If

        Dim axmLoginId As String = Nothing
        Dim aaId As String = Nothing
        Dim axmIndefLockReason As String = Nothing
        Dim axmLock As Boolean

        AxMAdminWSClient.Use(Sub(client)
                                 axmLoginId = client.LookupUserIdByMapId(Long.Parse(request.AxmId))

                                 Parallel.Invoke(Sub() axmLock = client.IsLocked(axmLoginId),
                                                 Sub() aaId = client.GetRsaId(axmLoginId),
                                                 Sub() axmIndefLockReason = client.GetIndefiniteLockoutReason(axmLoginId))
                             End Sub)

        Return If(Not String.IsNullOrEmpty(axmIndefLockReason),
                  CheckD3LockResponse.D3AccountLockedDefault(axmIndefLockReason),
                  If(axmLock OrElse CheckAALock(aaId, axmLoginId),
                  CheckD3LockResponse.D3AccountLocked,
                  CheckD3LockResponse.D3AccountUnlocked))
    End Function

    Private Shared Function CheckAALock(aaId As String, ByVal axmLoginId As String) As Boolean
        Try
            Return AdaptiveAuthenticationInterfaceClient.Use(Function(client) client.IsLocked(New AARequest With {.AdaptiveAuthId = aaId,
                                                                                                                  .UserLogOnName = axmLoginId}))
        Catch ex As NotEnrolledException
            'We don't care if they're not enrolled during a lock status check.

            Return False
        End Try
    End Function

    Function CheckD3AdminLockWithLogging(ByVal request As D3AdminRequest) As CheckD3LockResponse Implements ID3Admin.CheckD3AdminLock
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Check_Password_Lock, request, Nothing, Nothing, AddressOf CheckD3AdminLock)
    End Function

    Private Shared Function CheckD3AdminLock(ByVal request As D3AdminRequest) As CheckD3LockResponse
        If String.IsNullOrEmpty(request.AxmId) Then
            Return CheckD3LockResponse.InvalidAxmId
        ElseIf String.IsNullOrEmpty(request.CsrId) Then
            Return CheckD3LockResponse.EmptyCsrId
        End If

        Return AxMAdminWSClient.Use(Function(client) As CheckD3LockResponse
                                        Dim userName As String

                                        Try
                                            userName = client.LookupUserIdByMapId(Long.Parse(request.AxmId))
                                        Catch ex As Arvest.ServiceReferences.Axm.UserNotFoundException
                                            Return CheckD3LockResponse.InvalidAxmId
                                        End Try

                                        If client.IsAdminLocked(userName) Then
                                            CheckD3AdminLock = CheckD3LockResponse.D3AccountLocked
                                            CheckD3AdminLock.LockoutReason = client.GetLockoutReason(userName)

                                            Return CheckD3AdminLock
                                        End If

                                        Return CheckD3LockResponse.D3AccountUnlocked
                                    End Function)
    End Function

    Function CheckD3RegistrationWithLogging(ByVal request As D3AdminRequest) As D3RegistrationCheckResponse Implements ID3Admin.CheckD3Registration
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Check_Registration_Status, request, Nothing, Nothing, AddressOf CheckD3Registration)
    End Function

    Private Shared Function CheckD3Registration(ByVal request As D3AdminRequest) As D3RegistrationCheckResponse
        If String.IsNullOrEmpty(request.AxmId) Then
            Return D3RegistrationCheckResponse.InvalidAxMId
        ElseIf String.IsNullOrEmpty(request.CsrId) Then
            Return D3RegistrationCheckResponse.EmptyCsrId
        End If

        Return AxMAdminWSClient.Use(Function(client) As D3RegistrationCheckResponse
                                        Dim migrationDate As String = As400Client.RetrieveMigrationDateWithAxmId(request.AxmId)

                                        Try
                                            Dim userName As String = client.LookupUserIdByMapId(Long.Parse(request.AxmId))

                                            CheckD3Registration = If(client.IsInD3Group(userName),
                                                                     D3RegistrationCheckResponse.RegisteredInD3,
                                                                     D3RegistrationCheckResponse.NotRegisteredInD3)

                                            CheckD3Registration.D3UserName = userName
                                        Catch ex As AxmUserNotFoundException
                                            CheckD3Registration = If(String.IsNullOrEmpty(migrationDate),
                                                                     D3RegistrationCheckResponse.InvalidAxMId,
                                                                     D3RegistrationCheckResponse.NotRegisteredInD3)
                                        End Try

                                        CheckD3Registration.MigrationDate = migrationDate

                                        Return CheckD3Registration
                                    End Function)
    End Function

    Function UnregisterD3UserWithLogging(ByVal request As D3RegistrationRequest) As D3AdminResponse Implements ID3Admin.UnregisterD3User
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Login_Unregistered, request, Nothing, Nothing, AddressOf UnregisterD3User)
    End Function

    Private Shared Function UnregisterD3User(ByVal request As D3RegistrationRequest) As D3AdminResponse
        If String.IsNullOrEmpty(request.AxmId) Then
            Return D3AdminResponse.InvalidAxMId
        ElseIf String.IsNullOrEmpty(request.CsrId) Then
            Return D3AdminResponse.EmptyCsrId
        End If

        'DO NOT REMOVE; code to be uncommented when D3 takes new users without SSO login flow from S1.
        Try
            AxMAdminWSClient.Use(Sub(client) client.RemoveD3Group(client.LookupUserIdByMapId(Long.Parse(request.AxmId))))
        Catch ex As AxmUserNotFoundException
            Return D3AdminResponse.InvalidAxMId
        End Try


        'request.Service = D3RegistrationRequest.D3Service
        'request.Function = D3RegistrationRequest.MapRemoveAll

        If As400Client.CallAxmService(Of D3UnregisterResponse)(request).Success Then
            Return D3AdminResponse.UnenrollmentSuccessful
        End If

        Return D3AdminResponse.UnenrollmentFailed
    End Function

    Function MigrateD3UserWithLogging(ByVal request As D3MigrationRequest) As D3AdminResponse Implements ID3Admin.MigrateD3User
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Login_Registered, request, Nothing, Nothing, AddressOf MigrateD3User)
    End Function

    Private Shared Function MigrateD3User(ByVal request As D3MigrationRequest) As D3AdminResponse
        Dim axmId As Long

        If String.IsNullOrEmpty(request.CsrId) Then
            Return D3AdminResponse.EmptyCsrId
        ElseIf String.IsNullOrEmpty(request.AxmId) OrElse Not Long.TryParse(request.AxmId, axmId) Then
            Return D3AdminResponse.InvalidAxMId
        ElseIf String.IsNullOrEmpty(request.AxmLoginId) Then
            Return D3AdminResponse.InvalidAxmLoginId
        End If

        AxMAdminWSClient.Use(Sub(client As AxMAdminWSClient)
                                 Dim loginId As String = CreateUser(client, request.AxmLoginId, axmId, request.AdaptiveAuthId,
                                                                    AxMAdminWSClient.CreateRandomPassword(8),
                                                                    If(request.S1PasswordExpiredFlag, New Date?(Date.UtcNow), Nothing),
                                                                    request.OverwriteFlag)

                                 Parallel.Invoke({Sub() client.SetS1PasswordHash(loginId, request.S1PasswordHash),
                                                  Sub() client.AddGroup(loginId, request.TargetAxmGroup)})
                             End Sub)

        Return As400Client.CallAxmService(Of D3AdminResponse)(request)
    End Function

    Private Shared Function CreateUser(client As AxMAdminWSClient, userId As String, axmId As Long, adaptiveAuthId As String, password As String, expire? As Date,
                                       Optional overwrite As Boolean = False) As String
        Try
            Dim tempUserId As String = client.LookupUserIdByMapId(axmId)

            If overwrite OrElse IsAILUser(tempUserId, axmId) Then
                Try
                    client.SetUserId(tempUserId, userId)

                    Return userId
                Catch ex As DuplicateObjectException
                    Throw New Exception(String.Format("Can not rename AIL user '{0}'", tempUserId), ex)
                End Try
            End If

            Return tempUserId
        Catch ex As AxmUserNotFoundException
            client.CreateUser(userId, password, axmId, adaptiveAuthId, passwordExpiration:=expire)

            Return userId
        End Try
    End Function

    Private Shared Function IsAILUser(loginId As String, axmId As Long) As Boolean
        Dim tempAxmId As Long

        Return Long.TryParse(loginId, tempAxmId) AndAlso tempAxmId = axmId
    End Function

    Function RegisterD3UserWithLogging(ByVal request As D3RegistrationRequest) As D3AdminResponse Implements ID3Admin.RegisterD3User
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Login_Registered, request, Nothing, Nothing, AddressOf RegisterD3User)
    End Function

    Private Shared Function RegisterD3User(ByVal request As D3RegistrationRequest) As D3AdminResponse
        Dim axmId As Long
        Dim loginId As String = request.AxmLoginId

        If String.IsNullOrEmpty(request.AxmId) OrElse Not Long.TryParse(request.AxmId, axmId) Then
            Return D3AdminResponse.InvalidAxMId
        ElseIf String.IsNullOrEmpty(request.CsrId) Then
            Return D3AdminResponse.EmptyCsrId
        ElseIf String.IsNullOrEmpty(loginId) Then
            Return D3AdminResponse.EmptyLoginId
        ElseIf String.IsNullOrEmpty(request.Tin) Then
            Return D3AdminResponse.InvalidTin
        End If

        'TODO:  Removed to prepare S1 removal
        'If Authenticator.S1UserExistsByCustemerId(loginId.ToUpper) Then
        '    Return D3AdminResponse.RegistrationFromS1Fail(As400Client.RetrieveMigrationDate(loginId.ToUpper))
        'End If

        Return AxMAdminWSClient.Use(Function(client)
                                        loginId = CreateUser(client, loginId, axmId, axmId.ToString, CreateDefaultPassword(request.Tin), Date.UtcNow)

                                        Dim hostResponse As D3VerifyHostResponse = Nothing

                                        Parallel.Invoke(Sub() client.AddD3Group(loginId),
                                                        Sub() hostResponse = As400Client.CallAxmService(Of D3VerifyHostResponse)(New D3HostUpdate(axmId, request.CsrId)))

                                        Dim axmIds As IEnumerable(Of AxMRecord) = hostResponse.AxmIds

                                        Return If(axmIds IsNot Nothing AndAlso axmIds.Count > 0 AndAlso axmIds(0).AccountStatus = "REGISTERED",
                                                  D3AdminResponse.RegistrationSuccessful,
                                                  D3AdminResponse.CreateHostError(Of D3AdminResponse)(hostResponse.ErrorDescription))
                                    End Function)
    End Function

    Private Shared Function CreateDefaultPassword(tin As String) As String
        Return "AR" & Right(tin, 6)
    End Function

    Public Function LockD3UserWithLogging(ByVal request As D3LockAccountRequest) As D3AdminResponse Implements ID3Admin.LockD3User
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Login_Administratively_Locked, request, {"AxMExpiration", "AxMLockoutReason"}, {Date.Now.AddDays(-1).ToString, request.LockoutReason}, AddressOf LockD3User)
    End Function

    Private Shared Function LockD3User(ByVal request As D3LockAccountRequest) As D3AdminResponse
        If String.IsNullOrEmpty(request.AxmId) Then
            Return D3AdminResponse.InvalidAxMId
        ElseIf String.IsNullOrEmpty(request.CsrId) Then
            Return D3AdminResponse.EmptyCsrId
        ElseIf String.IsNullOrEmpty(request.LockoutReason) Then
            Return D3AdminResponse.EmptyLockoutReason
        End If

        AxMAdminWSClient.Use(Sub(client) client.AdministrativelyLockUser(client.LookupUserIdByMapId(CLng(request.AxmId)), request.LockoutReason))

        Return D3AdminResponse.LockD3Successful
    End Function

    Public Function UnlockD3UserWithLoging(ByVal request As D3AdminRequest) As D3AdminResponse Implements ID3Admin.UnlockD3User
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Login_Unlocked, request, {"AxMAccountLock"}, {"Unlocked"}, Function() UnlockD3User(request))
    End Function

    Public Shared Function UnlockD3User(ByVal request As D3AdminRequest) As D3AdminResponse
        If String.IsNullOrEmpty(request.AxmId) Then
            Return D3AdminResponse.InvalidAxMId
        ElseIf String.IsNullOrEmpty(request.CsrId) Then
            Return D3AdminResponse.EmptyCsrId
        End If

        Dim axmLoginId As String = AxMAdminWSClient.Use(Function(client) client.LookupUserIdByMapId(CLng(request.AxmId)))

        Parallel.Invoke(Sub() UnlockAAUser(axmLoginId),
                        Sub() AxMAdminWSClient.Use(Sub(client) client.UnlockUser(axmLoginId)))

        Return D3AdminResponse.UnlockD3Successful
    End Function

    Private Shared Sub UnlockAAUser(ByVal axmLoginId As String)
        Dim aaId As String = AxMAdminWSClient.Use(Function(client) client.GetRsaId(axmLoginId))

        Try
            AdaptiveAuthenticationInterfaceClient.Use(Sub(client) client.UnlockUser(New AARequest With {.AdaptiveAuthId = aaId,
                                                                                                        .UserLogOnName = axmLoginId}))
        Catch ex As NotEnrolledException
            'We don't care if they're not enrolled during an unlock check.
        End Try
    End Sub

    Public Function UnenrollAdaptiveAuthenticationWithLogging(ByVal request As D3AdminRequest) As D3AdminResponse Implements ID3Admin.UnenrollAdaptiveAuthentication
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Challenge_Questions_Reset, request, Nothing, Nothing, Function() UnenrollAdaptiveAuthentication(request))
    End Function

    Shared Function UnenrollAdaptiveAuthentication(ByVal request As D3AdminRequest) As D3AdminResponse
        If String.IsNullOrEmpty(request.AxmId) Then
            Return D3AdminResponse.InvalidAxMId
        ElseIf String.IsNullOrEmpty(request.AxmLoginId) Then
            Return D3AdminResponse.EmptyLoginId
        End If

        Try
            AdaptiveAuthenticationInterfaceClient.Use(Sub(client As AdaptiveAuthenticationInterfaceClient)
                                                          client.UnenrollUser(New AARequest With
                                                                              {
                                                                                  .AdaptiveAuthId = AxMAdminWSClient.GetRsaIdUsed(request.AxmLoginId),
                                                                                  .UserLogOnName = request.AxmLoginId
                                                                              })
                                                      End Sub)
        Catch ex As NotEnrolledException
            'Don't care if the user is already unenrolled.
        End Try

        Return D3AdminResponse.UnenrollmentSuccessful
    End Function

    Public Function AdminUnlockD3UserWithLogging(ByVal request As D3AdminRequest) As D3AdminResponse Implements ID3Admin.AdminUnlockD3User
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Login_Administratively_Unlocked, request, {"AxMExpiration", "AxMLockoutReason"}, {Date.Now.AddMonths(6).ToString, New String(" "c, 1)}, AddressOf AdminUnlockD3User)
    End Function

    Private Shared Function AdminUnlockD3User(ByVal request As D3AdminRequest) As D3AdminResponse
        If String.IsNullOrEmpty(request.AxmId) Then
            Return D3AdminResponse.InvalidAxMId
        ElseIf String.IsNullOrEmpty(request.CsrId) Then
            Return D3AdminResponse.EmptyCsrId
        End If

        AxMAdminWSClient.Use(Sub(client) client.AdministrativelyUnlockUser(client.LookupUserIdByMapId(CLng(request.AxmId))))

        Return D3AdminResponse.UnlockD3Successful
    End Function

    Function GetUserD3LogsWithLogging(ByVal request As D3AdminRequest) As D3LogSearchResponse Implements ID3Admin.GetUserD3Logs
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Search_Logs, request, Nothing, Nothing, AddressOf GetUserD3Logs)
    End Function

    Private Shared Function GetUserD3Logs(ByVal request As D3AdminRequest) As D3LogSearchResponse
        If String.IsNullOrEmpty(request.AxmId) Then
            Return D3LogSearchResponse.InvalidAxMId
        ElseIf String.IsNullOrEmpty(request.CsrId) Then
            Return D3LogSearchResponse.EmptyCsrId
        End If

        GetUserD3Logs = D3LogSearchResponse.SuccessfulSearch

        GetUserD3Logs.results = campClient.SearchLogs(New Dao.LogSearchRequest With {.AxmId = request.AxmId,
                                                                                     .CustomerId = request.AxmLoginId})
    End Function

    Function GetD3GroupsWithLogging(ByVal request As D3AdminRequest) As GetD3PrivilegesResponse Implements ID3Admin.GetD3Groups
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Search_Logs, request, Nothing, Nothing,
                         Function() New GetD3PrivilegesResponse With {.Groups = Converter.Convert(campClient.GetApplicationGroups())})
    End Function

    Public Function SearchLogsWithLogging(ByVal request As D3LogSearchRequest) As D3LogSearchResponse Implements ID3Admin.SearchD3Logs
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Search_Logs, request, Nothing, Nothing, AddressOf SearchLogs)
    End Function

    Public Function D3UserOptOutWithLogging(ByVal request As D3AdminRequest) As D3AdminResponse Implements ID3Admin.D3UserOptOut
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Login_Prevented, request, Nothing, Nothing, AddressOf D3UserOptOut)
    End Function

    Private Shared Function D3UserOptOut(ByVal request As D3AdminRequest) As D3AdminResponse
        Dim loginId As String = request.AxmLoginId

        If String.IsNullOrEmpty(loginId) Then
            Return D3AdminResponse.InvalidAxmLoginId
        End If

        AxMAdminWSClient.Use(Sub(client)
                                 Try
                                     client.OptOutD3Group(loginId)
                                 Catch ex As AxmUserNotFoundException
                                     client.CreateUser(loginId,
                                                       AxMAdminWSClient.CreateRandomPassword(8),
                                                       Long.Parse(request.AxmId),
                                                       passwordExpiration:=Date.UtcNow)

                                     client.OptOutD3Group(loginId)
                                 End Try
                             End Sub)

        Return D3AdminResponse.Successful
    End Function

    Public Function D3UserOptinWithLogging(ByVal request As D3AdminRequest) As D3AdminResponse Implements ID3Admin.D3UserOptIn
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Login_Allowed, request, Nothing, Nothing, AddressOf D3UserOptIn)
    End Function

    Private Shared Function D3UserOptIn(ByVal request As D3AdminRequest) As D3AdminResponse
        If String.IsNullOrEmpty(request.AxmLoginId) Then
            Return D3AdminResponse.InvalidAxmLoginId
        End If

        AxMAdminWSClient.Use(Sub(client) client.OptInD3Group(request.AxmLoginId))

        Return D3AdminResponse.Successful
    End Function

    Public Function D3UserOptOutCheckWithLogging(ByVal request As D3AdminRequest) As D3AdminResponse Implements ID3Admin.D3UserOptOutCheck
        ThrowIfNull(request, "request")

        Return LogAction(D3Action.AOB_Login_Allowed_Check, request, Nothing, Nothing, AddressOf D3UserOptOutCheck)
    End Function

    Private Shared Function D3UserOptOutCheck(ByVal request As D3AdminRequest) As D3AdminResponse
        If String.IsNullOrEmpty(request.AxmLoginId) Then
            Return D3AdminResponse.InvalidAxmLoginId
        End If

        Try
            Return If(AxMAdminWSClient.Use(Function(client) client.IsInGroup(request.AxmLoginId, AxmUserGroup.D3OptOut)),
                      D3AdminResponse.CustomerOptOut,
                      D3AdminResponse.Successful)
        Catch ex As AxmUserNotFoundException
            Return D3AdminResponse.Successful
        End Try
    End Function

    Private Shared Function SearchLogs(ByVal request As D3LogSearchRequest) As D3LogSearchResponse
        SearchLogs = D3LogSearchResponse.SuccessfulSearch

        SearchLogs.results = campClient.SearchLogs(New Dao.LogSearchRequest With
                                                   {
                                                       .AxmId = request.SearchAxmId,
                                                       .CustomerId = request.CustomerId,
                                                       .End = request.EndDt,
                                                       .Start = request.StartDt,
                                                       .Action = request.ActionType.ToString,
                                                       .CsrId = request.SearchCSRId
                                                   })
    End Function

    Private Shared Function LogAction(Of T As {D3AdminRequest}, TResult As {New, D3AdminResponse})(ByVal action As D3Action, ByVal request As T,
                                                                                                   ByVal properties As IEnumerable(Of String),
                                                                                                   ByVal propertyValues As IEnumerable(Of String),
                                                                                                   ByVal f As Func(Of T, TResult)) As TResult
        Dim success As Boolean

        Try
            LogAction = f(request)

            success = LogAction.Success
        Catch ex As Exception
            ex.AddData("request", request, {"TempPassword"})

            success = False

            LogAction = D3AdminResponse.CreateError(Of TResult)(ex, log)
        End Try

        LogAction(action, request.CsrId, request.AxmLoginId, request.AxmId, properties, propertyValues, success,
                  request.ClientIp, LogAction.Code, LogAction.Message, request.ClientBrowserInfo)

        Return LogAction
    End Function

    Friend Shared Sub LogAction(action As D3Action, csrId As String, logOnId As String, axmId As String, properties As IEnumerable(Of String),
                         propertyValues As IEnumerable(Of String), success As Boolean, clientIp As String, messageCode As String, message As String, clientBrowser As String)
        Task.Factory.StartNew(
            Sub() campClient.LogAction(action, csrId, logOnId, axmId, success, Join(properties), Join(propertyValues),
                                       clientIp, clientBrowser, messageCode, message))
    End Sub

    Private Shared Function Join(value As IEnumerable(Of String)) As String
        Return If(value Is Nothing, Nothing, String.Join("|"c, value))
    End Function
End Class
