﻿Imports System.Runtime.Serialization
Imports System.ComponentModel

<DataContract()>
Public Enum D3Action

    <EnumMember()>
    <Description("Empty")>
    Empty = 0

    <EnumMember()>
    <Description("Reset AOB Password")>
    AOB_Password_Reset

    <EnumMember()>
    <Description("Administratively Lock AOB Account")>
    AOB_Login_Administratively_Locked

    <EnumMember()>
    <Description("Reset AOB password attempts")>
    AOB_Login_Unlocked

    <EnumMember()>
    <Description("Enable account in AOB")>
    AOB_Bank_Account_Enabled

    <EnumMember()>
    <Description("Disable account in AOB")>
    AOB_Bank_Account_Disabled

    <EnumMember()>
    <Description("Register customer for AOB")>
    AOB_Login_Registered

    <EnumMember()>
    <Description("Unregister customer for AOB")>
    AOB_Login_Unregistered

    <EnumMember()>
    <Description("Retrieve AD groups for AOB service")>
    AOB_Get_AD_Groups

    <EnumMember()>
    <Description("Search AOB Logs")>
    AOB_Search_Logs

    <EnumMember()>
    <Description("Retrieve AD group privileges for AOB service")>
    AOB_Retrieve_Privilege_List

    <EnumMember()>
    <Description("Grant AD group an AOB privilege")>
    AOB_CSR_Privilege_Granted

    <EnumMember()>
    <Description("Revoke AOB privilege from AD group")>
    AOB_CSR_Privilege_Revoked

    <EnumMember()>
    <Description("Retrieve customer's AOB accounts")>
    AOB_Retrieve_Account_List

    <EnumMember()>
    <Description("Check AOB account lock status")>
    AOB_Check_Password_Lock

    <EnumMember()>
    <Description("Check AOB registration status")>
    AOB_Check_Registration_Status

    <EnumMember()>
    <Description("Remove Administrative AOB Lock")>
    AOB_Login_Administratively_Unlocked

    <EnumMember()>
    <Description("Reset AOB challenge questions")>
    AOB_Challenge_Questions_Reset

    <EnumMember()>
    <Description("Reset AOB login ID")>
    AOB_Login_ID_Changed

    <EnumMember()>
    <Description("Authorize CSR access")>
    AOB_Authorize_CSR

    <EnumMember()>
    <Description("Opt-Out of Service")>
    AOB_Login_Prevented

    <EnumMember()>
    <Description("Opt-In for Service")>
    AOB_Login_Allowed

    <EnumMember()>
    <Description("Check customer opt status.")>
    AOB_Login_Allowed_Check
End Enum