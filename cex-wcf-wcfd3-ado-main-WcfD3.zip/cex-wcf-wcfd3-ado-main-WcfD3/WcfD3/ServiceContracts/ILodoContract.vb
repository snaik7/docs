﻿Imports System.ServiceModel

Imports Arvest.Common.WCF

Imports Arvest.WCF.D3.DataContract.Lodo

<ServiceContract(Namespace:="http://arvest.com/")>
Public Interface ILodoContract
    Inherits IWCFContract

    <OperationContract(Name:="authenticateUserRSA")>
    Function AuthenticateUserRsa(ByVal request As AuthenticateUserRsaRequest) As AuthenticateUserRsaResponse

    <OperationContract(Name:="authenticateUser")>
    Function AuthenticateUser(ByVal request As AuthenticateUserRequest) As LodoResponse

    <OperationContract(Name:="lockUser")>
    Function LockUser(request As LockUserRequest) As LodoResponse

    <OperationContract(Name:="unLockUser")>
    Function UnlockUser(request As LockUserRequest) As LodoResponse

    <OperationContract(Name:="isLocked")>
    Function IsLocked(request As LockUserRequest) As IsLockedResponse

    <OperationContract(Name:="changePassword")>
    Function ChangePassword(request As Credentials) As LodoResponse

    <OperationContract(Name:="changeUserId")>
    Function ChangeUserId(request As ChangeUserIdRequest) As LodoResponse
End Interface
