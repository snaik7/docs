﻿Imports System.ServiceModel

Imports Arvest.Common
Imports Arvest.Common.WCF

Imports Arvest.WCF.D3.DataContract.CoreLive

<ServiceContract(Name:="CoreLive", Namespace:="http://d3banking.d3connect.corelive")>
<XmlSerializerFormat>
Public Interface ICoreLive
    Inherits IWCFContract

    <FaultContract(GetType(CoreLiveThrowable), Name:="CoreLiveThrowable", Action:="urn:updateProfileCoreLiveThrowable")>
    <OperationContract(Name:="updateProfile", Action:="urn:updateProfile", ReplyAction:="urn:updateProfileResponse")>
    Function UpdateProfile(request As ProfileUpdateRequest) As ProfileUpdateResponse

    <FaultContract(GetType(CoreLiveThrowable), Name:="CoreLiveThrowable", Action:="urn:initiateIntraDayCoreLiveThrowable")>
    <OperationContract(Name:="initiateIntraDay", Action:="urn:initiateIntraDay", ReplyAction:="urn:initiateIntraDayResponse")>
    Function InitiateIntraDay(request As IntraDayRequest) As IntraDayResponse

    <FaultContract(GetType(CoreLiveThrowable), Name:="CoreLiveThrowable", Action:="urn:stopPaymentCoreLiveThrowable")>
    <OperationContract(Name:="stopPayment", Action:="urn:stopPayment", ReplyAction:="urn:stopPaymentResponse")>
    Function StopPayment(request As StopPaymentRequest) As StopPaymentResponse

    <FaultContract(GetType(CoreLiveThrowable), Name:="CoreLiveThrowable", Action:="urn:initiateOnDemandCoreLiveThrowable")>
    <OperationContract(Name:="initiateOnDemand", Action:="urn:initiateOnDemand", ReplyAction:="urn:initiateOnDemandResponse")>
    Function InitiateOnDemand(request As OnDemandRequest) As OnDemandResponse

    <FaultContract(GetType(CoreLiveThrowable), Name:="CoreLiveThrowable", Action:="urn:transferFundsCoreLiveThrowable")>
    <OperationContract(Name:="transferFunds", Action:="urn:transferFunds", ReplyAction:="urn:transferFundsResponse")>
    Function TransferFunds(request As TransferRequest) As TransferResponse

    <FaultContract(GetType(CoreLiveThrowable), Name:="CoreLiveThrowable", Action:="urn:pingCoreLiveThrowable")>
    <OperationContract(Name:="ping", Action:="urn:ping", ReplyAction:="urn:pingResponse")>
    Function Ping(request As PingRequest) As PingResponse

    <FaultContract(GetType(CoreLiveThrowable), Name:="CoreLiveThrowable", Action:="urn:enrollEstatementsThrowable")>
    <OperationContract(Name:="enrollEstatements", Action:="urn:enrollEstatements", ReplyAction:="urn:enrollEstatementsResponse")>
    Function EnrollEstatements(request As EnrollEstatementsRequest) As EnrollEstatementsResponse
End Interface
