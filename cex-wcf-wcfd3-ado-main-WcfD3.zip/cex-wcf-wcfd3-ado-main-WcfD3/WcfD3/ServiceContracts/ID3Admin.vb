﻿Imports System.ServiceModel
Imports Arvest.Common.WCF
Imports Arvest.WCF.D3.DataContract
Imports Arvest.ServiceReferences.AA

<ServiceContract(Namespace:="http://arvest.com/")>
Public Interface ID3Admin
    Inherits IWCFContract

    <OperationContract()>
    Function ResetD3Password(ByVal request As D3AdminRequest) As D3AdminResponse

    <OperationContract()>
    Function ResetPasswordAdmin(ByVal request As D3AdminRequest) As D3AdminResponse

    <OperationContract()>
    Function RetreiveD3Accounts(ByVal request As D3AdminRequest) As D3AccountResponse

    <OperationContract()>
    Function AddAccount(ByVal request As D3AccountRequest) As D3AccountResponse

    <OperationContract()>
    Function RemoveAccount(ByVal request As D3AccountRequest) As D3AccountResponse

    <OperationContract()>
    Function SearchD3Logs(ByVal requset As D3LogSearchRequest) As D3LogSearchResponse

    <OperationContract()>
    Function AuthorizeUser(ByVal request As AuthorizeCsrRequest) As AuthorizeCsrResponse

    <OperationContract()>
    Function RevokeD3Privilege(ByVal request As D3PrivilegeRequest) As D3AdminResponse

    <OperationContract()>
    Function AddD3Privilege(ByVal request As D3PrivilegeRequest) As D3AdminResponse

    <OperationContract()>
    Function CheckD3Lock(ByVal request As D3AdminRequest) As CheckD3LockResponse

    <OperationContract()>
    Function CheckD3AdminLock(ByVal request As D3AdminRequest) As CheckD3LockResponse

    <OperationContract()>
    Function CheckD3Registration(ByVal request As D3AdminRequest) As D3RegistrationCheckResponse

    <OperationContract()>
    Function GetD3Groups(ByVal request As D3AdminRequest) As GetD3PrivilegesResponse

    <OperationContract()>
    Function RegisterD3User(ByVal request As D3RegistrationRequest) As D3AdminResponse

    <OperationContract()>
    Function UnregisterD3User(ByVal request As D3RegistrationRequest) As D3AdminResponse

    <OperationContract()>
    Function UnlockD3User(ByVal request As D3AdminRequest) As D3AdminResponse

    <OperationContract()>
    Function LockD3User(ByVal request As D3LockAccountRequest) As D3AdminResponse

    <OperationContract()>
    Function AdminUnlockD3User(ByVal request As D3AdminRequest) As D3AdminResponse

    <OperationContract()>
    Function UnenrollAdaptiveAuthentication(ByVal request As D3AdminRequest) As D3AdminResponse

    <OperationContract()>
    Function GetUserD3Logs(ByVal request As D3AdminRequest) As D3LogSearchResponse

    <OperationContract()>
    Function MigrateD3User(ByVal request As D3MigrationRequest) As D3AdminResponse

    <OperationContract()>
    Function D3UserOptOut(ByVal request As D3AdminRequest) As D3AdminResponse

    <OperationContract()>
    Function D3UserOptOutCheck(ByVal request As D3AdminRequest) As D3AdminResponse

    <OperationContract()>
    Function D3UserOptIn(ByVal request As D3AdminRequest) As D3AdminResponse
End Interface