﻿Imports System.Runtime.Serialization
Imports System.ServiceModel

Namespace DataContract.Lodo
    <DataContract(Namespace:="http://schemas.datacontract.org/2004/07/Arvest.WCF.OLBLodo")>
    Public Class AuthenticateUserRequest
        Inherits Credentials

    End Class
End Namespace