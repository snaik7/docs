﻿Imports System.Runtime.Serialization

Namespace DataContract.Lodo
    <DataContract(Namespace:="http://schemas.datacontract.org/2004/07/Arvest.WCF.OLBLodo")>
    Public Class LodoError

        <DataMember(Name:="code")>
        Property Code As Integer

        <DataMember(Name:="message")>
        Property Message As String
    End Class
End Namespace
