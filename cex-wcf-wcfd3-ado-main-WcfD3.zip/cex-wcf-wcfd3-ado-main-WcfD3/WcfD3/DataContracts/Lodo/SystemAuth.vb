﻿Imports System.Runtime.Serialization

Namespace DataContract.Lodo
    <DataContract(Namespace:="http://schemas.datacontract.org/2004/07/Arvest.WCF.OLBLodo")>
    Public Class SystemAuth

        <DataMember(Name:="systemPassword")>
        Property SystemPassword As String
    End Class
End Namespace