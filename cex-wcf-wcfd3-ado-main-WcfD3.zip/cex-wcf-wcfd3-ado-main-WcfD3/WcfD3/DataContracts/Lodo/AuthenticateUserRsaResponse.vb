﻿Imports System.Runtime.Serialization

Namespace DataContract.Lodo
    <DataContract(Name:="AuthenticateUserRSAResponse", Namespace:="http://schemas.datacontract.org/2004/07/Arvest.WCF.OLBLodo")>
    Public Class AuthenticateUserRsaResponse
        Inherits LodoResponse

        <DataMember(Name:="rsaId")>
        Property RsaId As String

        <DataMember(Name:="directId")>
        Property DirectId As String

        <DataMember(Name:="branchId")>
        Property BranchId As String = "Default"
    End Class
End Namespace
