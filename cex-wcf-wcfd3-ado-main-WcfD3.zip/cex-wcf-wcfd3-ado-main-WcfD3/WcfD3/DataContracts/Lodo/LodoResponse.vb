﻿Imports System.Runtime.Serialization

Namespace DataContract.Lodo
    <DataContract(Namespace:="http://schemas.datacontract.org/2004/07/Arvest.WCF.OLBLodo")>
    Public Class LodoResponse
        <DataMember(Name:="success")>
        Property Success As Boolean = True

        <DataMember(Name:="err")>
        Property Err As LodoError
    End Class
End Namespace

