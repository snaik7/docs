﻿Imports Arvest.Common

Namespace DataContract.Lodo
    Class LodoResponseFactory
        Inherits LodoResponseFactory(Of LodoResponse)

        Private Sub New()

        End Sub

        Overloads Shared Function Create() As LodoResponse
            Return New LodoResponse
        End Function
    End Class

    Class LodoResponseFactory(Of T As {LodoResponse, New})
        Protected Sub New()

        End Sub

        Shared Function Create(err As LodoError) As T
            Return New T With {.Success = False,
                               .Err = err}
        End Function

        Shared Function Create(code As Integer, message As String) As T
            Return Create(New LodoError With {.Code = code,
                                              .Message = message})
        End Function

        Shared Function Create(ex As Exception) As T
            Return Create(0, ex.GetMessages)
        End Function

        Protected Shared Function GetErrorCode(errorCode As String) As Integer
            Return If(Integer.TryParse(errorCode, GetErrorCode), GetErrorCode, 0)
        End Function

        Shared ReadOnly Property InvalidSysPassword As T
            Get
                Return Create(1, "Invalid System Password")
            End Get
        End Property

        Shared ReadOnly Property UserDoesntExist As T
            Get
                Return Create(2, "User does not exist")
            End Get
        End Property

        Shared ReadOnly Property IllegalPassword(message As String) As T
            Get
                Return Create(3, String.Format("Illegal password: {0}", message))
            End Get
        End Property

        Shared ReadOnly Property InvalidPassword As T
            Get
                Return Create(4, "Invalid Password")
            End Get
        End Property

        Shared ReadOnly Property ExpiredPassword As T
            Get
                Return Create(5, "Expired password")
            End Get
        End Property

        Shared ReadOnly Property ExpiredAccount As T
            Get
                Return Create(6, "Expired account")
            End Get
        End Property

        Shared ReadOnly Property LockedUser As T
            Get
                Return Create(7, "User locked out")
            End Get
        End Property

        Shared ReadOnly Property IllegalUserId As T
            Get
                Return Create(8, "Illegal user id")
            End Get
        End Property

        Shared ReadOnly Property DuplicateUserId As T
            Get
                Return Create(9, "User id already exists")
            End Get
        End Property
    End Class
End Namespace

