﻿Imports System.Runtime.Serialization

Namespace DataContract.Lodo
    <DataContract(Name:="AuthenticateUserRSARequest", Namespace:="http://schemas.datacontract.org/2004/07/Arvest.WCF.OLBLodo")>
    Public Class AuthenticateUserRsaRequest
        Inherits SystemAuth

        <DataMember(Name:="userid")>
        Public Property UserId As String
    End Class
End Namespace
