﻿Imports System.Runtime.Serialization

Namespace DataContract.Lodo
    <DataContract(Namespace:="http://schemas.datacontract.org/2004/07/Arvest.WCF.OLBLodo")>
    Public Class IsLockedResponse
        Inherits LodoResponse

        <DataMember>
        Property IsLocked As Boolean
    End Class
End Namespace
