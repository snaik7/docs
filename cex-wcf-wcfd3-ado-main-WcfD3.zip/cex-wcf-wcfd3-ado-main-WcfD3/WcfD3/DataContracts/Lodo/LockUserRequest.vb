﻿Imports System.Runtime.Serialization
Imports System.ServiceModel

Namespace DataContract.Lodo
    <DataContract(Namespace:="http://schemas.datacontract.org/2004/07/Arvest.WCF.OLBLodo")>
    Public Class LockUserRequest
        Inherits SystemAuth

        <DataMember(Name:="userID")>
        Property UserId As String
    End Class
End Namespace

