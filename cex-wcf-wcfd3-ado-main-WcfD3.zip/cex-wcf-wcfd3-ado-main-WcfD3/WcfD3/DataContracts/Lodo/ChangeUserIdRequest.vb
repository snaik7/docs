﻿Imports System.Runtime.Serialization

Namespace DataContract.Lodo
    <DataContract(Namespace:="http://schemas.datacontract.org/2004/07/Arvest.WCF.OLBLodo")>
        Public Class ChangeUserIdRequest
        Inherits SystemAuth

        <DataMember(Name:="userId")>
        Property UserId As String

        <DataMember(Name:="newUserId")>
        Property NewUserId As String

        <DataMember(Name:="clientIp")>
        Property ClientIp As String
    End Class
End Namespace