﻿Imports System.ServiceModel

Namespace DataContract.CoreLive
    <MessageContract(WrapperName:="ping")>
    Public Class PingRequest
        Inherits CoreLiveContract

    End Class
End Namespace
