﻿Imports System.Xml.Serialization
Imports System.Collections.Generic

Namespace DataContract.CoreLive
    <XmlType("intlAcctFundXferResp")>
    Public Class TransferResponseFields
        Inherits Response

        <XmlElement("fromAcctAvblBal")>
        Public Property FromAccountAvailableBalance As Decimal?

        <XmlElement("toAcctAvblBal")>
        Public Property ToAccountAvailableBalance As Decimal?

        <XmlArray("txnList")>
        <XmlArrayItem("txn")>
        Public Property Transactions As List(Of Transaction)
    End Class
End Namespace