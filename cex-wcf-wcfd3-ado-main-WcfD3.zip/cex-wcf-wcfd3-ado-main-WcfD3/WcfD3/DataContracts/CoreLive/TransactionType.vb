﻿Imports System.Xml.Serialization

Namespace DataContract.CoreLive
    <XmlType("txnTypeEnumType")>
    Public Enum TransactionType
        <XmlEnum("c")>
        Credit

        <XmlEnum("d")>
        Debit
    End Enum
End Namespace