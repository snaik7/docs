﻿Imports System.Xml.Serialization

Namespace DataContract.CoreLive
    Public Class AccountRequest
        <XmlElement("acctUid")>
        Public Property AccountId As String

        <XmlElement("compUid")>
        Public Property CompanyId As String
    End Class
End Namespace
