﻿Imports System.Collections.Generic

Imports Arvest.WCF.D3.DataContract.CoreLive
Imports Arvest.WCF.D3.DataAccess.Daos
Imports Arvest.WCF.D3.DataAccess.Daos.Wrappers

Imports AuthenticationDC = Arvest.WCF.D3.DataContract.CoreLive.Authentication
Imports AuthenticationDao = Arvest.WCF.D3.DataAccess.Daos.Authentication

Imports HeaderDC = Arvest.WCF.D3.DataContract.CoreLive.Header
Imports HeaderDao = Arvest.WCF.D3.DataAccess.Daos.Header

Imports TransferRequestDC = Arvest.WCF.D3.DataContract.CoreLive.TransferRequest
Imports TransferRequestDao = Arvest.WCF.D3.DataAccess.Daos.TransferRequest
Imports TransferOnUsRequestDao = Arvest.WCF.D3.DataAccess.Daos.TransferOnUsRequest

Imports TransferResponseDC = Arvest.WCF.D3.DataContract.CoreLive.TransferResponse
Imports TransferResponseDao = Arvest.WCF.D3.DataAccess.Daos.TransferResponse
Imports TransferOnUsResponseDao = Arvest.WCF.D3.DataAccess.Daos.TransferOnUsResponse

Imports AsyncResponseDC = Arvest.WCF.D3.DataContract.CoreLive.AsyncResponse
Imports AsyncResponseDao = Arvest.WCF.D3.DataAccess.Daos.AsyncResponse

Imports IntraDayRequestDC = Arvest.WCF.D3.DataContract.CoreLive.IntraDayRequest
Imports IntraDayRequestDao = Arvest.WCF.D3.DataAccess.Daos.IntraDayRequest

Imports DateRangeDC = Arvest.WCF.D3.DataContract.CoreLive.DateRange
Imports DateRangeDao = Arvest.WCF.D3.DataAccess.Daos.DateRange

Imports OnDemandRequestDC = Arvest.WCF.D3.DataContract.CoreLive.OnDemandRequest
Imports OnDemandRequestDao = Arvest.WCF.D3.DataAccess.Daos.OnDemandRequest

Imports OnDemandResponseDC = Arvest.WCF.D3.DataContract.CoreLive.OnDemandResponse

Imports ProfileUpdateRequestDC = Arvest.WCF.D3.DataContract.CoreLive.ProfileUpdateRequest
Imports ProfileUpdateRequestDao = Arvest.WCF.D3.DataAccess.Daos.ProfileUpdateRequest

Imports ProfileUpdateResponseDC = Arvest.WCF.D3.DataContract.CoreLive.ProfileUpdateResponse

Imports AccountEnrollmentDC = Arvest.WCF.D3.DataContract.CoreLive.AccountEnrollment
Imports AccountEnrollmentDao = Arvest.WCF.D3.DataAccess.Daos.AccountEnrollment

Imports UserSettingsDC = Arvest.WCF.D3.DataContract.CoreLive.UserSettings
Imports UserSettingsDao = Arvest.WCF.D3.DataAccess.Daos.UserSettings

Imports PersonDC = Arvest.WCF.D3.DataContract.CoreLive.Person
Imports PersonDao = Arvest.WCF.D3.DataAccess.Daos.Person

Imports AddressDC = Arvest.WCF.D3.DataContract.CoreLive.Address
Imports AddressDao = Arvest.WCF.D3.DataAccess.Daos.Address

Imports ResponseDC = Arvest.WCF.D3.DataContract.CoreLive.Response
Imports ResponseDao = Arvest.WCF.D3.DataAccess.Daos.Response

Imports UserProfileDC = Arvest.WCF.D3.DataContract.CoreLive.UserProfile
Imports UserProfileDao = Arvest.WCF.D3.DataAccess.Daos.UserProfile

Imports CoreLiveResponseDC = Arvest.WCF.D3.DataContract.CoreLive.CoreLiveResponse
Imports CoreLiveResponseDao = Arvest.WCF.D3.DataAccess.Daos.CoreLiveResponse

Imports TransactionDC = Arvest.WCF.D3.DataContract.CoreLive.Transaction
Imports TransactionDao = Arvest.WCF.D3.DataAccess.Daos.Transaction

Imports TransactionTypeDC = Arvest.WCF.D3.DataContract.CoreLive.TransactionType
Imports TransactionTypeDao = Arvest.WCF.D3.DataAccess.Daos.TransactionType

Namespace Domain
    NotInheritable Class CoreLiveMapper

        Private Sub New()

        End Sub

        Shared Function Map(response As EnrollEstatementsResponseWrap) As EnrollEstatementsResponse
            If response Is Nothing Then
                Return Nothing
            End If

            Return New EnrollEstatementsResponse With
                   {
                       .Header = Map(response.Header),
                       .Fields = Map(response.Response)
                   }
        End Function

        Shared Function Map(response As CoreLiveResponseDao) As CoreLiveResponseDC
            If response Is Nothing Then
                Return Nothing
            End If

            Return New CoreLiveResponseDC With
                   {
                       .Status = response.Status,
                       .InformationalText = response.InformationalText
                   }
        End Function

        Shared Function Map(request As EnrollEstatementsRequest) As EnrollEstatementsRequestWrap
            If request Is Nothing Then
                Return Nothing
            End If

            Return New EnrollEstatementsRequestWrap With
                   {
                       .Header = Map(request.Header),
                       .Request = Map(request.Fields)
                   }
        End Function

        Shared Function Map(request As EnrollEstatementsRequestFields) As AccountEnrollmentDao
            If request Is Nothing Then
                Return Nothing
            End If

            Return New AccountEnrollmentDao With
                   {
                       .AccountId = request.AccountId,
                       .CompanyId = request.CompanyId,
                       .EStatementPreference = request.EStatementPreference
                   }
        End Function

        Shared Function Map(request As ProfileUpdateRequestDC) As ProfileUpdateRequestWrap
            If request Is Nothing Then
                Return Nothing
            End If

            Return New ProfileUpdateRequestWrap With
                   {
                       .Header = Map(request.Header),
                       .Request = Map(request.Fields)
                   }
        End Function

        Shared Function Map(response As ProfileUpdateResponseWrap) As ProfileUpdateResponseDC
            If response Is Nothing Then
                Return Nothing
            End If

            Return New ProfileUpdateResponseDC With
                   {
                       .Header = Map(response.Header),
                       .Fields = Map(response.Response)
                   }
        End Function

        Shared Function Map(request As ProfileUpdateRequestFields) As ProfileUpdateRequestDao
            If request Is Nothing Then
                Return Nothing
            End If

            Return New ProfileUpdateRequestDao With
                   {
                       .Profile = Map(request.Profile)
                   }
        End Function

        Shared Function Map(request As UserProfileDC) As UserProfileDao
            If request Is Nothing Then
                Return Nothing
            End If

            Return New UserProfileDao With
                   {
                       .AccountEnrollment = Map(request.AccountEnrollment),
                       .UserSettings = Map(request.UserSettings)
                   }
        End Function

        Shared Function Map(response As ResponseDao) As ResponseDC
            If response Is Nothing Then
                Return Nothing
            End If

            Return New ResponseDC With
                   {
                       .ConfirmationNumber = response.ConfirmationNumber,
                       .InformationalText = response.InformationalText,
                       .Status = response.Status
                   }
        End Function

        Shared Function Map(accountEnrollments As List(Of AccountEnrollmentDC)) As IEnumerable(Of AccountEnrollmentDao)
            If accountEnrollments Is Nothing Then
                Return Nothing
            End If

            Return (From accountEnrollment As AccountEnrollmentDC In accountEnrollments
                    Select Map(accountEnrollment)).ToList
        End Function

        Shared Function Map(request As AccountEnrollmentDC) As AccountEnrollmentDao
            If request Is Nothing Then
                Return Nothing
            End If

            Return New AccountEnrollmentDao With
                   {
                       .AccountId = request.AccountId,
                       .CompanyId = request.CompanyId,
                       .EStatementPreference = request.EStatementPreference
                   }
        End Function

        Shared Function Map(request As UserSettingsDC) As UserSettingsDao
            If request Is Nothing Then
                Return Nothing
            End If

            Return New UserSettingsDao With
                   {
                       .BillPayStatus = request.BillPayStatus,
                       .BillPaySubscriberId = request.BillPaySubscriberId,
                       .DateOfBirth = request.DateOfBirth,
                       .EmailOptOut = request.EmailOptOut,
                       .Gender = request.Gender,
                       .Mobile = request.Mobile,
                       .Person = Map(request.Person)
                   }
        End Function

        Shared Function Map(request As PersonDC) As PersonDao
            If request Is Nothing Then
                Return Nothing
            End If

            Return New PersonDao With
                   {
                       .AlternateEmail = request.AlternateEmail,
                       .Employee = request.Employee,
                       .FirstName = request.FirstName,
                       .HomePhone = request.HomePhone,
                       .LastName = request.LastName,
                       .MailingAddress = Map(request.MailingAddress),
                       .MiddleName = request.MiddleName,
                       .MobilePhone = request.MobilePhone,
                       .PhysicalAddress = Map(request.PhysicalAddress),
                       .PrimaryEmail = request.PrimaryEmail,
                       .WorkPhone = request.WorkPhone
                   }
        End Function

        Shared Function Map(request As AddressDC) As AddressDao
            If request Is Nothing Then
                Return Nothing
            End If

            Return New AddressDao With
                   {
                       .Address1 = request.Address1,
                       .Address2 = request.Address2,
                       .Address3 = request.Address3,
                       .Address4 = request.Address4,
                       .City = request.City,
                       .CountryCode = request.CountryCode,
                       .Latitude = request.Latitude,
                       .Longitude = request.Longitude,
                       .PostalCode = request.PostalCode,
                       .State = request.State
                   }
        End Function

        Shared Function Map(response As OnDemandResponseWrap) As OnDemandResponseDC
            If response Is Nothing Then
                Return Nothing
            End If

            Return New OnDemandResponseDC With
                   {
                       .Header = Map(response.Header),
                       .Fields = Map(response.Response)
                   }
        End Function

        Shared Function Map(request As OnDemandRequestDC) As OnDemandRequestWrap
            If request Is Nothing Then
                Return Nothing
            End If

            Return New OnDemandRequestWrap With
                   {
                       .Header = Map(request.Header),
                       .Request = Map(request.Fields)
                   }
        End Function

        Shared Function Map(request As OnDemandRequestFields) As OnDemandRequestDao
            If request Is Nothing Then
                Return Nothing
            End If

            Return New OnDemandRequestDao With
                   {
                       .EchoToken = request.EchoToken
                   }
        End Function

        Shared Function Map(response As AsyncResponseDao) As AsyncResponseDC
            If response Is Nothing Then
                Return Nothing
            End If

            Return New AsyncResponseDC With
                   {
                       .Status = response.Status,
                       .InformationalText = response.InformationalText,
                       .Payload = response.Payload
                   }
        End Function

        Shared Function Map(request As IntraDayResponseWrap) As IntraDayResponse
            If request Is Nothing Then
                Return Nothing
            End If

            Return New IntraDayResponse With
                    {
                        .Header = Map(request.Header),
                        .Fields = Map(request.Response)
                    }
        End Function

        Shared Function Map(request As IntraDayRequestDC) As IntraDayRequestWrap
            If request Is Nothing Then
                Return Nothing
            End If

            Return New IntraDayRequestWrap With
                    {
                        .Header = Map(request.Header),
                        .Request = Map(request.Fields)
                    }
        End Function

        Shared Function Map(request As IntraDayRequestFields) As IntraDayRequestDao
            If request Is Nothing Then
                Return Nothing
            End If

            Return New IntraDayRequestDao With
                    {
                        .DateRange = Map(request.DateRange),
                        .EchoToken = request.EchoToken
                    }
        End Function

        Shared Function Map(request As DateRangeDC) As DateRangeDao
            If request Is Nothing Then
                Return Nothing
            End If

            Return New DateRangeDao With
                    {
                        .Begin = request.Begin,
                        .End = request.End
                    }
        End Function

        Shared Function Map(request As TransferRequestDC) As TransferRequestWrap
            If request Is Nothing Then
                Return Nothing
            End If

            ' Only allow one type of transfer

            If request.Fields IsNot Nothing AndAlso request.Fields.FromAccount IsNot Nothing Then
                Return New TransferRequestWrap With
                    {
                        .Header = Map(request.Header),
                        .Request = Map(request.Fields)
                    }
            ElseIf request.OnUsRequestFields IsNot Nothing AndAlso request.OnUsRequestFields.FromAccount IsNot Nothing Then
                Return New TransferRequestWrap With
                    {
                        .Header = Map(request.Header),
                        .OnUsRequest = Map(request.OnUsRequestFields)
                    }
            Else
                Return Nothing
            End If

        End Function

        Shared Function Map(request As TransferResponseWrap) As TransferResponseDC
            If request Is Nothing Then
                Return Nothing
            End If

            Return New TransferResponseDC With
                    {
                        .Header = Map(request.Header),
                        .Fields = Map(request.Response),
                        .OnUsFields = Map(request.OnUsResponse)
                    }
        End Function

        Shared Function Map(header As HeaderDC) As HeaderDao
            If header Is Nothing Then
                Return Nothing
            End If

            Return New HeaderDao With {.Version = header.Version,
                                       .RequestId = header.RequestId,
                                       .Authentication = Map(header.Authentication),
                                       .UserId = header.UserId}
        End Function

        Shared Function Map(header As HeaderDao) As HeaderDC
            If header Is Nothing Then
                Return Nothing
            End If

            Return New HeaderDC With {.Version = header.Version,
                                      .RequestId = header.RequestId,
                                      .Authentication = Map(header.Authentication),
                                      .UserId = header.UserId}
        End Function

        Shared Function Map(authentication As AuthenticationDC) As AuthenticationDao
            If authentication Is Nothing Then
                Return Nothing
            End If

            Return New AuthenticationDao With {.UserName = authentication.UserName,
                                               .Password = authentication.Password}
        End Function

        Shared Function Map(authentication As AuthenticationDao) As AuthenticationDC
            If authentication Is Nothing Then
                Return Nothing
            End If

            Return New AuthenticationDC With {.UserName = authentication.UserName,
                                              .Password = authentication.Password}
        End Function

        Shared Function Map(request As TransferRequestFields) As TransferRequestDao
            If request Is Nothing Then
                Return Nothing
            End If

            Return New TransferRequestDao With {.FromAccount = request.FromAccount,
                                                .ToAccount = request.ToAccount,
                                                .Memo = request.Memo,
                                                .FromAccountCurrencyCode = request.FromAccountCurrencyCode,
                                                .ToAccountCurrencyCode = request.ToAccountCurrencyCode,
                                                .Date = request.Date,
                                                .Amount = request.Amount}
        End Function

        Shared Function Map(request As TransferOnUsRequestFields) As TransferOnUsRequestDao
            If request Is Nothing Then
                Return Nothing
            End If

            Return New TransferOnUsRequestDao With {.FromAccount = request.FromAccount,
                                                    .ToName = request.ToName,
                                                    .ToAccountNumber = request.ToAccountNumber,
                                                    .ToRoutingNumber = request.ToRoutingNumber,
                                                    .Memo = request.Memo,
                                                    .FromAccountCurrencyCode = request.FromAccountCurrencyCode,
                                                    .Date = request.Date,
                                                    .Amount = request.Amount}
        End Function

        Private Shared Function Map(request As TransferResponseDao) As TransferResponseFields
            If request Is Nothing Then
                Return Nothing
            End If

            Return New TransferResponseFields With {.FromAccountAvailableBalance = request.FromAccountAvailableBalance,
                                                    .ToAccountAvailableBalance = request.ToAccountAvailableBalance,
                                                    .ConfirmationNumber = request.ConfirmationNumber,
                                                    .Status = request.Status,
                                                    .InformationalText = request.InformationalText,
                                                    .Transactions = Map(request.Transactions)}
        End Function

        Private Shared Function Map(request As TransferOnUsResponseDao) As TransferOnUsResponseFields
            If request Is Nothing Then
                Return Nothing
            End If

            Return New TransferOnUsResponseFields With {.FromAccountAvailableBalance = request.FromAccountAvailableBalance,
                                                        .ConfirmationNumber = request.ConfirmationNumber,
                                                        .Status = request.Status,
                                                        .InformationalText = request.InformationalText,
                                                        .Transactions = Map(request.Transaction)}
        End Function

        Private Shared Function Map(transactions As IEnumerable(Of TransactionDao)) As List(Of TransactionDC)
            If transactions Is Nothing Then
                Return Nothing
            End If

            Return (From t As TransactionDao In transactions
                    Select New TransactionDC With
                           {
                               .Id = t.Id,
                               .AccountId = t.AccountId,
                               .Type = Map(t.Type),
                               .Amount = t.Amount,
                               .PostDate = t.PostDate,
                               .Pending = t.Pending,
                               .PostingSequence = t.PostingSequence,
                               .Name = t.Name
                           }).ToList
        End Function

        Private Shared Function Map(transaction As TransactionDao) As TransactionDC
            If transaction Is Nothing Then
                Return Nothing
            End If

            Return New TransactionDC With {.Id = transaction.Id,
                                           .AccountId = transaction.AccountId,
                                           .Type = Map(transaction.Type),
                                           .Amount = transaction.Amount,
                                           .PostDate = transaction.PostDate,
                                           .Pending = transaction.Pending,
                                           .PostingSequence = transaction.PostingSequence,
                                           .Name = transaction.Name}
        End Function

        Private Shared Function Map([type] As TransactionTypeDao) As TransactionTypeDC
            Select Case type
                Case TransactionTypeDao.c
                    Return TransactionTypeDC.Credit
                Case TransactionTypeDao.d
                    Return TransactionTypeDC.Debit
            End Select

            Return Nothing
        End Function
    End Class
End Namespace