﻿Imports System.Xml.Serialization

Namespace DataContract.CoreLive

    <XmlType("personType")>
    Public Class Person

        <XmlElement("frstName")>
        Public Property FirstName As String

        <XmlElement("midlName")>
        Public Property MiddleName As String

        <XmlElement("lastName")>
        Public Property LastName As String

        <XmlElement("priEmail")>
        Public Property PrimaryEmail As String

        <XmlElement("altEmail")>
        Public Property AlternateEmail As String

        <XmlElement("homePhon")>
        Public Property HomePhone As String

        <XmlElement("workPhon")>
        Public Property WorkPhone As String

        <XmlElement("moblPhon")>
        Public Property MobilePhone As String

        <XmlElement("emp")>
        Public Property Employee As String = "0"

        <XmlElement("priAddr")>
        Public Property PhysicalAddress As Address

        <XmlElement("mailAddr")>
        Public Property MailingAddress As Address
    End Class
End Namespace
