﻿Imports System.ServiceModel

Namespace DataContract.CoreLive
    <MessageContract(WrapperName:="enrollEstatements")>
    Public Class EnrollEstatementsRequest
        Inherits CoreLiveContract

        <MessageBodyMember(Name:="eStmtEnrlRqst")>
        Public Property Fields As EnrollEstatementsRequestFields
    End Class
End Namespace