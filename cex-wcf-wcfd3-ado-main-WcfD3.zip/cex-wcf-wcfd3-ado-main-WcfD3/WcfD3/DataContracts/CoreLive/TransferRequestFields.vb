﻿Imports System.Xml.Serialization

Namespace DataContract.CoreLive
    <XmlType("intlAcctFundXferRqst")>
    Public Class TransferRequestFields

        <XmlElement("fromAcctUid")>
        Public Property FromAccount As String

        <XmlElement("toAcctUid")>
        Public Property ToAccount As String

        <XmlElement("memo")>
        Public Property Memo As String

        <XmlElement("fromAcctCncyCode")>
        Public Property FromAccountCurrencyCode As String

        <XmlElement("toAcctCncyCode")>
        Public Property ToAccountCurrencyCode As String

        <XmlElement("date")>
        Public Property [Date] As Date

        <XmlElement("amt")>
        Public Property Amount As Decimal
    End Class
End Namespace

