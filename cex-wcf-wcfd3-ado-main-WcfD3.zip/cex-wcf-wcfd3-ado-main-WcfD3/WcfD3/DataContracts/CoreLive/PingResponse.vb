﻿Imports System.ServiceModel

Namespace DataContract.CoreLive
    <MessageContract(WrapperName:="pingResponse")>
    Public Class PingResponse
        Inherits CoreLiveContract

        <MessageBodyMember(Name:="pingResp")>
        Public Property Fields As CoreLiveResponse
    End Class
End Namespace