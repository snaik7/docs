﻿Imports System.Xml.Serialization

Namespace DataContract.CoreLive
    <XmlType("asyncResponseType")>
    Public Class AsyncResponse
        Inherits CoreLiveResponse

        <XmlElement("payload")>
        Public Property Payload As String
    End Class
End Namespace
