﻿Imports System.ServiceModel

Namespace DataContract.CoreLive
    <MessageContract(WrapperName:="initiateIntraDayResponse")>
    Public Class IntraDayResponse
        Inherits CoreLiveContract

        <MessageBodyMember(Name:="intraDayResp")>
        Public Property Fields As AsyncResponse
    End Class
End Namespace