﻿Imports System.Xml.Serialization

Namespace DataContract.CoreLive

    <XmlType("headerType")>
    Public Class Header

        <XmlElement("ver")>
        Public Property Version As String = "2.0"

        <XmlElement("rqstId")>
        Public Property RequestId As String

        <XmlElement("authn")>
        Public Property Authentication As Authentication

        <XmlElement("uid")>
        Public Property UserId As String
    End Class
End Namespace
