﻿Imports System.Xml.Serialization

Namespace DataContract.CoreLive
    Public Class StopPaymentRequestFields
        Inherits AccountRequest

        <XmlElement("memo")>
        Public Property Memo As String

        <XmlElement("txnType")>
        Public Property TransactionType As String

        <XmlElement("chekNbr")>
        Public Property CheckNumber As String

        <XmlElement("amt")>
        Public Property Amount As Decimal
    End Class
End Namespace