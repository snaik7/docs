﻿Imports System.Xml.Serialization

Namespace DataContract.CoreLive
    Public Class EnrollEstatementsRequestFields
        Inherits AccountRequest

        <XmlElement("eStmtPref")>
        Public Property EStatementPreference As String
    End Class
End Namespace