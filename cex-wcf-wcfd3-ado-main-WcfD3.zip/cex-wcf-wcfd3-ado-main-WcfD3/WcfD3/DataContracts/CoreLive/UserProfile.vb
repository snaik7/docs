﻿Imports System.Xml.Serialization
Imports System.Collections.Generic

Namespace DataContract.CoreLive
    Public Class UserProfile
        <XmlArray("acctEnrlLst")>
        <XmlArrayItem("acctEnrl")>
        Public Property AccountEnrollment As List(Of AccountEnrollment)

        <XmlElement("userSet")>
        Public Property UserSettings As UserSettings
    End Class
End Namespace