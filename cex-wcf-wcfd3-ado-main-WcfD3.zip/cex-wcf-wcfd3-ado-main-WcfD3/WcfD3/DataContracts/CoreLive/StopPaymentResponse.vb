﻿Imports System.ServiceModel

Namespace DataContract.CoreLive
    <MessageContract(WrapperName:="stopPaymentResponse")>
    Public Class StopPaymentResponse
        Inherits CoreLiveContract

        <MessageBodyMember(Name:="stopPmtResp")>
        Public Property Fields As Response
    End Class
End Namespace