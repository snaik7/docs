﻿Imports System.ServiceModel

Namespace DataContract.CoreLive
    <MessageContract(WrapperName:="enrollEstatementsResponse")>
    Public Class EnrollEstatementsResponse
        Inherits CoreLiveContract

        <MessageBodyMember(Name:="eStmtEnrlResp")>
        Public Property Fields As CoreLiveResponse
    End Class
End Namespace