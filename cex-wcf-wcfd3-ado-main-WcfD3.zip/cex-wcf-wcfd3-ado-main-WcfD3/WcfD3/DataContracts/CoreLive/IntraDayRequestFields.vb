﻿Imports System.Xml.Serialization

Namespace DataContract.CoreLive
    <XmlType("intraDayRqst")>
    Public Class IntraDayRequestFields
        <XmlElement("txnDateRang")>
        Public Property DateRange As DateRange

        <XmlElement("eTkn")>
        Public Property EchoToken As String
    End Class
End Namespace