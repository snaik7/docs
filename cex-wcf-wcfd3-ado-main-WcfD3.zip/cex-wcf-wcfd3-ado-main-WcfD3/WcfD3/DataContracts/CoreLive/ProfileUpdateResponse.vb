﻿Imports System.ServiceModel

Namespace DataContract.CoreLive
    <MessageContract(WrapperName:="updateProfileResponse")>
    Public Class ProfileUpdateResponse
        Inherits CoreLiveContract

        <MessageBodyMember(Name:="prflUpdtResp")>
        Public Property Fields As Response
    End Class
End Namespace

