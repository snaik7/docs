﻿Imports System.Xml.Serialization

Namespace DataContract.CoreLive
    Public Enum ItemChoice
        <XmlEnum("intlAcctFundXferResp")>
        IntlAcctFundXferResp

        <XmlEnum("intlAcctFundXferRqst")>
        IntlAcctFundXferRqst

        <XmlEnum("intraDayResp")>
        IntraDayResp

        <XmlEnum("intraDayRqst")>
        IntraDayRqst

        <XmlEnum("onDemandResp")>
        OnDemandResp

        <XmlEnum("onDemandRqst")>
        OnDemandRqst

        <XmlEnum("prflUpdtResp")>
        PrflUpdtResp

        <XmlEnum("prflUpdtRqst")>
        PrflUpdtRqst

        <XmlEnum("stopPmtResp")>
        StopPmtResp

        <XmlEnum("stopPmtRqst")>
        StopPmtRqst
    End Enum
End Namespace
