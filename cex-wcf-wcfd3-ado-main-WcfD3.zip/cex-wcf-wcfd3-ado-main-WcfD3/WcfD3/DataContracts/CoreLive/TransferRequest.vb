﻿Imports System.ServiceModel

Namespace DataContract.CoreLive
    <MessageContract(WrapperName:="transferFunds")>
    Public Class TransferRequest
        Inherits CoreLiveContract

        <MessageBodyMember(Name:="intlAcctFundXferRqst")>
        Public Property Fields As TransferRequestFields

        <MessageBodyMember(Name:="onUsXferRqst")>
        Public Property OnUsRequestFields As TransferOnUsRequestFields
    End Class
End Namespace