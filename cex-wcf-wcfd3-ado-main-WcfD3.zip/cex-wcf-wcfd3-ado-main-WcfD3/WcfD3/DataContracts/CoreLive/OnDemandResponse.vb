﻿Imports System.ServiceModel

Namespace DataContract.CoreLive
    <MessageContract(WrapperName:="initiateOnDemandResponse")>
    Public Class OnDemandResponse
        Inherits CoreLiveContract

        <MessageBodyMember(Name:="onDemandResp")>
        Public Property Fields As AsyncResponse
    End Class
End Namespace
