﻿Imports System.Xml.Serialization

Namespace DataContract.CoreLive
    <XmlType("transactionType")>
    Public Class Transaction
        <XmlElement("uid")>
        Property Id As String

        <XmlElement("acctUid")>
        Property AccountId As String

        <XmlElement("type")>
        Property [Type] As TransactionType

        <XmlElement("amt")>
        Property Amount As Decimal

        <XmlElement("postDate")>
        Property PostDate As Date

        <XmlElement("pndg")>
        Property Pending As Integer

        <XmlElement("postSeq")>
        Property PostingSequence As Integer

        <XmlElement("name")>
        Property Name As String
    End Class
End Namespace

