﻿Imports System.ServiceModel

Namespace DataContract.CoreLive
    <MessageContract(WrapperName:="transferFundsResponse")>
    Public Class TransferResponse
        Inherits CoreLiveContract

        <MessageBodyMember(Name:="intlAcctFundXferResp")>
        Public Property Fields As TransferResponseFields

        <MessageBodyMember(Name:="onUsXferResp")>
        Public Property OnUsFields As TransferOnUsResponseFields

    End Class
End Namespace
