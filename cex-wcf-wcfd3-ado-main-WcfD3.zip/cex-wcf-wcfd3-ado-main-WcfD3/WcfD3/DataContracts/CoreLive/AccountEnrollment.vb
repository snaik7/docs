﻿Imports System.Xml.Serialization

Namespace DataContract.CoreLive
    Public Class AccountEnrollment
        <XmlAttribute("acctUid")>
        Public Property AccountId As String

        <XmlAttribute("compUid")>
        Public Property CompanyId As String

        <XmlElement("eStmtPref")>
        Public Property EStatementPreference As String
    End Class
End Namespace
