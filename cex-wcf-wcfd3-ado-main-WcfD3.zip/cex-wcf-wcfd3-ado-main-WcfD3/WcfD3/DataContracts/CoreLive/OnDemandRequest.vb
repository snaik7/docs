﻿Imports System.ServiceModel

Namespace DataContract.CoreLive
    <MessageContract(WrapperName:="initiateOnDemand")>
    Public Class OnDemandRequest
        Inherits CoreLiveContract

        <MessageBodyMember(Name:="onDemandRqst")>
        Public Property Fields As OnDemandRequestFields
    End Class
End Namespace
