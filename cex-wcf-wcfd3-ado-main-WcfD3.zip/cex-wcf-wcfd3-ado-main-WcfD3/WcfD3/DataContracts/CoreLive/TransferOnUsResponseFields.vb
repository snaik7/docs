﻿Imports System.Xml.Serialization

Namespace DataContract.CoreLive
    <XmlType("onUsXferResp")>
    Public Class TransferOnUsResponseFields
        Inherits Response

        <XmlElement("fromAcctAvblBal")>
        Public Property FromAccountAvailableBalance As Decimal?

        <XmlElement("txn")>
        Public Property Transactions As Transaction
    End Class
End Namespace