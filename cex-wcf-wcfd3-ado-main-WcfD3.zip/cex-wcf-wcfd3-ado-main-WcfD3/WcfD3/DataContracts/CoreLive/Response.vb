﻿Imports System.Xml.Serialization

Namespace DataContract.CoreLive
    <XmlType("responseType")>
    Public Class Response
        Inherits CoreLiveResponse

        <XmlElement("cnfmNbr")>
        Public Property ConfirmationNumber As String
    End Class
End Namespace
