﻿Imports System.Xml.Serialization

Namespace DataContract.CoreLive
    <XmlType("authenticationType")>
    Public Class Authentication

        <XmlAttribute("userName")>
        Public Property UserName As String

        <XmlAttribute("pswd")>
        Public Property Password As String
    End Class
End Namespace

