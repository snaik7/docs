﻿Imports System.Xml.Serialization

Namespace DataContract.CoreLive
    <XmlType("userSet")>
    Public Class UserSettings
        <XmlElement("bpStat")>
        Public Property BillPayStatus As String

        <XmlElement("bpId")>
        Public Property BillPaySubscriberId As String

        <XmlElement("dob")>
        Public Property DateOfBirth As Date

        <XmlElement("emlOpt")>
        Public Property EmailOptOut As String = "0"

        <XmlElement("gndr")>
        Public Property Gender As String

        <XmlElement("mobl")>
        Public Property Mobile As String = "0"

        <XmlElement("pers")>
        Public Property Person As Person
    End Class
End Namespace
