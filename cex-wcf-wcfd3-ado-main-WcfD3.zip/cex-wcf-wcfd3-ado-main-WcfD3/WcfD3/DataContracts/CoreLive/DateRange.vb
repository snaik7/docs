﻿Imports System.Xml.Serialization

Namespace DataContract.CoreLive
    <XmlType("txnDateRangType")>
    Public Class DateRange
        <XmlAttribute("begnDate")>
        Public Property Begin As Date

        <XmlAttribute("endDate")>
        Public Property [End] As Date
    End Class
End Namespace
