﻿Imports System.Xml.Serialization

Namespace DataContract.CoreLive

    <XmlType("addressType")>
    Public Class Address

        <XmlElement("addr1")>
        Public Property Address1 As String

        <XmlElement("addr2")>
        Public Property Address2 As String

        <XmlElement("addr3")>
        Public Property Address3 As String

        <XmlElement("addr4")>
        Public Property Address4 As String

        <XmlElement("city")>
        Public Property City As String

        <XmlElement("st")>
        Public Property State As String

        <XmlElement("pstlCode")>
        Public Property PostalCode As String

        <XmlElement("ctryCode")>
        Public Property CountryCode As String = "US"

        <XmlElement("lat")>
        Public Property Latitude As Decimal

        <XmlElement("lon")>
        Public Property Longitude As Decimal
    End Class
End Namespace