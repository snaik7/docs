﻿Imports System.ServiceModel

Namespace DataContract.CoreLive
    <MessageContract(WrapperName:="initiateIntraDay")>
    Public Class IntraDayRequest
        Inherits CoreLiveContract

        <MessageBodyMember(Name:="intraDayRqst")>
        Public Property Fields As IntraDayRequestFields
    End Class
End Namespace