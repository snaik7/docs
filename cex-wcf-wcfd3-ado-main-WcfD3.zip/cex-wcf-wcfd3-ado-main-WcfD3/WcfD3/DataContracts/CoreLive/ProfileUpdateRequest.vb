﻿Imports System.ServiceModel

Namespace DataContract.CoreLive
    <MessageContract(WrapperName:="updateProfile")>
    Public Class ProfileUpdateRequest
        Inherits CoreLiveContract

        <MessageBodyMember(Name:="prflUpdtRqst")>
        Public Property Fields As ProfileUpdateRequestFields
    End Class
End Namespace