﻿Imports System.ServiceModel

Namespace DataContract.CoreLive
    <MessageContract(WrapperName:="stopPayment")>
    Public Class StopPaymentRequest
        Inherits CoreLiveContract

        <MessageBodyMember(Name:="stopPmtRqst")>
        Public Property Fields As StopPaymentRequestFields
    End Class
End Namespace
