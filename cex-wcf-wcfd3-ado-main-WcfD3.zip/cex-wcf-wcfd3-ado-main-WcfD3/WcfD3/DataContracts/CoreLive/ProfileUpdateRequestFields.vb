﻿Imports System.Xml.Serialization

Namespace DataContract.CoreLive
    Public Class ProfileUpdateRequestFields
        <XmlElement("userPrfl")>
        Public Property Profile As UserProfile
    End Class
End Namespace