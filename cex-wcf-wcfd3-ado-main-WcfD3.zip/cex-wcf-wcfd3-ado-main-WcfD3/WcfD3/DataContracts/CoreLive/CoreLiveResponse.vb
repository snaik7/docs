﻿Imports System.Xml.Serialization

Namespace DataContract.CoreLive
    Public Class CoreLiveResponse
        <XmlElement("stat")>
        Public Property Status As Integer

        <XmlElement("infoText")>
        Public Property InformationalText As String
    End Class
End Namespace