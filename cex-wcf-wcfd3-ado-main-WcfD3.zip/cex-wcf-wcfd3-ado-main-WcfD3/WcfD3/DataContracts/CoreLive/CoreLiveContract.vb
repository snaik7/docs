﻿Imports System.ServiceModel

Namespace DataContract.CoreLive
    <MessageContract()>
    Public Class CoreLiveContract

        <MessageBodyMember(Name:="hdr")>
        Public Property Header As Header
    End Class
End Namespace