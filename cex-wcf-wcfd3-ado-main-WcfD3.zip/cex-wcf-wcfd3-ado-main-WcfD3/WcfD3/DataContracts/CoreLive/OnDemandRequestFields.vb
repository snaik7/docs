﻿Imports System.Xml.Serialization

Namespace DataContract.CoreLive
    Public Class OnDemandRequestFields
        <XmlElement("eTkn")>
        Public Property EchoToken As String
    End Class
End Namespace