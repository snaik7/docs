﻿Imports Arvest.WCF.D3.DataContract
Imports System.Runtime.Serialization

Public Class D3RegistrationRequest
    Inherits D3AdminRequest

    Private Const CsrService As String = "CSR"

    <DataMember()>
    Public Property TempPassword As String

    Protected Overrides Sub SetDefaults()
        MyBase.SetDefaults()

        Service = CsrService
        [Function] = MapRemove
    End Sub
End Class