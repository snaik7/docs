﻿Imports Arvest.Common
Imports System.ServiceModel
Imports System.Runtime.Serialization
Imports System.Collections.Generic

Namespace DataContract
    <DataContract()>
    Public Class D3AdminResponse

        Private _message As String

        Protected Const _successfulTranCode As String = "000"
        Protected Const _successfulTran As String = "Successful transaction."
        Protected Const _invalidAxmId As String = "Empty or invalid AxmId."
        Protected Const _invalidAxmIdCode As String = "210"
        Protected Const _invalidTaxId As String = "Empty or invalid TIN."
        Protected Const _invalidTaxIdCode As String = "220"
        Protected Const _invalidAccounts As String = "No accounts received, OR empty or invalid Account Number for one of the received accounts."
        Protected Const _invalidAccountsCode As String = "230"
        Protected Const _invalidAxmLogin As String = "Empty or invalid AxM Login ID."
        Protected Const _invalidAxmLoginCode As String = "240"
        Protected Const _invalidLockoutReason As String = "No lockout reason specified for a lock action."
        Protected Const _invalidLockoutReasonCode As String = "250"
        Protected Const _invalidPasswordCode As String = "260"
        Protected Const _invalidPassword As String = "Invald or empty temporary password."
        Protected Const _emptyCsrId As String = "No CSR Id specified for CSR action."
        Protected Const _emptyCsrIdCode As String = "260"
        Protected Const _emptyLoginId As String = "No Login Id specified for D3 registration."
        Protected Const _emptyLoginIdCode As String = "261"
        Protected Const _emptyDomain As String = "No Domain specified for CSR authorization."
        Protected Const _emptyDomainCode As String = "270"
        Protected Const _emptyUser As String = "No User specified for CSR authorization."
        Protected Const _emptyUserCode As String = "280"
        Protected Const _notRegisteredInD3 As String = "Customer is not enrolled in D3."
        Protected Const _notRegisteredInD3Code As String = "290"
        Protected Const _optOutOfD3Code As String = "291"
        Protected Const _optOutOfD3 As String = "Customer has opted out of D3 service."
        Protected Const _RegisteredInD3 As String = "Customer is enrolled in D3."
        Protected Const _RegisteredInD3Code As String = "300"
        Protected Const _invalidTaxIdType As String = "Empty or invalid TIN Type."
        Protected Const _invalidTaxIdTypeCode As String = "320"
        Protected Const _successfulD3Auth As String = "Authorization successful."
        Protected Const _successfulD3AuthCode As String = "400"
        Protected Const _successfulD3Reg As String = "Registration successful."
        Protected Const _successfulD3RegCode As String = "100"
        Protected Const _successfulD3Unreg As String = "Unenrollment successful."
        Protected Const _successfulD3UnregCode As String = "101"
        Protected Const _failedD3Unreg As String = "Unenrollment failed."
        Protected Const _failedD3UnregCode As String = "110"
        Protected Const _successfulPasswordReset As String = "Reset password successful."
        Protected Const _successfulPasswordResetCode As String = "600"
        Protected Const _passwordReusedOnReset As String = "User's password has already been reset."
        Protected Const _passwordReusedOnResetCode As String = "601"
        Protected Const _successfulD3Unlock As String = "Unlock D3 account successful."
        Protected Const _successfulD3UnlockCode As String = "700"
        Protected Const _successfulD3Lock As String = "Lock D3 account successful."
        Protected Const _successfulD3LockCode As String = "800"
        Protected Const _d3AccountLocked As String = "D3 account is locked."
        Protected Const _d3AccountLockedCode As String = "801"
        Protected Const _d3AccountUnlocked As String = "D3 account is unlocked."
        Protected Const _d3AccountUnlockedCode As String = "802"
        Protected Const _d3AccountLockedDefault As String = "D3 account is locked due to expired default password."
        Protected Const _d3AccountLockedDefaultCode As String = "803"
        Protected Const _D3ExceptionCode As String = "510"
        Protected Const _hostErrorCode As String = "520"
        Protected Const _successfulSearch As String = "Search successful."
        Protected Const _successfulSearchCode As String = "900"
        Protected Const _registrationFromS1Fail As String = "User cannot be registered; they are scheduled for migration on the following date: {0}"
        Protected Const _registrationFromS1FailCode As String = "102"

        <DataMember()>
        Public Property Service As String

        <DataMember()>
        <XmlSerializeOptions(tagName:="TimeStamp")>
        Public Property Timestamp As String

        <DataMember()>
        <XmlSerializeOptions(tagName:="ReturnCode")>
        Public Property Code As String

        <DataMember()>
        Public Property Success As Boolean

        <DataMember()>
        Public Property SessionId As String

        <DataMember()>
        Public Property AxmId As String

        Public Property [Function] As String

        <DataMember()>
        Public Property AcctStatus As String

        <DataMember()>
        <XmlSerializeOptions(tagName:="ErrorDescription")>
        Public Property Message As String
            Get
                Return _message
            End Get
            Set(value As String)
                If value = "SUCCESS" Then
                    Success = True
                    Code = "000"
                Else
                    Code = "020"
                    Success = False
                End If
                _message = value
            End Set
        End Property

        Friend Shared Function Create(Of T As {D3AdminResponse, New})(ByVal errorCode As String, ByVal message As String, ByVal success As Boolean) As T
            Return New T With {.Message = message,
                               .Code = errorCode,
                               .Success = success}
        End Function

        Friend Shared Function CreateSuccess(ByVal errorCode As String, ByVal message As String) As D3AdminResponse
            Return CreateSuccess(Of D3AdminResponse)(errorCode, message)
        End Function

        Friend Shared Function CreateSuccess(Of T As {D3AdminResponse, New})(ByVal errorCode As String, ByVal message As String) As T
            Return Create(Of T)(errorCode, message, True)
        End Function

        Friend Shared Function CreateError(ByVal errorCode As String, ByVal message As String) As D3AdminResponse
            Return CreateError(Of D3AdminResponse)(errorCode, message)
        End Function

        Friend Shared Function CreateError(Of T As {D3AdminResponse, New})(ByVal errorCode As String, ByVal message As String) As T
            Return Create(Of T)(errorCode, message, False)
        End Function

        Friend Shared Function CreateError(ByVal ex As Exception, ByVal log As ArvestTraceSource) As D3AdminResponse
            Return CreateError(Of D3AdminResponse)(ex, log)
        End Function

        Friend Shared Function CreateError(Of T As {D3AdminResponse, New})(ByVal ex As Exception, ByVal log As ArvestTraceSource) As T
            log.TraceError(ex.GetStackTraces)

            Return CreateError(Of T)(_D3ExceptionCode, ex.GetMessages)
        End Function

        Friend Shared Function CreateHostError(Of T As {D3AdminResponse, New})(ByVal hostMessage As String) As T
            Return CreateError(Of T)(_hostErrorCode, hostMessage)
        End Function

        Friend Shared ReadOnly Property Successful As D3AdminResponse
            Get
                Return CreateSuccess(_successfulTranCode, _successfulTran)
            End Get
        End Property

        Friend Shared ReadOnly Property InvalidAxMId As D3AdminResponse
            Get
                Return CreateError(_invalidAxmIdCode, _invalidAxmId)
            End Get
        End Property

        Friend Shared ReadOnly Property InvalidTin As D3AdminResponse
            Get
                Return CreateError(_invalidTaxIdCode, _invalidTaxId)
            End Get
        End Property

        Friend Shared ReadOnly Property InvalidAxmLoginId As D3AdminResponse
            Get
                Return CreateError(_invalidAxmLoginCode, _invalidAxmLogin)
            End Get
        End Property

        Friend Shared ReadOnly Property EmptyLockoutReason As D3AdminResponse
            Get
                Return CreateError(_invalidLockoutReasonCode, _invalidLockoutReason)
            End Get
        End Property

        Friend Shared ReadOnly Property EmptyCsrId As D3AdminResponse
            Get
                Return CreateError(_emptyCsrIdCode, _emptyCsrId)
            End Get
        End Property

        Friend Shared ReadOnly Property EmptyLoginId As D3AdminResponse
            Get
                Return CreateError(_emptyLoginIdCode, _emptyLoginId)
            End Get
        End Property

        Friend Shared ReadOnly Property RegisteredInD3 As D3AdminResponse
            Get
                Return CreateSuccess(_RegisteredInD3Code, _RegisteredInD3)
            End Get
        End Property

        Friend Shared ReadOnly Property NotRegisteredInD3 As D3AdminResponse
            Get
                Return CreateError(_notRegisteredInD3Code, _notRegisteredInD3)
            End Get
        End Property

        Friend Shared ReadOnly Property InvalidTinType As D3AdminResponse
            Get
                Return CreateError(_invalidTaxIdTypeCode, _invalidTaxIdType)
            End Get
        End Property

        Friend Shared ReadOnly Property RegistrationSuccessful As D3AdminResponse
            Get
                Return CreateSuccess(_successfulD3RegCode, _successfulD3Reg)
            End Get
        End Property

        Friend Shared ReadOnly Property ResetPasswordSuccessful As D3AdminResponse
            Get
                Return CreateSuccess(_successfulPasswordResetCode, _successfulPasswordReset)
            End Get
        End Property

        Friend Shared ReadOnly Property UnlockD3Successful As D3AdminResponse
            Get
                Return CreateSuccess(_successfulD3UnlockCode, _successfulD3Unlock)
            End Get
        End Property

        Friend Shared ReadOnly Property LockD3Successful As D3AdminResponse
            Get
                Return CreateSuccess(_successfulD3LockCode, _successfulD3Lock)
            End Get
        End Property

        Friend Shared ReadOnly Property UnenrollmentSuccessful As D3AdminResponse
            Get
                Return CreateSuccess(_successfulD3UnregCode, _successfulD3Unreg)
            End Get
        End Property

        Friend Shared ReadOnly Property UnenrollmentFailed As D3AdminResponse
            Get
                Return CreateError(_failedD3UnregCode, _failedD3Unreg)
            End Get
        End Property

        Friend Shared ReadOnly Property EmptyTempPassword As D3AdminResponse
            Get
                Return CreateError(_invalidPasswordCode, _invalidPassword)
            End Get
        End Property

        Friend Shared ReadOnly Property CustomerOptOut As D3AdminResponse
            Get
                Return CreateSuccess(_optOutOfD3Code, _optOutOfD3)
            End Get
        End Property

        Friend Shared ReadOnly Property RegistrationFromS1Fail(ByVal migrationDate As String) As D3AdminResponse
            Get
                Return CreateError(_registrationFromS1FailCode, String.Format(_registrationFromS1Fail, migrationDate))
            End Get
        End Property

        Friend Shared ReadOnly Property ReusedPasswordOnReset As D3AdminResponse
            Get
                Return CreateError(_passwordReusedOnResetCode, _passwordReusedOnReset)
            End Get
        End Property
    End Class
End Namespace
