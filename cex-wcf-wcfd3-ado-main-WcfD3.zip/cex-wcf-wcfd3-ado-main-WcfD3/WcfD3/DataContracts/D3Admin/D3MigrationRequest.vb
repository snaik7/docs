﻿Imports System.Collections.Generic
Imports System.Runtime.Serialization

Imports Arvest.Common

Imports Arvest.WCF.D3.DataContract

Public Class D3MigrationRequest
    Inherits D3AdminRequest

    Protected Overrides Sub SetDefaults()
        MyBase.SetDefaults()

        [Function] = MapMigrate
    End Sub

    <DataMember()>
    <XmlSerializeOptions(Omit:=True)>
    Property S1PasswordExpiredFlag As Boolean

    <DataMember()>
    <XmlSerializeOptions(Omit:=True)>
    Property OverwriteFlag As Boolean

    <DataMember()>
    <XmlSerializeOptions(Omit:=True)>
    Property S1PasswordHash As String

    <DataMember()>
    Property RegisteredAccounts As IEnumerable(Of Account)

    <DataMember()>
    <XmlSerializeOptions(Omit:=True)>
    Property TargetAxmGroup As String

    <DataMember()>
    Property MigrationDate As String

    <DataMember()>
    Property AdaptiveAuthId As String

End Class