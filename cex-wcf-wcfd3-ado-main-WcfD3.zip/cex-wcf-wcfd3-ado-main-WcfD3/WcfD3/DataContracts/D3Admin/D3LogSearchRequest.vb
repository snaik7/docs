﻿Imports System.Runtime.Serialization
Imports System.ServiceModel
Imports System.Collections.Generic
Imports Arvest.Common

Namespace DataContract
    <DataContract()>
    Public Class D3LogSearchRequest
        Inherits D3AdminRequest

        <DataMember()>
        Property SearchCSRId As String

        <DataMember()>
        Property SearchAxmId As String

        <DataMember()>
        Property StartDt As DateTime

        <DataMember()>
        Property EndDt As DateTime

        <DataMember()>
        Property CustomerId As String

        <DataMember()>
        Property ActionType As D3Action

    End Class
End Namespace