﻿Imports Arvest.Common
Imports System.ServiceModel
Imports System.Runtime.Serialization
Imports System.Collections.Generic

Namespace DataContract
    <DataContract()>
    Public Class GetD3PrivilegesResponse
        Inherits D3AdminResponse

        <DataMember()>
        Property Groups As IEnumerable(Of ApplicationGroup)
    End Class
End Namespace