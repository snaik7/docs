﻿Imports Arvest.Common
Imports System.Runtime.Serialization
Imports System.Collections.Generic

Namespace DataContract
    <DataContract()>
    Public Class AuthorizeCsrResponse
        Inherits D3AdminResponse

        <DataMember(Name:="Priviliges")>
        Property Privileges As IEnumerable(Of D3Action)

        Friend Shared Shadows Function CreateSuccess(ByVal ErrorCode As String, ByVal Message As String, ByVal Privileges As IEnumerable(Of D3Action)) As AuthorizeCsrResponse
            Return New AuthorizeCsrResponse With {.Message = Message,
                                                  .Code = ErrorCode,
                                                  .Success = True,
                                                  .Privileges = Privileges}
        End Function

        Friend Shared Shadows Function CreateError(ByVal ErrorCode As String, ByVal Message As String) As AuthorizeCsrResponse
            Return New AuthorizeCsrResponse With {.Message = Message,
                                                  .Code = ErrorCode,
                                                  .Success = False,
                                                  .Privileges = New List(Of D3Action)}
        End Function

        Friend Shared Shadows ReadOnly Property Successful As AuthorizeCsrResponse
            Get
                Return CreateSuccess(_successfulTranCode, _successfulTran, New List(Of D3Action))
            End Get
        End Property

        Friend Shared Shadows ReadOnly Property InvalidAxMId As AuthorizeCsrResponse
            Get
                Return CreateError(_invalidAxmIdCode, _invalidAxmId)
            End Get
        End Property

        Friend Shared Shadows ReadOnly Property InvalidTin As AuthorizeCsrResponse
            Get
                Return CreateError(_invalidTaxIdCode, _invalidTaxId)
            End Get
        End Property

        Friend Shared Shadows ReadOnly Property EmptyCsrId As AuthorizeCsrResponse
            Get
                Return CreateError(_emptyCsrIdCode, _emptyCsrId)
            End Get
        End Property

        Friend Shared ReadOnly Property EmptyDomain As AuthorizeCsrResponse
            Get
                Return CreateError(_emptyDomainCode, _emptyDomain)
            End Get
        End Property

        Friend Shared ReadOnly Property EmptyUserName As AuthorizeCsrResponse
            Get
                Return CreateError(_emptyUserCode, _emptyUser)
            End Get
        End Property

        Friend Shared ReadOnly Property AuthorizationSuccessful(ByVal Privileges As IEnumerable(Of D3Action)) As AuthorizeCsrResponse
            Get
                Return CreateSuccess(_successfulD3AuthCode, _successfulD3Auth, Privileges)
            End Get
        End Property
    End Class
End Namespace