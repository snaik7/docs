﻿Imports System.Runtime.Serialization

Namespace DataContract
    <DataContract()>
    Public Class D3PrivilegeRequest
        Inherits D3AdminRequest

        <DataMember()>
        Property SelectedPrivilege As D3Action

        <DataMember()>
        Property AdGroup As String

    End Class
End Namespace