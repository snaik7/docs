﻿Imports System.Runtime.Serialization
Imports Arvest.Common

Namespace DataContract
    <DataContract()>
    Public Class Account
        <DataMember()>
        <XmlSerializeOptions(TagName:="AxmAccount")>
        Property AccountNumber As String

        <DataMember()>
        <XmlSerializeOptions(TagName:="AxmActType")>
        Property AccountType As String

        <DataMember()>
        <XmlSerializeOptions(TagName:="AcctStatus")>
        Property AccountStatus As String

        <DataMember()>
        <XmlSerializeOptions(TagName:="AxmId")>
        Property AxmId As String

        <DataMember()>
        <XmlSerializeOptions(TagName:="AxmSSN")>
        Property AxmSSN As String

        <DataMember()>
        <XmlSerializeOptions(TagName:="AxmSSNType")>
        Property AxmSSNType As String

        <DataMember()>
        <XmlSerializeOptions(TagName:="EStmt")>
        Property Estmt As String
    End Class
End Namespace