﻿Imports System.Collections.Generic
Imports System.Runtime.Serialization

Imports Arvest.DataAccess.Camp.Dao

Namespace DataContract
    <DataContract()>
    Public Class D3LogSearchResponse
        Inherits D3AdminResponse

        <DataMember()>
        Property results As IEnumerable(Of LogSearchResults)

        Friend Shared Shadows Function Create(ByVal ErrorCode As String, ByVal Message As String, ByVal Success As Boolean) As D3LogSearchResponse
            Return New D3LogSearchResponse With {.Code = ErrorCode,
                                                .Message = Message,
                                                .Success = Success,
                                                .results = New List(Of LogSearchResults)}
        End Function

        Friend Shared Shadows Function CreateSuccess(ByVal ErrorCode As String, ByVal Message As String) As D3LogSearchResponse
            Return Create(ErrorCode, Message, True)
        End Function

        Friend Shared Shadows Function CreateError(ByVal ErrorCode As String, ByVal Message As String) As D3LogSearchResponse
            Return New D3LogSearchResponse With {.Code = ErrorCode,
                                                .Message = Message,
                                                .Success = False,
                                                .results = New List(Of LogSearchResults)}
        End Function

        Friend Shared Shadows ReadOnly Property EmptyCsrId As D3LogSearchResponse
            Get
                Return CreateError(_emptyCsrIdCode, _emptyCsrId)
            End Get
        End Property

        Friend Shared Shadows ReadOnly Property InvalidAxMId As D3LogSearchResponse
            Get
                Return CreateError(_invalidAxmIdCode, _invalidAxmId)
            End Get
        End Property

        Friend Shared ReadOnly Property SuccessfulSearch As D3LogSearchResponse
            Get
                Return CreateSuccess(_successfulSearchCode, _successfulSearch)
            End Get
        End Property
    End Class
End Namespace