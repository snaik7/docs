﻿Imports Arvest.Common
Imports System.ServiceModel
Imports System.Collections.Generic
Imports System.Runtime.Serialization

Namespace DataContract
    <DataContract()>
    Public Class D3RegistrationCheckResponse
        Inherits D3AdminResponse

        <DataMember()>
        Public Property D3UserName As String

        <DataMember()>
        Public Property MigrationDate As String

        Friend Shared Shadows ReadOnly Property RegisteredInD3 As D3RegistrationCheckResponse
            Get
                Return CreateSuccess(Of D3RegistrationCheckResponse)(_RegisteredInD3Code, _RegisteredInD3)
            End Get
        End Property

        Friend Shared Shadows ReadOnly Property NotRegisteredInD3 As D3RegistrationCheckResponse
            Get
                Return CreateError(Of D3RegistrationCheckResponse)(_notRegisteredInD3Code, _notRegisteredInD3)
            End Get
        End Property

        Friend Shared Shadows ReadOnly Property InvalidAxMId As D3RegistrationCheckResponse
            Get
                Return CreateError(Of D3RegistrationCheckResponse)(_invalidAxmIdCode, _invalidAxmId)
            End Get
        End Property

        Friend Shared Shadows ReadOnly Property EmptyCsrId As D3RegistrationCheckResponse
            Get
                Return CreateError(Of D3RegistrationCheckResponse)(_emptyCsrIdCode, _emptyCsrId)
            End Get
        End Property
    End Class
End Namespace