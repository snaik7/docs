﻿Imports Arvest.Common
Imports System.ServiceModel
Imports System.Collections.Generic
Imports System.Runtime.Serialization

Namespace DataContract
    <DataContract()>
    Public Class D3AccountResponse
        Inherits D3AdminResponse

        <DataMember()>
        <XmlSerializeOptions(tagName:="Accounts", ArrayElementName:="Account")>
        Public Property Accounts As IEnumerable(Of Account)

        Shared Shadows Function CreateError(ByVal ErrorCode As String, ByVal Message As String) As D3AccountResponse
            Return New D3AccountResponse With {.Code = ErrorCode,
                                                .Message = Message,
                                                .Success = False,
                                                .Accounts = New List(Of Account)}
        End Function

        Friend Shared Shadows ReadOnly Property InvalidAxMId As D3AccountResponse
            Get
                Return CreateError(_invalidAxmIdCode, _invalidAxmId)
            End Get
        End Property

        Friend Shared Shadows ReadOnly Property InvalidTin As D3AccountResponse
            Get
                Return CreateError(_invalidTaxIdCode, _invalidTaxId)
            End Get
        End Property

        Friend Shared Shadows ReadOnly Property NoAccounts As D3AccountResponse
            Get
                Return CreateError(_invalidAccountsCode, _invalidAccounts)
            End Get
        End Property

        Friend Shared Shadows ReadOnly Property EmptyCsrId As D3AccountResponse
            Get
                Return CreateError(_emptyCsrIdCode, _emptyCsrId)
            End Get
        End Property
    End Class
End Namespace