﻿Imports System.Runtime.Serialization
Imports Arvest.Common

Namespace DataContract
    <DataContract()>
    Public Class D3AdminRequest

        Friend Const MapRetrieve As String = "MAPRETRIEVE"
        Friend Const MapAdd As String = "MAPADD"
        Friend Const MapRemove As String = "MAPREMOVE"
        Friend Const MapRemoveAll As String = "MAPREMOVEALL"
        Friend Const MapMigrate As String = "MAPMIGRATE"
        Friend Const D3Service As String = "D3"

        <DataMember()>
        <XmlSerializeOptions(TagName:="AxmId")>
        Property AxmId As String

        <DataMember()>
        <XmlSerializeOptions(TagName:="SSN")>
        Property Tin As String

        <DataMember()>
        <XmlSerializeOptions(TagName:="SSNType")>
        Property TinType As String

        <XmlSerializeOptions(TagName:="Service")>
        Property Service As String

        <XmlSerializeOptions(TagName:="TimeStamp")>
        Property Timestamp As String

        Property [Function] As String

        <DataMember()>
        Property CsrId As String

        <DataMember()>
        Property AxmLoginId As String

        <DataMember()>
        <XmlSerializeOptions(Omit:=True)>
        Property ClientIp As String

        <DataMember()>
        <XmlSerializeOptions(Omit:=True)>
        Property ClientBrowserInfo As String

        Sub New()
            SetDefaults()
        End Sub

        Protected Overridable Sub SetDefaults()
            Service = D3Service
            Timestamp = Date.Now.ToString
        End Sub

        <OnDeserializing>
        Private Sub OnDeserializing(context As StreamingContext)
            SetDefaults()
        End Sub
    End Class
End Namespace