﻿Imports System.Runtime.Serialization

Namespace DataContract
    <DataContract()>
    Public Class D3LockAccountRequest
        Inherits D3AdminRequest

        <DataMember()>
        Property LockoutReason As String
    End Class
End Namespace