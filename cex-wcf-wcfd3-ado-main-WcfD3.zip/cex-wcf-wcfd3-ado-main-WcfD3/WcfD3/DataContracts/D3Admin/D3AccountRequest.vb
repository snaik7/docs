﻿Imports System.Collections.Generic
Imports System.Runtime.Serialization
Imports Arvest.Common

Namespace DataContract
    <DataContract()>
    Public Class D3AccountRequest
        Inherits D3AdminRequest

        <DataMember()>
        <XmlSerializeOptions(arrayElementName:="Account", tagName:="Accounts")>
        Property Accounts As IEnumerable(Of Account)

        Friend Function HasAccountData() As Boolean
            Return Accounts IsNot Nothing AndAlso
                   Accounts.Count > 0 AndAlso
                   Not Accounts.Any(Function(a As Account) String.IsNullOrEmpty(a.AccountNumber) OrElse String.IsNullOrEmpty(a.AccountType))
        End Function
    End Class
End Namespace