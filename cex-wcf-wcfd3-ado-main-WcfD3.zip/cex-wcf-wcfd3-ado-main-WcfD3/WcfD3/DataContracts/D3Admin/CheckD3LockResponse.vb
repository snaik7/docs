﻿Imports System.Runtime.Serialization

Namespace DataContract
    <DataContract()>
    Public Class CheckD3LockResponse
        Inherits D3AdminResponse

        <DataMember()>
        Property Locked As Boolean = False

        <DataMember()>
        Property LockoutReason As String

        Friend Shared ReadOnly Property D3AccountLocked As CheckD3LockResponse
            Get
                Dim out As CheckD3LockResponse = CreateSuccess(Of CheckD3LockResponse)(_d3AccountLockedCode, _d3AccountLocked)
                out.Locked = True
                Return out
            End Get
        End Property

        Friend Shared ReadOnly Property D3AccountLockedDefault(lockoutReason As String) As CheckD3LockResponse
            Get
                Dim out As CheckD3LockResponse = CreateSuccess(Of CheckD3LockResponse)(_d3AccountLockedDefaultCode, _d3AccountLockedDefault)
                out.LockoutReason = lockoutReason
                out.Locked = True
                Return out
            End Get
        End Property

        Friend Shared ReadOnly Property D3AccountUnlocked As CheckD3LockResponse
            Get
                Return CreateSuccess(Of CheckD3LockResponse)(_d3AccountUnlockedCode, _d3AccountUnlocked)
            End Get
        End Property

        Friend Shared Shadows ReadOnly Property InvalidAxmLoginId As CheckD3LockResponse
            Get
                Return CreateError(Of CheckD3LockResponse)(_invalidAxmLoginCode, _invalidAxmLogin)
            End Get
        End Property

        Friend Shared Shadows ReadOnly Property InvalidAxmId As CheckD3LockResponse
            Get
                Return CreateError(Of CheckD3LockResponse)(_invalidAxmLoginCode, _invalidAxmLogin)
            End Get
        End Property

        Friend Shared Shadows ReadOnly Property EmptyCsrId As CheckD3LockResponse
            Get
                Return CreateError(Of CheckD3LockResponse)(_emptyCsrIdCode, _emptyCsrId)
            End Get
        End Property
    End Class
End Namespace