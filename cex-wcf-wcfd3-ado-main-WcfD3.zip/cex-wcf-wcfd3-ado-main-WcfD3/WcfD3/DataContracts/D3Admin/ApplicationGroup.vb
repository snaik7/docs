﻿Imports System.Runtime.Serialization
Imports System.Collections.Generic

<DataContract>
Public Class ApplicationGroup

    <DataMember()>
    Property GroupName As String

    <DataMember()>
    Property Priority As Integer

    <DataMember()>
    Property Privileges As IEnumerable(Of D3Action)
End Class
