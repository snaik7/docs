﻿Imports Arvest.Common
Imports System.Runtime.Serialization

Namespace DataContract
    <DataContract()>
    Public Class AuthorizeCsrRequest
        Inherits D3AdminRequest

        <DataMember()>
        Property Domain As String

        <DataMember()>
        Property UserName As String
    End Class
End Namespace