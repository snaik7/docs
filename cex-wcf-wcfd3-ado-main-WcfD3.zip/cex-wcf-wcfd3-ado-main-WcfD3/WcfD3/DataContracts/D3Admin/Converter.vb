﻿Imports System.Collections.Generic

Imports DaoApplicationGroup = Arvest.DataAccess.Camp.Dao.ApplicationGroup

Namespace DataContract.D3Admin
    NotInheritable Class Converter
        Private Sub New()

        End Sub

        Shared Function Convert(applicationGroups As IEnumerable(Of DaoApplicationGroup)) As IEnumerable(Of ApplicationGroup)
            If applicationGroups Is Nothing Then
                Return Nothing
            End If

            Return (From applicationGroup As DaoApplicationGroup In applicationGroups
                    Select Convert(applicationGroup)).ToList()
        End Function

        Shared Function Convert(applicationGroup As DaoApplicationGroup) As ApplicationGroup
            If applicationGroup Is Nothing Then
                Return Nothing
            End If

            Return New ApplicationGroup With
                   {.GroupName = applicationGroup.GroupName,
                    .Priority = applicationGroup.Priority,
                    .Privileges = Convert(applicationGroup.Privileges)}
        End Function

        Shared Function Convert(privileges As IEnumerable(Of String)) As IEnumerable(Of D3Action)
            If privileges Is Nothing Then
                Return Nothing
            End If

            Return (From privilege As String In privileges
                    Select DirectCast([Enum].Parse(GetType(D3Action), privilege), D3Action)).ToList
        End Function
    End Class
End Namespace

