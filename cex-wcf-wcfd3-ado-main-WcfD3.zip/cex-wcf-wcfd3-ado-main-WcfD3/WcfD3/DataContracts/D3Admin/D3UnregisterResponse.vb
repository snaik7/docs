﻿Imports System.Collections.Generic

Imports Arvest.Common
Imports Arvest.WCF.D3.DataContract

Public Class D3UnregisterResponse
    Inherits D3AdminResponse

    <XmlSerializeOptions(tagName:="Accounts", ArrayElementName:="Account")>
    Public Property Accounts As IEnumerable(Of Account)
End Class
