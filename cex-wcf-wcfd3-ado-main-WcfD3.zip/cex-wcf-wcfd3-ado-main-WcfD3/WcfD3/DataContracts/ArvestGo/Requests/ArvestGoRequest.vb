﻿Imports System.Runtime.Serialization

Namespace DataContract
    <DataContract()>
    Public Class ArvestGoRequest
        <DataMember()>
        Property UserId As String
    End Class
End Namespace