﻿Imports Arvest.Common

Public Class CheckDepositLimitResponse

    <XmlSerializeOptions(TagName:="code")>
    Property Code As String

    <XmlSerializeOptions(TagName:="message")>
    Property Message As String

    <XmlSerializeOptions(TagName:="usage1")>
    Property Usage1 As String

    <XmlSerializeOptions(TagName:="limit1")>
    Property Limit1 As String

    <XmlSerializeOptions(TagName:="usage30")>
    Property Usage30 As String

    <XmlSerializeOptions(TagName:="limit30")>
    Property Limit30 As String
End Class
