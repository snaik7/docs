﻿Imports System.Runtime.Serialization

<DataContract()>
Public Class ArvestGoError

    <DataMember()>
    Property ErrorMessage As String

    <DataMember()>
    Property ErrorCode As String

End Class
