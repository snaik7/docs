﻿Imports System.Runtime.Serialization

Namespace DataContract
    <DataContract()>
    Public Class GetCheckDepositLimitResponse
        Inherits ArvestGoResponse

        <DataMember()>
        Property LimitLastBusinessDay As String

        <DataMember()>
        Property LimitLast30Days As String

        <DataMember()>
        Property UsageLastBusinessDay As String

        <DataMember()>
        Property UsageLast30Days As String

    End Class
End Namespace