﻿Imports System.Runtime.Serialization

Namespace DataContract
    <DataContract()>
    Public Class ArvestGoResponse

        <DataMember()>
        Property [Error] As ArvestGoError

    End Class
End Namespace