﻿Imports Arvest.Common

Namespace DataAccess.Daos
    Public Class ProfileUpdateRequest
        <XmlSerializeOptions(tagName:="userPrfl")>
        Public Property Profile As UserProfile
    End Class
End Namespace
