﻿Imports Arvest.Common

Namespace DataAccess.Daos
    Public Class AsyncResponse
        Inherits CoreLiveResponse

        <XmlSerializeOptions(tagName:="payload")>
        Public Property Payload As String
    End Class
End Namespace
