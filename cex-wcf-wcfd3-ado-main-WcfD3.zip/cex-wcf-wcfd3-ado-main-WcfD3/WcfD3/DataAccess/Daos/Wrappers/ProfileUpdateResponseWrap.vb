﻿Imports Arvest.Common

Namespace DataAccess.Daos.Wrappers
    Public Class ProfileUpdateResponseWrap
        Inherits BaseDao

        <XmlSerializeOptions(tagName:="prflUpdtResp")>
        Public Property Response As Response
    End Class
End Namespace