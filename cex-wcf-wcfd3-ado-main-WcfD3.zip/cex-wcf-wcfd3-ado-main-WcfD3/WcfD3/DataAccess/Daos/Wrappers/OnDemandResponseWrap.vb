﻿Imports Arvest.Common

Namespace DataAccess.Daos.Wrappers
    Public Class OnDemandResponseWrap
        Inherits BaseDao

        <XmlSerializeOptions(tagName:="onDemandResp")>
        Public Property Response As AsyncResponse
    End Class
End Namespace