﻿Imports Arvest.Common

Namespace DataAccess.Daos.Wrappers
    Public Class EnrollEstatementsRequestWrap
        Inherits BaseDao

        <XmlSerializeOptions(TagName:="eStmtEnrlRqst")>
        Public Property Request As AccountEnrollment
    End Class
End Namespace
