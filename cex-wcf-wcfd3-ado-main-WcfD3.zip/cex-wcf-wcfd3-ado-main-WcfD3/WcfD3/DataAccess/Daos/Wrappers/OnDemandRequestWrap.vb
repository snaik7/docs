﻿Imports Arvest.Common

Namespace DataAccess.Daos.Wrappers
    Public Class OnDemandRequestWrap
        Inherits BaseDao

        <XmlSerializeOptions(tagName:="onDemandRqst")>
        Public Property Request As OnDemandRequest
    End Class
End Namespace