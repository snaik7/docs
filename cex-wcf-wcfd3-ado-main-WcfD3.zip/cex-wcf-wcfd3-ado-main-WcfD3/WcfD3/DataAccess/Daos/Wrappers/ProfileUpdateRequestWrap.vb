﻿Imports Arvest.Common

Namespace DataAccess.Daos.Wrappers
    Public Class ProfileUpdateRequestWrap
        Inherits BaseDao

        <XmlSerializeOptions(tagName:="prflUpdtRqst")>
        Public Property Request As ProfileUpdateRequest
    End Class
End Namespace