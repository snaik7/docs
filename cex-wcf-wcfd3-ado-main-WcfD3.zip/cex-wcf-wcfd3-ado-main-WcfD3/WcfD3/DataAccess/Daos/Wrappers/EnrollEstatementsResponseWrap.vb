﻿Imports Arvest.Common

Namespace DataAccess.Daos.Wrappers
    Public Class EnrollEstatementsResponseWrap
        Inherits BaseDao

        <XmlSerializeOptions(tagName:="eStmtEnrlResp")>
        Public Property Response As CoreLiveResponse
    End Class
End Namespace
