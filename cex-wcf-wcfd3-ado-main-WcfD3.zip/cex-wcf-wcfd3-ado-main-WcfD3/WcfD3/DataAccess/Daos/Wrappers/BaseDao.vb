﻿Imports Arvest.Common

Namespace DataAccess.Daos.Wrappers
    Public MustInherit Class BaseDao
        <XmlSerializeOptions(tagName:="hdr")>
        Public Property Header As Header
    End Class
End Namespace

