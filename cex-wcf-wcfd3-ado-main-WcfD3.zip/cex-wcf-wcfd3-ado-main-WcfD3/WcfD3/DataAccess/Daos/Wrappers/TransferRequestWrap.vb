﻿Imports Arvest.Common

Namespace DataAccess.Daos.Wrappers
    Public Class TransferRequestWrap
        Inherits BaseDao

        <XmlSerializeOptions(TagName:="intlAcctFundXferRqst")>
        Public Property Request As TransferRequest

        <XmlSerializeOptions(TagName:="onUsXferRqst")>
        Public Property OnUsRequest As TransferOnUsRequest
    End Class
End Namespace
