﻿Imports Arvest.Common

Namespace DataAccess.Daos.Wrappers
    Public Class IntraDayRequestWrap
        Inherits BaseDao

        <XmlSerializeOptions(tagName:="intraDayRqst")>
        Public Property Request As IntraDayRequest
    End Class
End Namespace

