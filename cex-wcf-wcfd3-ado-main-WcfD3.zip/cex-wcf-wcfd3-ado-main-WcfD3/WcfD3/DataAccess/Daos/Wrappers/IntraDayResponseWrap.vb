﻿Imports Arvest.Common

Namespace DataAccess.Daos.Wrappers
    Public Class IntraDayResponseWrap
        Inherits BaseDao

        <XmlSerializeOptions(tagName:="intraDayResp")>
        Public Property Response As AsyncResponse
    End Class
End Namespace

