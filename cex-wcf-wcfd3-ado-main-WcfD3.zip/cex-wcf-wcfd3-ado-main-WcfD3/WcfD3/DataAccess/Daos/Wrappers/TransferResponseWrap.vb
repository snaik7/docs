﻿Imports Arvest.Common

Namespace DataAccess.Daos.Wrappers
    Public Class TransferResponseWrap
        Inherits BaseDao

        <XmlSerializeOptions(TagName:="intlAcctFundXferResp")>
        Public Property Response As TransferResponse

        <XmlSerializeOptions(TagName:="OnUsXferResp")>
        Public Property OnUsResponse As TransferOnUsResponse
    End Class
End Namespace
