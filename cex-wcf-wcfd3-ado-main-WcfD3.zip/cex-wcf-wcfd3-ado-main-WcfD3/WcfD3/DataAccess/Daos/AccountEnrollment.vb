﻿Imports Arvest.Common

Namespace DataAccess.Daos
    Public Class AccountEnrollment
        Inherits AccountRequest

        <XmlSerializeOptions(tagName:="eStmtPref")>
        Public Property EStatementPreference As String
    End Class
End Namespace
