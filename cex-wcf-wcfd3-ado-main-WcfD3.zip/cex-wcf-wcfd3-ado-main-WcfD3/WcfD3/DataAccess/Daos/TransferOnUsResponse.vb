﻿Imports Arvest.Common

Namespace DataAccess.Daos
    Public Class TransferOnUsResponse
        Inherits CoreLiveResponse

        <XmlSerializeOptions(TagName:="fromAcctAvblBal")>
        Public Property FromAccountAvailableBalance As Decimal?

        <XmlSerializeOptions(TagName:="toName")>
        Public Property ToName As String

        <XmlSerializeOptions(TagName:="toAcctNbr")>
        Public Property ToAccountNumber As String

        <XmlSerializeOptions(TagName:="toRoutingNbr")>
        Public Property ToRoutingNumber As String

        <XmlSerializeOptions(TagName:="cnfmNbr")>
        Public Property ConfirmationNumber As String

        <XmlSerializeOptions(TagName:="txn")>
        Public Property Transaction As Transaction
    End Class
End Namespace
