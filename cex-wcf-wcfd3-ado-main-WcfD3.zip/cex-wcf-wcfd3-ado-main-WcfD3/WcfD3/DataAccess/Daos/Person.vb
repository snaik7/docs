﻿Imports Arvest.Common

Namespace DataAccess.Daos
    Public Class Person

        <XmlSerializeOptions(tagName:="frstName")>
        Public Property FirstName As String

        <XmlSerializeOptions(tagName:="midlName")>
        Public Property MiddleName As String

        <XmlSerializeOptions(tagName:="lastName")>
        Public Property LastName As String

        <XmlSerializeOptions(tagName:="priEmail")>
        Public Property PrimaryEmail As String

        <XmlSerializeOptions(tagName:="altEmail")>
        Public Property AlternateEmail As String

        <XmlSerializeOptions(tagName:="homePhon")>
        Public Property HomePhone As String

        <XmlSerializeOptions(tagName:="workPhon")>
        Public Property WorkPhone As String

        <XmlSerializeOptions(tagName:="moblPhon")>
        Public Property MobilePhone As String

        <XmlSerializeOptions(tagName:="emp")>
        Public Property Employee As String = "0"

        <XmlSerializeOptions(tagName:="priAddr")>
        Public Property PhysicalAddress As Address

        <XmlSerializeOptions(tagName:="mailAddr")>
        Public Property MailingAddress As Address
    End Class
End Namespace
