﻿Imports Arvest.Common


Namespace DataAccess.Daos.Map
    Public Class CreateMapIdResponse
        Inherits HostResponse

        <XmlSerializeOptions(tagName:="mapId")>
        Property MapId As Long
    End Class
End Namespace

