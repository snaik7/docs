﻿Imports Arvest.Common

Namespace DataAccess.Daos.Map
    Public Class HostResponse
        <XmlSerializeOptions(tagName:="code")>
        Property Code As Integer

        <XmlSerializeOptions(tagName:="message")>
        Property Message As String

        <XmlSerializeOptions(tagName:="success")>
        Property Success As Boolean
    End Class
End Namespace
