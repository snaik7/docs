﻿Imports Arvest.Common

Namespace DataAccess.Daos
    Public Class CoreLiveResponse
        <XmlSerializeOptions(tagName:="stat")>
        Public Property Status As Integer

        <XmlSerializeOptions(tagName:="infoText")>
        Public Property InformationalText As String
    End Class
End Namespace
