﻿Imports Arvest.Common

Namespace DataAccess.Daos
    Public Class Address
        <XmlSerializeOptions(tagName:="addr1")>
        Public Property Address1 As String

        <XmlSerializeOptions(tagName:="addr2")>
        Public Property Address2 As String

        <XmlSerializeOptions(tagName:="addr3")>
        Public Property Address3 As String

        <XmlSerializeOptions(tagName:="addr4")>
        Public Property Address4 As String

        <XmlSerializeOptions(tagName:="city")>
        Public Property City As String

        <XmlSerializeOptions(tagName:="st")>
        Public Property State As String

        <XmlSerializeOptions(tagName:="pstlCode")>
        Public Property PostalCode As String

        <XmlSerializeOptions(tagName:="ctryCode")>
        Public Property CountryCode As String = "US"

        <XmlSerializeOptions(tagName:="lat")>
        Public Property Latitude As Decimal

        <XmlSerializeOptions(tagName:="lon")>
        Public Property Longitude As Decimal
    End Class
End Namespace