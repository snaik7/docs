﻿Imports System.Collections.Generic

Imports Arvest.Common

 Class D3VerifyHostResponse
    <XmlSerializeOptions(tagName:="RelAxmIds", ArrayElementName:="AxmRecord")>
    Public Property AxmIds As IEnumerable(Of AxMRecord)

    <XmlSerializeOptions(tagName:="AcctNumber")>
    Public Property AccountNumber As String

    <XmlSerializeOptions(tagName:="AcctType")>
    Public Property AccountType As String

    Public Property ErrorDescription As String

    Public Property Service As String

    <XmlSerializeOptions(tagName:="TimeStamp")>
    Public Property Timestamp As String

    Public Property [Function] As String

    Public Property SessionId As String
End Class