﻿
Imports Arvest.Common

Class AxMRecord
    <XmlSerializeOptions(TagName:="AxmSSN")>
    Property Last4Ssn As String

    Property AxmSSNType As String

    Property AxmId As String

    <XmlSerializeOptions(TagName:="AcctStatus")>
    Property AccountStatus As String

    Property AxmAccount As String

    Property AxmActType As String

    Property AxmService As String
End Class