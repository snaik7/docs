﻿Imports Arvest.WCF.D3.DataContract

Class D3HostUpdate
    Inherits D3AdminRequest

    Property MapId As Long

    Sub New(ByVal MapId As Long, ByVal CsrId As String)
        [Function] = "MAPUPDATE"

        Me.CsrId = CsrId
        Me.MapId = MapId
    End Sub
End Class