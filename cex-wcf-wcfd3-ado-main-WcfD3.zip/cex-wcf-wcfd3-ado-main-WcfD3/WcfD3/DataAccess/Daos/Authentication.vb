﻿Imports Arvest.Common

Namespace DataAccess.Daos
    Public Class Authentication

        <XmlSerializeOptions(tagName:="userName")>
        Public Property UserName As String

        <XmlSerializeOptions(tagName:="pswd")>
        Public Property Password As String
    End Class
End Namespace

