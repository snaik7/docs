﻿Imports Arvest.Common

Namespace DataAccess.Daos
    Public Class Response
        Inherits CoreLiveResponse

        <XmlSerializeOptions(tagName:="cnfmNbr")>
        Public Property ConfirmationNumber As String
    End Class
End Namespace
