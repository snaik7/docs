﻿Imports Arvest.Common

Namespace DataAccess.Daos
    Public Class OnDemandRequest

        <XmlSerializeOptions(tagName:="eTkn")>
        Public Property EchoToken As String
    End Class
End Namespace
