﻿Imports Arvest.Common

Namespace DataAccess.Daos
    Public Class Header

        <XmlSerializeOptions(tagName:="ver")>
        Public Property Version As String = "2.0"

        <XmlSerializeOptions(tagName:="rqstId")>
        Public Property RequestId As String

        <XmlSerializeOptions(tagName:="authn")>
        Public Property Authentication As Authentication

        <XmlSerializeOptions(tagName:="uid")>
        Public Property UserId As String
    End Class
End Namespace
