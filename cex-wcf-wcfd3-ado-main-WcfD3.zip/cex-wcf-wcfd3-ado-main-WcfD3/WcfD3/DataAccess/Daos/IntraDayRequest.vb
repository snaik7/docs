﻿Imports Arvest.Common

Namespace DataAccess.Daos
    Public Class IntraDayRequest

        <XmlSerializeOptions(tagName:="txnDateRang")>
        Public Property DateRange As DateRange

        <XmlSerializeOptions(tagName:="eTkn")>
        Public Property EchoToken As String
    End Class
End Namespace
