﻿Imports Arvest.Common

Namespace DataAccess.Daos
    Public Class TransferOnUsRequest

        <XmlSerializeOptions(TagName:="fromAcctUid")>
        Public Property FromAccount As String

        <XmlSerializeOptions(TagName:="toName")>
        Public Property ToName As String

        <XmlSerializeOptions(TagName:="toAcctNbr")>
        Public Property ToAccountNumber As String

        <XmlSerializeOptions(TagName:="toRoutingNbr")>
        Public Property ToRoutingNumber As String

        <XmlSerializeOptions(TagName:="memo")>
        Public Property Memo As String

        <XmlSerializeOptions(TagName:="fromAcctCncyCode")>
        Public Property FromAccountCurrencyCode As String

        <XmlSerializeOptions(TagName:="date", DateTimeFormat:="yyyy-MM-dd")>
        Public Property [Date] As Date

        <XmlSerializeOptions(TagName:="amt")>
        Public Property Amount As Decimal
    End Class
End Namespace
