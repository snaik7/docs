﻿Imports Arvest.Common

Namespace DataAccess.Daos
    Public Class TransferRequest

        <XmlSerializeOptions(tagName:="fromAcctUid")>
        Public Property FromAccount As String

        <XmlSerializeOptions(tagName:="toAcctUid")>
        Public Property ToAccount As String

        <XmlSerializeOptions(tagName:="memo")>
        Public Property Memo As String

        <XmlSerializeOptions(tagName:="fromAcctCncyCode")>
        Public Property FromAccountCurrencyCode As String

        <XmlSerializeOptions(tagName:="toAcctCncyCode")>
        Public Property ToAccountCurrencyCode As String

        <XmlSerializeOptions(tagName:="date", DateTimeFormat:="yyyy-MM-dd")>
        Public Property [Date] As Date

        <XmlSerializeOptions(tagName:="amt")>
        Public Property Amount As Decimal
    End Class
End Namespace
