﻿Namespace DataAccess.Daos
    Public Enum TransactionType
        c
        d
    End Enum
End Namespace