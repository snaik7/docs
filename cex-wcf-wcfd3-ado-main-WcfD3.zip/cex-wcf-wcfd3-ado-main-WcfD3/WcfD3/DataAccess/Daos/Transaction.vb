﻿Imports Arvest.Common

Namespace DataAccess.Daos
    Public Class Transaction
        <XmlSerializeOptions(tagName:="uid")>
        Property Id As String

        <XmlSerializeOptions(tagName:="acctUid")>
        Property AccountId As String

        <XmlSerializeOptions(tagName:="type")>
        Property [Type] As TransactionType

        <XmlSerializeOptions(tagName:="amt")>
        Property Amount As Decimal

        <XmlSerializeOptions(tagName:="postDate")>
        Property PostDate As Date

        <XmlSerializeOptions(tagName:="pndg")>
        Property Pending As Integer

        <XmlSerializeOptions(tagName:="postSeq")>
        Property PostingSequence As Integer

        <XmlSerializeOptions(tagName:="name")>
        Property Name As String
    End Class
End Namespace
