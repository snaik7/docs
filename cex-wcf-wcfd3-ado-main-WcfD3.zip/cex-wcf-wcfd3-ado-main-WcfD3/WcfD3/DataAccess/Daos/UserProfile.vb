﻿Imports System.Collections.Generic

Imports Arvest.Common

Namespace DataAccess.Daos
    Public Class UserProfile
        <XmlSerializeOptions(TagName:="acctEnrlLst", ArrayElementName:="acct")>
        Public Property AccountEnrollment As IEnumerable(Of AccountEnrollment)

        <XmlSerializeOptions(tagName:="userSet")>
        Public Property UserSettings As UserSettings
    End Class
End Namespace

