﻿Imports Arvest.Common

Namespace DataAccess.Daos
    Public Class UserSettings

        <XmlSerializeOptions(tagName:="bpStat")>
        Public Property BillPayStatus As String

        <XmlSerializeOptions(tagName:="bpId")>
        Public Property BillPaySubscriberId As String

        <XmlSerializeOptions(tagName:="dob", DateTimeFormat:="yyyy-MM-dd")>
        Public Property DateOfBirth As Date

        <XmlSerializeOptions(tagName:="emlOpt")>
        Public Property EmailOptOut As String = "0"

        <XmlSerializeOptions(tagName:="gndr")>
        Public Property Gender As String

        <XmlSerializeOptions(tagName:="mobl")>
        Public Property Mobile As String = "0"

        <XmlSerializeOptions(tagName:="pers")>
        Public Property Person As Person
    End Class
End Namespace
