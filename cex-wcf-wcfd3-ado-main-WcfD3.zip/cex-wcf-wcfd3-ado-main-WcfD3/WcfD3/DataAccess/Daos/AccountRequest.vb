﻿Imports Arvest.Common

Namespace DataAccess.Daos
    Public Class AccountRequest
        <XmlSerializeOptions(tagName:="acctUid")>
        Public Property AccountId As String

        <XmlSerializeOptions(tagName:="compUid")>
        Public Property CompanyId As String
    End Class
End Namespace