﻿Imports Arvest.Common
Imports System.Collections.Generic

Namespace DataAccess.Daos
    Public Class TransferResponse
        Inherits CoreLiveResponse

        <XmlSerializeOptions(tagName:="fromAcctAvblBal")>
        Public Property FromAccountAvailableBalance As Decimal?

        <XmlSerializeOptions(tagName:="toAcctAvblBal")>
        Public Property ToAccountAvailableBalance As Decimal?

        <XmlSerializeOptions(tagName:="cnfmNbr")>
        Public Property ConfirmationNumber As String

        <XmlSerializeOptions(tagName:="txnList", ArrayElementName:="txn")>
        Public Property Transactions As IEnumerable(Of Transaction)
    End Class
End Namespace
