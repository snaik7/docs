﻿Imports Arvest.Common

Namespace DataAccess.Daos
    Public Class StopPaymentRequest
        Inherits AccountRequest

        <XmlSerializeOptions(tagName:="memo")>
        Public Property Memo As String

        <XmlSerializeOptions(tagName:="txnType")>
        Public Property TransactionType As String

        <XmlSerializeOptions(tagName:="chekNbr")>
        Public Property CheckNumber As String

        <XmlSerializeOptions(tagName:="amt")>
        Public Property Amount As Decimal
    End Class
End Namespace
