﻿Imports Arvest.Common

Namespace DataAccess.Daos
    Public Class DateRange

        <XmlSerializeOptions(tagName:="begnDate", DateTimeFormat:="yyyy-MM-dd")>
        Public Property Begin As Date

        <XmlSerializeOptions(tagName:="endDate", DateTimeFormat:="yyyy-MM-dd")>
        Public Property [End] As Date
    End Class
End Namespace
