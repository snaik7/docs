﻿Imports System.Collections.Generic
Imports System.Configuration
Imports System.Linq
Imports System.Xml

Imports Arvest.Common
Imports Arvest.Common.DataAccess.DB2i

Namespace DataAccess
    Class As400Client
        Private Shared hostTimeout As TimeSpan = TimeSpan.FromSeconds(Double.Parse(ConfigurationManager.AppSettings("hostTimeout")))

        Private Shared commandTimeout As Integer = Integer.Parse(ConfigurationManager.AppSettings("commandTimeout"))

        Private Shared connSwitch As ConnectionSwitch = New ConnectionSwitch(CreateConnectionInfo("AS400", ConfigurationManager.AppSettings("schema")),
                                                                             CreateConnectionInfo("AS400ATM", "ABOLIB"),
                                                                             TimeSpan.FromSeconds(Double.Parse(ConfigurationManager.AppSettings("connectionSwitchInterval"))))

        Private Shared cloudLibrary As String = ConfigurationManager.AppSettings("cloudLibrary")

        Private Shared Function CreateConnectionInfo(connectionStringName As String, schema As String) As ConnectionInfo
            Return New ConnectionInfo With
                   {
                       .ConnectionStringSettings = ConfigurationManager.ConnectionStrings(connectionStringName),
                       .Schema = schema
                   }
        End Function

        Private Sub New()

        End Sub

        Shared Function Ping() As Boolean
            Return connSwitch.PingActiveConnection()
        End Function

        Shared Function D3Connect(Of T)(request As Object, reqType As String, rootXml As String) As T
            Dim connInfo As ConnectionInfo = connSwitch.ActiveConnectionInfo
            Dim storedProcedure As String = String.Format("CALL {0}.OD3CONNECT(?, ?)", connInfo.Schema)

            Dim serializer As New ArvestXmlSerializer(True, storedProcedure)

            Dim xmlIn As String = serializer.Serialize(request, New XmlWriterSettings With {.OmitXmlDeclaration = True}, rootXml)
            Dim xmlOut As String

            Try
                xmlOut = DirectCast(ArvestDB2iSqlCommand.ExecuteOutputParmeters(connInfo.ConnectionStringSettings,
                                                                                storedProcedure,
                                                                                {reqType, xmlIn},
                                                                                commandTimeout:=commandTimeout,
                                                                                hostTimeout:=hostTimeout)(0), String)
            Catch ex As Exception
                ex.Data.Add("XML sent to host", xmlIn)

                Throw ex.PreserveStackTrace()
            End Try

            Return Deserialize(Of T)(serializer, xmlIn, xmlOut)
        End Function

        Shared Function CallAxmService(Of T)(request As Object) As T
            Return SendXmlToDB2(Of T)(request, connSwitch.ActiveConnectionInfo.ConnectionStringSettings, "CALL ABOLIB.AXMSERVICE(?)", "request", hostTimeout)
        End Function

        Shared Function RetrieveMigrationDate(webUserId As String) As String
            Return RetrieveMigrationDate("SELECT DISTINCT MIGDATE " &
                                         "FROM {0}.CLDD3CTRL " &
                                         "WHERE AXMUSERID = ?", webUserId)
        End Function

        Shared Function RetrieveMigrationDateWithAxmId(axmId As String) As String
            Return RetrieveMigrationDate("SELECT DISTINCT MIGDATE " &
                                         "FROM {0}.CLDD3CTRL " &
                                         "WHERE AXMID = ?", axmId)
        End Function

        Shared Function RetrieveEmail(axmId As String) As String
            Dim xmlIn As String = (New ArvestXmlSerializer(True)).Serialize(New With {.userId = axmId},
                                                                            New XmlWriterSettings With {.OmitXmlDeclaration = True},
                                                                            "request")
            Dim xmlOut As String

            Try
                xmlOut = DirectCast(ArvestDB2iSqlCommand.ExecuteOutputParmeters(connSwitch.ActiveConnectionInfo.ConnectionStringSettings,
                                                                                "ABOLIB.MAPRFNDCLD",
                                                                                {xmlIn},
                                                                                commandTimeout:=commandTimeout,
                                                                                hostTimeout:=hostTimeout)(0),
                                    String)
            Catch ex As Exception
                ex.Data.Add("XML sent to host", xmlIn)

                Throw ex.PreserveStackTrace()
            End Try

            Dim resp As XElement = XElement.Load(xmlOut)
            Dim email As IEnumerable(Of String) = From el In resp.Elements("Customer")
                                                  Select el.Element("HomeEmail").Value

            Return email(0)
        End Function

        Shared Function GetMobileDepositLimits(userId As String) As CheckDepositLimitResponse
            Dim serializer As New ArvestXmlSerializer(True)
            Dim xmlRequest As String = serializer.Serialize(New With {.userId = userId},
                                                            New XmlWriterSettings With {.OmitXmlDeclaration = True},
                                                            "request")
            'Throw New Exception(DirectCast(ArvestDB2iSqlCommand.ExecuteOutputParmeters _
            '                                                                       (connSwitch.ActiveConnectionInfo.ConnectionStringSettings,
            '                                                                        "CALL ABOLIB.MOBVELAMTP(?)",
            '                                                                        {xmlRequest},
            '                                                                        commandTimeout:=commandTimeout,
            '                                                                        hostTimeout:=hostTimeout)(0),
            '                                                            String))
            Return serializer.Deserialize(Of CheckDepositLimitResponse)(DirectCast(ArvestDB2iSqlCommand.ExecuteOutputParmeters _
                                                                                   (connSwitch.ActiveConnectionInfo.ConnectionStringSettings,
                                                                                    "CALL ABOLIB.MOBVELAMTP(?)",
                                                                                    {xmlRequest},
                                                                                    commandTimeout:=commandTimeout,
                                                                                    hostTimeout:=hostTimeout)(0),
                                                                        String))
        End Function

        Private Shared Function RetrieveMigrationDate(commandText As String, parameter As String) As String
            Return ArvestDB2iSqlCommand.ExecuteScalar(Of String)(connSwitch.ActiveConnectionInfo.ConnectionStringSettings,
                                                                 String.Format(commandText, cloudLibrary),
                                                                  {parameter})
        End Function
    End Class
End Namespace