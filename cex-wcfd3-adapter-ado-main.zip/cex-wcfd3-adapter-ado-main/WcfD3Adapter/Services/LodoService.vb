﻿Imports System.ServiceModel
Imports System.Configuration

Imports Arvest.Common.WCF

Imports Arvest.WCF.D3.Adapter.ServiceReferences.Lodo

<ServiceBehavior(Namespace:="http://arvest.com/", ConcurrencyMode:=ConcurrencyMode.Multiple)>
Public Class LodoService
    Implements ILodoContract

    Private Shared lodoEndpointConfigurationName As String = ConfigurationManager.AppSettings("LodoEndpointConfigurationName")

    Public Function isServerAlive() As Boolean Implements ILodoContract.IsServerAlive
        Return True
    End Function

    Public Function authenticateUser(ByVal request As AuthenticateUserRequest) As LodoResponse Implements ILodoContract.authenticateUser
        Return WCFUtil.UseClient(AddressOf getLodoContractClient.authenticateUser, request)
    End Function

    Public Function authenticateUserRSA(ByVal request As AuthenticateUserRSARequest) As AuthenticateUserRSAResponse Implements ILodoContract.authenticateUserRSA
        Return WCFUtil.UseClient(AddressOf getLodoContractClient.authenticateUserRSA, request)
    End Function

    Public Function lockUser(ByVal request As LockUserRequest) As LodoResponse Implements ILodoContract.lockUser
        Return WCFUtil.UseClient(AddressOf getLodoContractClient.lockUser, request)
    End Function

    Public Function unLockUser(ByVal request As LockUserRequest) As LodoResponse Implements ILodoContract.unLockUser
        Return WCFUtil.UseClient(AddressOf getLodoContractClient.unLockUser, request)
    End Function

    Public Function changePassword(ByVal request As Credentials) As LodoResponse Implements ILodoContract.changePassword
        Return WCFUtil.UseClient(AddressOf getLodoContractClient.changePassword, request)
    End Function

    Public Function isLocked(request As LockUserRequest) As IsLockedResponse Implements ILodoContract.isLocked
        Return WCFUtil.UseClient(AddressOf getLodoContractClient.isLocked, request)
    End Function

    Private Shared Function getLodoContractClient() As LodoContractClient
        Return New LodoContractClient(lodoEndpointConfigurationName)
    End Function

    Public Function changeUserId(request As ChangeUserIdRequest) As LodoResponse Implements ILodoContract.changeUserId
        Return WCFUtil.UseClient(AddressOf getLodoContractClient.changeUserId, request)
    End Function
End Class
