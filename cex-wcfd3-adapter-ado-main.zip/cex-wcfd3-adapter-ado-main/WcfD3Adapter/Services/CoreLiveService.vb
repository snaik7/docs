﻿Imports System.Configuration
Imports System.ServiceModel
Imports System.Diagnostics

Imports Arvest.Common
Imports Arvest.Common.WCF

Imports Arvest.WCF.D3.Adapter.ServiceReferences.CoreLive

<ServiceBehavior(Namespace:="http://d3banking.d3connect.corelive", ConcurrencyMode:=ConcurrencyMode.Multiple)>
Public Class CoreLiveService
    Implements CoreLive

    Private Shared coreLiveEndpointConfigurationName As String = ConfigurationManager.AppSettings("CoreLiveEndpointConfigurationName")

    Public Sub New()
        Trace.CorrelationManager.ActivityId = Guid.NewGuid
    End Sub

    Public Function GetCoreLiveClient() As CoreLiveClient
        Return New CoreLiveClient(coreLiveEndpointConfigurationName)
    End Function

    Public Function IsServerAlive(request As IsServerAliveRequest) As IsServerAliveResponse Implements CoreLive.IsServerAlive
        Return New IsServerAliveResponse() With {.IsServerAliveResult = True}
    End Function

    Public Function enrollEstatements(request As EnrollEstatementsRequest) As EnrollEstatementsResponse Implements CoreLive.enrollEstatements
        Return UseClient(Function(client As CoreLiveClient) client.enrollEstatements(request))
    End Function

    Public Function initiateIntraDay(request As IntraDayRequest) As IntraDayResponse Implements CoreLive.initiateIntraDay
        Return UseClient(Function(client As CoreLiveClient) client.initiateIntraDay(request))
    End Function

    Public Function initiateOnDemand(request As OnDemandRequest) As OnDemandResponse Implements CoreLive.initiateOnDemand
        Return UseClient(Function(client As CoreLiveClient) client.initiateOnDemand(request))
    End Function

    Public Function ping(request As PingRequest) As PingResponse Implements CoreLive.ping
        Return UseClient(Function(client As CoreLiveClient) client.ping(request))
    End Function

    Public Function stopPayment(request As StopPaymentRequest) As StopPaymentResponse Implements CoreLive.stopPayment
        Return UseClient(Function(client As CoreLiveClient) client.stopPayment(request))
    End Function

    Public Function transferFunds(request As TransferRequest) As TransferResponse Implements CoreLive.transferFunds
        Return UseClient(Function(client As CoreLiveClient) client.transferFunds(request))
    End Function

    Public Function updateProfile(request As ProfileUpdateRequest) As ProfileUpdateResponse Implements CoreLive.updateProfile
        Return UseClient(Function(client As CoreLiveClient) client.updateProfile(request))
    End Function

    Private Function UseClient(Of TResponse)(ByVal clientFunc As Func(Of CoreLiveClient, TResponse)) As TResponse
        Try
            Return GetCoreLiveClient.UseClient(clientFunc)
        Catch ex As FaultException(Of ExceptionDetail) When ex.Message = "The operation has timed out."
            Throw New FaultException(ex.CreateMessageFault).DoNotTrace
        Catch ex As FaultException(Of ExceptionDetail)
            Throw New FaultException(ex.CreateMessageFault)
        End Try
    End Function
End Class
