﻿Imports System.Configuration
Imports Arvest.Common.WCF
Imports Arvest.WCF.D3.Adapter.ServiceReferences.ArvestGo

Public Class ArvestGoService
    Implements IArvestGoService

    Private Shared arvestGoEndpointConfigurationName As String = ConfigurationManager.AppSettings("ArvestGoEndpointConfigurationName")

    Private Function getArvestGoClient() As ArvestGoServiceClient
        Return New ArvestGoServiceClient(arvestGoEndpointConfigurationName)
    End Function

    Public Function GetCheckDepositLimit(request As ArvestGoRequest) As GetCheckDepositLimitResponse _
        Implements IArvestGoService.GetCheckDepositLimit

        Return WCFUtil.UseClient(AddressOf getArvestGoClient.GetCheckDepositLimit, request)
    End Function

    Public Function IsServerAlive() As Boolean _
        Implements IWCFContract.IsServerAlive

        Using client As ArvestGoServiceClient = getArvestGoClient()
            Return client.IsServerAlive()
        End Using
    End Function
End Class
