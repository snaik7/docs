﻿Imports System.ServiceModel
Imports System.Configuration

Imports Arvest.Common.WCF

Imports Arvest.WCF.D3.Adapter.ServiceReferences.D3Admin

<ServiceBehavior(Namespace:="http://arvest.com/", ConcurrencyMode:=ConcurrencyMode.Multiple)>
Public Class D3AdminAdaptor
    Implements ID3Admin

    Private Shared d3AdminEndpointConfigurationName As String = ConfigurationManager.AppSettings("D3AdminEndpointConfigurationName")

    Public Function isServerAlive() As Boolean Implements ID3Admin.IsServerAlive
        Return True
    End Function

    Public Function MigrateUser(ByVal request As D3MigrationRequest) As D3AdminResponse Implements ID3Admin.MigrateUser
        Return WCFUtil.UseClient(AddressOf getD3ContractClient.MigrateD3User, request)
    End Function

    Private Shared Function getD3ContractClient() As D3AdminClient
        Return New D3AdminClient(d3AdminEndpointConfigurationName)
    End Function
End Class
