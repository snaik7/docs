﻿Imports Arvest.Common.WCF
Imports System.ServiceModel
Imports Arvest.WCF.D3.Adapter.ServiceReferences.D3Admin

<ServiceContract(Namespace:="http://arvest.com/")>
Public Interface ID3Admin
    Inherits IWCFContract

    <OperationContract()>
    Function MigrateUser(ByVal request As D3MigrationRequest) As D3AdminResponse
End Interface