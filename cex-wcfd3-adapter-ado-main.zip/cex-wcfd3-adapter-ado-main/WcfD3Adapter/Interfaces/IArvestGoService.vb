﻿Imports System.ServiceModel
Imports Arvest.Common.WCF
Imports Arvest.WCF.D3.Adapter.ServiceReferences.ArvestGo

<ServiceContract()>
Public Interface IArvestGoService
    Inherits IWCFContract

    <OperationContract()>
    Function GetCheckDepositLimit(request As ArvestGoRequest) As GetCheckDepositLimitResponse

End Interface
