# Windows Communication Foundation D3 middleware 
This is a Microsoft Visual Studio Wcf Project to provide middle tier service.  This project is reconstructed as a solution project to allow compiler, local and DevOps build engine to better utilize modern solution configuration for different environment deployment on DevOps

# Getting Started
Here is the minimun requirements for developer to download the code and work on
1.	Microsoft Visual Studio 2019
2.	Dot Net Framework 4.0.0
3.	Newtonsoft Json Nuget

# Build and Test
1. There are multiple Environment stored in folder /config
2. Three Configuration in Configuration Manager for each Arvest Environments
   a. ArvestDevEnv
   b. ArvestTestEnv
   c. ArvestProdEnv
3. The binary folder for deployment to servers for each configuration environment
   a. \bin\ArvestDevEnv
   b. \bin\ArvestTestEnv
   c. \bin\ArvestProdEnv
4. During Build process, the following steps are required to target each specific Environment
   a. Create folder mkdir \bin\$(ConfigurationName)\config 
     i. E.g. mkdir \bin\ArvestDevEnv\config
   b. Copy file "\config\appSettings.config.$(ConfigurationName)" to "\config\appSettings.config"
     i. E.g. copy "\config\appSettings.config.ArvestDevEnv" "\config\appSettings.config"
   c. Copy file "\config\connectionStrings.config.$(ConfigurationName)" to "\config\connectionStrings.config"
     i. E.g. copy "\config\connectionStrings.config.ArvestDevEnv" "\config\connectionStrings.config"
   d. Copy file "\config\diagnostics.config.$(ConfigurationName)" to "\config\diagnostics.config"
     i. E.g. copy "\config\diagnostics.config.ArvestDevEnv" "\config\diagnostics.config"
   e. Recompile and Build the into each respective Deployment folder
     i. msbuild.exe D3.sln /property:Configuration=ArvestDevEnv for \bin\ArvestDevEnv
	 ii. msbuild.exe D3.sln /property:Configuration=ArvestTestEnv for \bin\ArvestTestEnv
	 iii. msbuild.exe D3.sln /property:Configuration=ArvestProdEnv for \bin\ArvestProdEnv


# Contribute
This project has a long history touched by many software developers.  Please keep in mind for future developers maintaining this code when you are long gone.  Emphasis is on readability and allow someone fresh to pick up and run with it.  Keep it simple.

If you want to learn more about creating good readme files then refer the following [guidelines](https://docs.microsoft.com/en-us/azure/devops/repos/git/create-a-readme?view=azure-devops). You can also seek inspiration from the below readme files:
- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)
