﻿Imports System.ServiceModel
Imports Arvest.WCF.OLB.ClairMailCore.MBankingInterface
Imports Arvest.Common

Namespace ClairMailCore.Request
    <MessageContract(IsWrapped:=False)>
    Partial Public Class AuthenticateUserRSARequest

        <MessageBodyMember([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface", Order:=0)>
        <XmlSerializeOptions(tagName:="authUserRSAReq")>
        Property authenticateUserRequest As New AuthenticateUserRequest_Type
    End Class
End Namespace