﻿Imports System.ServiceModel
Imports Arvest.WCF.OLB.ClairMailCore.MBankingInterface

Namespace ClairMailCore.Request
    <MessageContract(IsWrapped:=False)>
    Public Class RemoteDepositRequest
        <MessageBodyMember([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
        Property processRDCRequest As ProcessRDCRequest_Type
    End Class
End Namespace
