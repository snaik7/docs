﻿Imports System.ServiceModel
Imports Arvest.WCF.OLB.ClairMailCore.MBankingInterface
Imports Arvest.Common

Namespace ClairMailCore.Request
    <MessageContract(IsWrapped:=False)>
    Partial Public Class GetUserRequest

        <MessageBodyMember([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface", Order:=0)>
        <XmlSerializeOptions(tagName:="getUserReq")>
        Property getUserRequest As New UserRequest_Type
    End Class
End Namespace


