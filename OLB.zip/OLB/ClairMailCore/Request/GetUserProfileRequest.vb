﻿Imports System.ServiceModel
Imports Arvest.WCF.OLB.ClairMailCore.MBankingInterface
Imports Arvest.Common

Namespace ClairMailCore.Request
    <MessageContract(IsWrapped:=False)>
    Partial Public Class GetUserProfileRequest

        <MessageBodyMember([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface", Order:=0)>
        <XmlSerializeOptions(tagName:="getUserPrReq")>
        Property getUserProfileRequest As New UserProfileRequest_Type
    End Class
End Namespace
