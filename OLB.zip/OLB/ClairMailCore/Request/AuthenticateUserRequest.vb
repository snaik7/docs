﻿Imports System.ServiceModel
Imports System.Xml.Serialization
Imports Arvest.WCF.OLB.ClairMailCore.MBankingInterface
Imports Arvest.Common

Namespace ClairMailCore.Request
    <MessageContract(IsWrapped:=False)>
    Partial Public Class AuthenticateUserRequest

        <MessageBodyMember([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface", Order:=0)>
        <XmlSerializeOptions(tagName:="authUserReq")>
        Property authenticateUserRequest As New AuthenticateUserRequest_Type
    End Class
End Namespace