﻿Imports System.ServiceModel
Imports Arvest.WCF.OLB.ClairMailCore.MBankingInterface
Imports Arvest.Common

Namespace ClairMailCore.Request
    <MessageContract(IsWrapped:=False)>
    Partial Public Class GetRecentTransfersRequest

        <MessageBodyMember([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface", Order:=0)>
        <XmlSerializeOptions(tagName:="getRXfersReq")>
        Property getRecentTransfersRequest As New RecentTransfersType_Request
    End Class
End Namespace
