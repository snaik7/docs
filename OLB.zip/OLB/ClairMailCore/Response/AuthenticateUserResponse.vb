﻿Imports System.ServiceModel
Imports Arvest.WCF.OLB.ClairMailCore.MBankingInterface
Imports Arvest.Common

Namespace ClairMailCore.Response
    <MessageContract(IsWrapped:=False)>
    Partial Public Class AuthenticateUserResponse

        <MessageBodyMember([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface", Order:=0)>
        <XmlSerializeOptions(tagName:="authUserResp")>
        Property authenticateUserResponse As New AuthenticateUserResponse_Type
    End Class
End Namespace