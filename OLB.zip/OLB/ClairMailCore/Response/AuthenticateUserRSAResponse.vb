﻿Imports System.ServiceModel
Imports Arvest.WCF.OLB.ClairMailCore.MBankingInterface
Imports Arvest.Common

Namespace ClairMailCore.Response
    <MessageContract(IsWrapped:=False)>
    Partial Public Class AuthenticateUserRSAResponse

        <MessageBodyMember([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface", Order:=0)>
        <XmlSerializeOptions(tagName:="authUserRSAResp")>
        Property authenticateUserRSAResponse As New AuthenticateUserRSAResponse_Type
    End Class
End Namespace