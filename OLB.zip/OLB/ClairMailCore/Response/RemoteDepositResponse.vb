﻿Imports System.ServiceModel
Imports Arvest.WCF.OLB.ClairMailCore.MBankingInterface

Namespace ClairMailCore.Response
    <MessageContract(IsWrapped:=False)>
    Public Class RemoteDepositResponse
        <MessageBodyMember([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
        Property remoteDepositResponse As ProcessRDCResponse_Type
    End Class
End Namespace

