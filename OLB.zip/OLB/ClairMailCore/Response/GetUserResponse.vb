﻿Imports System.ServiceModel
Imports Arvest.WCF.OLB.ClairMailCore.MBankingInterface
Imports Arvest.Common

Namespace ClairMailCore.Response
    <MessageContract(IsWrapped:=False)>
    Partial Public Class GetUserResponse

        <MessageBodyMember(Name:="getUserResponse", Namespace:="http://schemas.clairmail.com/2009/01/MBankingInterface", Order:=0)>
        <XmlSerializeOptions(tagName:="getUserResp")>
        Property GetUserResponse As New UserResponse_Type

        <XmlSerializeOptions(tagName:="axmID")>
        Property AxmId As String
    End Class
End Namespace