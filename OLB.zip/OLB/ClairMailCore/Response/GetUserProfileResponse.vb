﻿Imports System.ServiceModel
Imports Arvest.WCF.OLB.ClairMailCore.MBankingInterface
Imports Arvest.Common

Namespace ClairMailCore.Response
    <MessageContract(IsWrapped:=False)>
    Public Class GetUserProfileResponse

        <MessageBodyMember(Name:="getUserProfileResponse", Namespace:="http://schemas.clairmail.com/2009/01/MBankingInterface", Order:=0)>
        <XmlSerializeOptions(tagName:="getUserPrResp")>
        Property GetUserProfileResponse As New UserProfileResponse_Type

        <XmlSerializeOptions(tagName:="axmID")>
        Property AxmId As String
    End Class
End Namespace

