﻿Imports System.ServiceModel
Imports Arvest.WCF.OLB.ClairMailCore.MBankingInterface
Imports Arvest.Common

Namespace ClairMailCore.Response
    <MessageContract(IsWrapped:=False)>
    Partial Public Class GetRecentTransfersResponse

        <MessageBodyMember([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface", Order:=0)>
        <XmlSerializeOptions(tagName:="getRXfersResp")>
        Property getRecentTransfersResponse As New RecentTransfersType_Response
    End Class
End Namespace