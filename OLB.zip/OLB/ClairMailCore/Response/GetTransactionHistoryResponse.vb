﻿Imports System.ServiceModel
Imports Arvest.WCF.OLB.ClairMailCore.MBankingInterface
Imports Arvest.Common

Namespace ClairMailCore.Response
    <MessageContract(IsWrapped:=False)>
    Partial Public Class GetTransactionHistoryResponse

        <MessageBodyMember([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface", Order:=0)>
        <XmlSerializeOptions(tagName:="getTHistResp")>
        Property getTransactionHistoryResponse As New TransactionHistoryType_Response
    End Class

End Namespace

