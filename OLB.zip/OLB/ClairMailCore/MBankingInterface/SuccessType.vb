﻿Imports System.ServiceModel

Namespace ClairMailCore.MBankingInterface
    <MessageContract()>
    Public Class SuccessType
        <MessageBodyMember([Namespace]:="http://validationservice.arvest.com/")>
        Property confirmationNumber As String
    End Class
End Namespace

