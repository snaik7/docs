﻿Imports System.Xml.Serialization
Imports System.ServiceModel
Imports Arvest.WCF.OLB.ClairMailCore.MBankingModel.Account
Imports Arvest.Common


Namespace ClairMailCore.MBankingInterface
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
    Partial Public Class BalanceType_Request
        Inherits Request_Type

        <XmlArray([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account", Order:=0)>
        <XmlSerializeOptions(tagName:="acctList", arrayelementName:="account")>
        Public Property accountList As Account_Type()
    End Class
End Namespace