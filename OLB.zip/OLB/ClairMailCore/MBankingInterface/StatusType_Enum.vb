﻿Imports System.Xml.Serialization

Namespace ClairMailCore.MBankingInterface
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
    Public Enum StatusType_Enum
        SUCCESS
        FAIL
    End Enum
End Namespace