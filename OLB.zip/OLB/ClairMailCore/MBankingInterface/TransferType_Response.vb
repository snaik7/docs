﻿Imports System.Xml.Serialization
Imports Arvest.WCF.OLB.ClairMailCore.MBankingModel.Transfer
Imports Arvest.Common

Namespace ClairMailCore.MBankingInterface
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
    Partial Public Class TransferType_Response
        Inherits Response_Type

        <XmlElement([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Transfer", Order:=0)>
        <XmlSerializeOptions(tagName:="transferConfirm")>
        Public Property transferConfirmation As TransferConfirmation_Type
    End Class
End Namespace