﻿Imports System.Xml.Serialization
Imports Arvest.Common

Namespace ClairMailCore.MBankingModel.Model
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Model")>
    Public Class NameValue_Type

        <XmlElement(Order:=0),
         XmlSerializeOptions(length:=20)>
        Public Property key As String

        <XmlElement(Order:=1),
         XmlSerializeOptions(length:=100)>
        Public Property value As String
    End Class
End Namespace