﻿Imports System.Xml.Serialization
Imports Arvest.WCF.OLB.ClairMailCore.MBankingModel.Account
Imports Arvest.Common

Namespace ClairMailCore.MBankingInterface
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
    Partial Public Class RecentTransfersType_Response
        Inherits Response_Type

        <XmlArray([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account", Order:=0)>
        <XmlSerializeOptions(tagName:="transactionL", arrayelementName:="transaction")>
        Public Property transactionList As Transaction_Type()
    End Class
End Namespace