﻿Imports System.Xml.Serialization
Imports Arvest.WCF.OLB.ClairMailCore.MBankingModel.Account
Imports Arvest.Common

Namespace ClairMailCore.MBankingInterface
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
    Partial Public Class BalanceType_Response
        Inherits Response_Type

        <XmlArray([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account", Order:=0)>
        <XmlSerializeOptions(arrayelementName:="account")>
        Public Property accountList As Account_Type()
    End Class
End Namespace