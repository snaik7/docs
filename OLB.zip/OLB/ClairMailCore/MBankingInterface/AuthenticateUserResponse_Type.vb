﻿Imports System.Xml.Serialization

Namespace ClairMailCore.MBankingInterface
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
    Partial Public Class AuthenticateUserResponse_Type
        Inherits Response_Type

        <XmlElement(Order:=0)>
        Property extUserId As String

        <XmlElement(Order:=1)>
        Property directId As String

        <XmlElement(Order:=2)>
        Property branchId As String = "Default"
    End Class
End Namespace