﻿Imports System.Xml.Serialization
Imports Arvest.WCF.OLB.ClairMailCore.MBankingModel.Account
Imports Arvest.Common

Namespace ClairMailCore.MBankingModel.Transfer
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Transfer")>
    Partial Public Class Transfer_Type

        <XmlElement(Order:=0)>
        Public Property transferId As String

        <XmlElement(Order:=1)>
        Public Property description As String

        <XmlElement(Order:=2)>
        <XmlSerializeOptions(tagName:="shortDesc")>
        Public Property shortDescription As String

        <XmlElement(Order:=3)>
        Public Property fromAccount As Account_Type

        <XmlElement(Order:=4)>
        Public Property toAccount As Account_Type

        <XmlElement(Order:=5)>
        Public Property amount As Amount_Type

        <XmlElement(DataType:="date", Order:=6)>
        <XmlSerializeOptions(dateTimeFormat:="MM/dd/yyyy")>
        Public Property nextDate As Date
    End Class
End Namespace