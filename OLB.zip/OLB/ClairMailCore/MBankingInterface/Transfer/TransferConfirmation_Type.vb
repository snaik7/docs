﻿Imports System.Xml.Serialization
Imports Arvest.WCF.OLB.ClairMailCore.MBankingInterface

Namespace ClairMailCore.MBankingModel.Transfer
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Transfer")>
    Partial Public Class TransferConfirmation_Type
        Inherits BankingConfirmation_Type

        <XmlElement(Order:=0)>
        Public Property transfer As Transfer_Type
    End Class
End Namespace