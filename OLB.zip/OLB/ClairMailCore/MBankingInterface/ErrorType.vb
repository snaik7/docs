﻿Imports System.ServiceModel

Namespace ClairMailCore.MBankingInterface
    <MessageContract()>
    Public Class ErrorType
        <MessageBodyMember([Namespace]:="http://validationservice.arvest.com/")>
        Property errorCode As String

        <MessageBodyMember([Namespace]:="http://validationservice.arvest.com/")>
        Property errorDesc As String
    End Class
End Namespace

