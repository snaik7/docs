﻿Imports System.Xml.Serialization
Imports Arvest.WCF.OLB.ClairMailCore.MBankingModel.Transfer
Imports Arvest.Common

Namespace ClairMailCore.MBankingInterface
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
    Partial Public Class ScheduledTransfersType_Response
        Inherits Response_Type

        <XmlArray([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Transfer", Order:=0)>
        <XmlSerializeOptions(arrayelementName:="transfer")>
        Public Property transferList As Transfer_Type()
    End Class
End Namespace