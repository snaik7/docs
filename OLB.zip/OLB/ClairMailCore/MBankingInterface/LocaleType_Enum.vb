﻿Imports System.CodeDom.Compiler
Imports System.Xml.Serialization

Namespace ClairMailCore.MBankingInterface
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
    Public Enum LocaleType_Enum
        es_AR
        en_AR
        pt_BR
        en_BR
        es_BR
        en_CA
        fr_CA
        fr_FR
        en_FR
        de_DE
        en_DE
        it_IT
        en_IT
        es_MX
        en_MX
        es_PE
        en_PE
        es_ES
        en_ES
        en_GB
        pl_GB
        en_US
        fr_US
        es_US
        es_VE
        en_VE
    End Enum
End Namespace
