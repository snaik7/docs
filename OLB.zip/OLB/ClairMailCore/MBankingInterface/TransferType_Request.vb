﻿Imports System.Xml.Serialization
Imports Arvest.WCF.OLB.ClairMailCore.MBankingModel.Transfer

Namespace ClairMailCore.MBankingInterface
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
    Partial Public Class TransferType_Request
        Inherits Request_Type

        <XmlElement([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Transfer", Order:=0)>
        Public Property transfer As Transfer_Type
    End Class
End Namespace