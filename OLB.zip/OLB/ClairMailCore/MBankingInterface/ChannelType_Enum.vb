﻿Imports System.Xml.Serialization

Namespace ClairMailCore.MBankingInterface
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
    Public Enum ChannelType_Enum
        SMS
        MWEB
        MCLIENT
        ENROLLMENT
    End Enum
End Namespace
