﻿Imports Arvest.WCF.OLB.ClairMailCore.MBankingModel.Model
Imports System.Xml.Serialization
Imports Arvest.WCF.OLB.ClairMailCore.MBankingModel.Account
Imports Arvest.Common

Namespace ClairMailCore.MBankingInterface
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
    Public Class ProcessRDCRequest_Type
        Inherits Request_Type

        <XmlElement([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account")>
        Property account As Account_Type

        <XmlElement([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account")>
        Property amount As Amount_Type

        <XmlElement([Namespace]:="http://validationservice.arvest.com/")>
        Property imageFormat As String

        <XmlElement([Namespace]:="http://validationservice.arvest.com/")>
        <XmlSerializeOptions(length:=8)>
        Property frontImage As String

        <XmlElement(Namespace:="http://validationservice.arvest.com/")>
        <XmlSerializeOptions(length:=8)>
        Property backImage As String

        <XmlArray([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Model")>
        Property properties As NameValue_Type()
    End Class
End Namespace
