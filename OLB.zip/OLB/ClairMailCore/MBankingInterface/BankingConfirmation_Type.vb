﻿Imports System.Xml.Serialization
Imports Arvest.WCF.OLB.ClairMailCore.MBankingModel.Account
Imports Arvest.WCF.OLB.ClairMailCore.MBankingModel.Transfer
Imports Arvest.Common

Namespace ClairMailCore.MBankingInterface
    '<XmlInclude(GetType(CancelPaymentConfirmation_Type)),
    ' XmlInclude(GetType(PaymentConfirmation_Type)),
    ' XmlInclude(GetType(StopPaymentConfirmation_Type)),
    ' XmlInclude(GetType(TransferConfirmation_Type)),
    ' XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account")>
    <XmlInclude(GetType(TransferConfirmation_Type)),
     XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account")>
    Partial Public Class BankingConfirmation_Type

        <XmlElement(Order:=0)>
        Public Property id As String

        <XmlElement(Order:=1)>
        <XmlSerializeOptions(tagName:="shortDesc")>
        Public Property shortDescription As String

        <XmlElement(Order:=2)>
        Public Property description As String

        <XmlElement(Order:=3)>
        Public Property status As ConfirmStatus_Enum = ConfirmStatus_Enum.WILL_BE_PROCESSED
    End Class
End Namespace
