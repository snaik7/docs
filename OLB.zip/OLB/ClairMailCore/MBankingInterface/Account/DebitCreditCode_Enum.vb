﻿Imports System.Xml.Serialization

Namespace ClairMailCore.MBankingModel.Account
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account")>
    Public Enum DebitCreditCode_Enum
        CREDIT
        DEBIT
    End Enum
End Namespace