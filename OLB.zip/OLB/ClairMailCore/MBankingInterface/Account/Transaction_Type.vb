﻿Imports System.Xml.Serialization
Imports Arvest.WCF.OLB.ClairMailCore.MBankingModel.Model
Imports Arvest.Common

Namespace ClairMailCore.MBankingModel.Account
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account")>
    Partial Public Class Transaction_Type

        'Private _postDate As Date

        <XmlElement(DataType:="date", Order:=0)>
        <XmlSerializeOptions(dateTimeformat:="MM/dd/yyyy")>
        Public Property postDate As Date

        <XmlElement(Order:=1)>
        Public Property id As String

        <XmlElement(Order:=2)>
        Public Property internalId As String

        <XmlElement(Order:=3)>
        Public Property type As TransactionType_Enum

        <XmlElement(Order:=4)>
        <XmlSerializeOptions(tagName:="shortDesc")>
        Public Property shortDescription As String

        <XmlElement(Order:=5)>
        Public Property description As String

        <XmlElement(Order:=6)>
        Public Property checkNumber As String

        <XmlElement(Order:=7)>
        Public Property status As TransactionStatus_Enum = TransactionStatus_Enum.PENDING

        <XmlElement(Order:=8)>
        Public Property location As String

        <XmlElement(Order:=9)>
        Public Property city As String

        <XmlElement(Order:=10)>
        Public Property merchant As String

        <XmlElement(Order:=11)>
        Public Property debitType As DebitCreditCode_Enum = DebitCreditCode_Enum.CREDIT

        <XmlElement(Order:=12)>
        Public Property fromAccount As Account_Type

        <XmlElement(Order:=13)>
        Public Property toAccount As Account_Type

        <XmlElement(Order:=14)>
        Public Property amount As Amount_Type

        <XmlElement(Order:=15)>
        Public Property payee As PaymentPayee_Type

        <XmlElement(Order:=16)>
        <XmlSerializeOptions(tagName:="customTrans")>
        Public Property customTransaction As String

        <XmlArray([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Model", Order:=17)>
        <XmlSerializeOptions(arrayElementName:="nameValue")>
        Public Property nameValueList As NameValue_Type()
    End Class
End Namespace