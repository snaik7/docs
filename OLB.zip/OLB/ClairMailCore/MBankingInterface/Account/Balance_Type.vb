﻿Imports System.Xml.Serialization
Imports Arvest.Common

Namespace ClairMailCore.MBankingModel.Account
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account")>
    Partial Public Class Balance_Type

        <XmlElement(Order:=0)>
        Public Property current As Amount_Type 'flat balance after processing

        <XmlElement(Order:=1)>
        Public Property available As Amount_Type 'memo posted - holds + flow

        <XmlElement(Order:=2)>
        <XmlSerializeOptions(tagName:="availableCred")>
        Public Property availableCredit As Amount_Type
    End Class
End Namespace


