﻿Imports System.Xml.Serialization
Imports Arvest.Common

Namespace ClairMailCore.MBankingModel.Account
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account")>
    Partial Public Class FilterParameters_Type

        <XmlElement(Order:=0)>
        <XmlSerializeOptions(tagName:="lowCheckNum")>
        Public Property lowCheckNumber As String

        <XmlElement(Order:=1)>
        <XmlSerializeOptions(tagName:="highCheckNum")>
        Public Property highCheckNumber As String

        <XmlElement(DataType:="date", Order:=2)>
        <XmlSerializeOptions(dateTimeformat:="MM/dd/yyyy")>
        Public Property fromDate As Date = Date.MinValue

        <XmlElement(DataType:="date", Order:=3)>
        <XmlSerializeOptions(dateTimeformat:="MM/dd/yyyy")>
        Public Property toDate As Date = Date.MaxValue

        <XmlElement(Order:=4)>
        Public Property lowAmount As Amount_Type

        <XmlElement(Order:=5)>
        Public Property highAmount As Amount_Type
    End Class
End Namespace

