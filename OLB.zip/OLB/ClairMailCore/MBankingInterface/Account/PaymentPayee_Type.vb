﻿Imports System.Xml.Serialization
Imports Arvest.WCF.OLB.ClairMailCore.MBankingModel.Model
Imports Arvest.Common

Namespace ClairMailCore.MBankingModel.Account
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account")>
    Public Class PaymentPayee_Type

        <XmlElement(Order:=0)>
        Public Property payeeId As String

        <XmlElement(Order:=1)>
        Public Property payeeName As String

        <XmlElement(Order:=2)>
        Public Property payeeNickname As String

        <XmlElement(Order:=3)>
        Public Property payeeAccount As String

        <XmlElement(Order:=4)>
        <XmlSerializeOptions(tagName:="defaultAcctId")>
        Public Property defaultAccountId As AccountId_Type

        <XmlElement(Order:=5)>
        Public Property defaultAmount As Amount_Type

        <XmlElement(DataType:="date", Order:=6)>
        <XmlSerializeOptions(tagName:="earliestPayD", dateTimeformat:="MM/dd/yyyy")>
        Public Property earliestPayDate As Date

        <XmlElement(DataType:="integer", Order:=7)>
        Public Property daysToPay As String

        <XmlArray([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Model", Order:=8)>
        <XmlSerializeOptions(arrayElementName:="nameValue")>
        Public Property nameValueList As NameValue_Type()
    End Class
End Namespace