﻿Imports System.Xml.Serialization

Namespace ClairMailCore.MBankingModel.Account
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account")>
    Public Enum TransactionStatus_Enum
        CANCELED
        FAILED
        POSTED
        PENDING
    End Enum
End Namespace