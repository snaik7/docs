﻿Imports System.Xml.Serialization

Namespace ClairMailCore.MBankingModel.Account
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account")>
    Public Enum TransactionType_Enum
        ATM
        CHECK
        CREDITCARD
        CUSTOM
        DEBITCARD
        DEPOSIT
        DIRECTDEBIT
        DIRECTDEPOSIT
        DIVIDEND
        FIFEE
        INTEREST
        NONSUFFICIENTFUNDSFEE
        OTHER
        OVERDRAFTFEE
        PAYMENT
        POS
        REPEATPAYMENT
        SERVICECHARGE
        TRANSFER
        CASHWITHDRAWAL
    End Enum
End Namespace


