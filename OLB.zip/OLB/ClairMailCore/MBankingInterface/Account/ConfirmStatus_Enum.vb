﻿Imports System.Xml.Serialization

Namespace ClairMailCore.MBankingModel.Account
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account")>
    Public Enum ConfirmStatus_Enum
        WILL_BE_PROCESSED
        WILL_NOT_BE_PROCESSED
    End Enum
End Namespace
