﻿Imports System.Xml.Serialization
Imports Arvest.Common
Imports Arvest.WCF.OLB.ClairMailCore.MBankingModel.Model

Namespace ClairMailCore.MBankingModel.Account
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account")>
    Public Class Account_Type

        <XmlElement(Order:=0)>
        Public Property accountId As AccountId_Type

        <XmlElement(Order:=1),
         XmlSerializeOptions(length:=100)>
        Public Property displayName As String

        <XmlElement(Order:=2),
         XmlSerializeOptions(length:=100)>
        Public Property nickName As String

        <XmlElement(Order:=3)>
        Public Property balance As Balance_Type

        <XmlElement(Order:=4)>
        Public Property primary As Boolean = False

        <XmlElement(Order:=5)>
        Public Property transferToOk As Boolean = True

        <XmlElement(Order:=6)>
        <XmlSerializeOptions(tagName:="xferFromOk")>
        Public Property transferFromOk As Boolean = True

        <XmlElement(Order:=7)>
        Public Property billPayOk As Boolean = True

        <XmlElement(Order:=8)>
        Public Property rdcOk As Boolean = True

        <XmlElement(Order:=9)>
        <XmlSerializeOptions(tagName:="dispAccntOk")>
        Public Property displayAccountOk As Boolean = True

        <XmlElement(Order:=10)>
        <XmlSerializeOptions(tagName:="displTxnOk")>
        Public Property displayTransactionsOk As Boolean = True

        <XmlElement(Order:=11)>
        Public Property accountClass As AccountClassType_Enum = AccountClassType_Enum.CHECKING

        <XmlArray([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Model", Order:=12)>
        <XmlSerializeOptions(arrayElementName:="nameValue")>
        Public Property nameValueList As NameValue_Type()

        <XmlElement(Order:=13)>
        Public Property routingTransitNumber As String

        <XmlElement(Order:=14)>
        Public Property eligibleforalertregistration As Boolean = False
    End Class
End Namespace