﻿Imports System.Xml.Serialization

Namespace ClairMailCore.MBankingModel.Account
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account")>
    Public Enum AccountClassType_Enum
        CARD
        CD
        CHECKING
        LOAN
        MONEY_MARKET
        OTHER
        SAVINGS
    End Enum
End Namespace
