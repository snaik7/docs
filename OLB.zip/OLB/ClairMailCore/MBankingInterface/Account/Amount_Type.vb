﻿Imports System.Xml.Serialization
Imports Arvest.Common

Namespace ClairMailCore.MBankingModel.Account
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account")>
    Partial Public Class Amount_Type

        <XmlElement(Order:=0),
         XmlSerializeOptions(length:=3)>
        Public Property currencyCode As String

        <XmlElement(Order:=1)>
        <XmlSerializeOptions(tagName:="currencySym", length:=1)>
        Public Property currencySymbol As String

        <XmlElement(Order:=2),
         XmlSerializeOptions(length:=20)>
        Public Property value As String
    End Class
End Namespace