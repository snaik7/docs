﻿Imports System.Xml.Serialization
Imports Arvest.Common

Namespace ClairMailCore.MBankingModel.Account
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account")>
    Public Class AccountId_Type

        <XmlElement(Order:=0),
         XmlSerializeOptions(length:=5)>
        Public Property companyId As String

        <XmlElement(Order:=1),
         XmlSerializeOptions(length:=5)>
        Public Property type As String

        <XmlElement(Order:=2),
         XmlSerializeOptions(length:=16)>
        Public Property number As String
    End Class
End Namespace