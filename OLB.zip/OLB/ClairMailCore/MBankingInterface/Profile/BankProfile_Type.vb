﻿Imports System.Xml.Serialization
Imports Arvest.WCF.OLB.ClairMailCore.MBankingModel.Account
Imports Arvest.WCF.OLB.ClairMailCore.MBankingModel.Model
Imports Arvest.Common

Namespace ClairMailCore.MBankingModel.Profile
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Profile")>
    Public Class BankProfile_Type

        <XmlElement(Order:=0)>
        Public Property disabledState As DisabledState_Type

        <XmlArray(Order:=1)>
        <XmlArrayItem([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account", IsNullable:=False)>
        <XmlSerializeOptions(tagName:="regAccts", arrayelementName:="account")>
        Public Property registeredAccounts As Account_Type()

        <XmlArray([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Model", Order:=2)>
        <XmlSerializeOptions(arrayelementName:="nameValue")>
        Public Property nameValueList As NameValue_Type()

        <XmlArray(Order:=3)>
        <XmlArrayItem([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Payment", IsNullable:=False)>
        <XmlSerializeOptions(arrayelementName:="paymentPayees")>
        Public Property payees As PaymentPayee_Type()

        <XmlElement(Order:=3)>
        <XmlSerializeOptions(tagName:="ExtBillPaySubscriberID")>
        Public Property extBillPaySubscriberID As String
    End Class
End Namespace