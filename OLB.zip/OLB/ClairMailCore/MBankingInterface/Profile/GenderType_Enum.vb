﻿Imports System.Xml.Serialization

Namespace ClairMailCore.MBankingModel.Profile
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Profile")>
    Public Enum GenderType_Enum
        M
        F
        U
    End Enum
End Namespace