﻿Imports System.Xml.Serialization
Imports Arvest.Common

Namespace ClairMailCore.MBankingModel.Profile
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Profile")>
    Partial Public Class Person_Type

        <XmlElement(Order:=0)>
        Public Property givenName As String

        <XmlElement(Order:=1)>
        Public Property middleName As String

        <XmlElement(Order:=2)>
        Public Property familyName As String

        <XmlElement(DataType:="date", Order:=3)>
        <XmlSerializeOptions(dateTimeformat:="MM/dd/yyyy")>
        Public Property dob As Date

        <XmlElement(Order:=4)>
        Public Property gender As GenderType_Enum = GenderType_Enum.U

        <XmlElement(Order:=5)>
        Public Property preferredLocale As String = "en_US"

        <XmlElement(Order:=6)>
        Public Property timeZone As String = "America/Chicago"

        <XmlElement(Order:=7)>
        Public Property userId As String

        <XmlElement(Order:=8)>
        Public Property profile As BankProfile_Type

        <XmlArray(Order:=9)>
        <XmlSerializeOptions(arrayelementName:="phoneNumber")>
        Public Property phoneNumbers As PhoneNumber_Type()

        <XmlArray(Order:=10)>
        <XmlSerializeOptions(arrayelementName:="emailAddress")>
        Public Property emailAddresses As String()

        <XmlElement(Order:=11)>
        Public Property ExtBillPaySubscriberID As String
    End Class
End Namespace