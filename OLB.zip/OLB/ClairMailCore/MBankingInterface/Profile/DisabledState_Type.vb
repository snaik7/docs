﻿Imports System.Xml.Serialization
Imports Arvest.Common

Namespace ClairMailCore.MBankingModel.Profile
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Profile")>
    Public Class DisabledState_Type

        <XmlElement(IsNullable:=True, Order:=0)>
        <XmlSerializeOptions(tagName:="isDisabledInd")>
        Public Property isDisabledIndicator As Nullable(Of Boolean)

        <XmlElement(IsNullable:=True, Order:=1)>
        <XmlSerializeOptions(tagName:="disabledDate", dateTimeformat:="MM/dd/yyyy")>
        Public Property disabledDateTime As Nullable(Of Date)
    End Class
End Namespace