﻿Imports System.Xml.Serialization

Namespace ClairMailCore.MBankingModel.Profile
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Profile")>
    Partial Public Class PhoneNumber_Type

        <XmlElement(Order:=0)>
        Public Property countryCode As String

        <XmlElement(Order:=1)>
        Public Property number As String
    End Class
End Namespace

