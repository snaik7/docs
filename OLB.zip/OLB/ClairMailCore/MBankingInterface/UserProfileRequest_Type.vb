﻿Imports System.Xml.Serialization

Namespace ClairMailCore.MBankingInterface
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
    Partial Public Class UserProfileRequest_Type
        Inherits Request_Type
    End Class
End Namespace

