﻿Imports System.Xml.Serialization
Imports Arvest.Common
Imports Arvest.WCF.OLB.ClairMailCore.MBankingModel.Model

Namespace ClairMailCore.MBankingInterface
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
    Partial Public Class AuthenticateUserRequest_Type
        Inherits Request_Type

        <XmlElement(Order:=0)>
        <XmlSerializeOptions(length:=64)>
        Public Property userName As String

        <XmlElement(Order:=1)>
        <XmlSerializeOptions(length:=64)>
        Public Property password As String

        <XmlArray([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Model", Order:=2)>
        <XmlSerializeOptions(arrayelementName:="nameValue")>
        Public Property nameValueList As NameValue_Type()
    End Class
End Namespace

