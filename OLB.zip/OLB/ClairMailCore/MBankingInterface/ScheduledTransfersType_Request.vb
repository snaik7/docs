﻿Imports System.Xml.Serialization
Imports Arvest.WCF.OLB.ClairMailCore.MBankingModel.Account

Namespace ClairMailCore.MBankingInterface
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
    Partial Public Class ScheduledTransfersType_Request
        Inherits Request_Type

        <XmlElement("account", [Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account", Order:=0)>
        Public Property account As Account_Type

        <XmlElement(Order:=1)>
        Public Property maxTrans As Integer
    End Class
End Namespace
