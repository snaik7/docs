﻿Imports System.Xml.Serialization

Namespace ClairMailCore.MBankingInterface
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
    Public Class Error_Type

        Public Sub New()

        End Sub

        Public Sub New(ByVal errorCode As String, ByVal errorSource As String, ByVal errorMessage As String)
            Me.errorCode = errorCode
            Me.errorSource = errorSource
            Me.errorMessage = errorMessage
        End Sub

        <XmlElement(Order:=0)>
        Public Property errorCode As String

        <XmlElement(Order:=1)>
        Public Property errorMessage As String

        <XmlElement(Order:=2)>
        Public Property errorSource As String

        Public Shared ReadOnly Property USER_NOT_FOUND As Error_Type
            Get
                Return New Error_Type("90002", "WCF", "User not found")
            End Get
        End Property

        Public Shared ReadOnly Property INVALID_PASSWORD As Error_Type
            Get
                Return New Error_Type("90004", "WCF", "Invalid password")
            End Get
        End Property

        Public Shared ReadOnly Property EXPIRED_PASSWORD As Error_Type
            Get
                Return New Error_Type("90005", "WCF", "Password has expired")
            End Get
        End Property

        Public Shared ReadOnly Property USER_LOCKED As Error_Type
            Get
                Return New Error_Type("90007", "WCF", "User id locked")
            End Get
        End Property
    End Class
End Namespace

