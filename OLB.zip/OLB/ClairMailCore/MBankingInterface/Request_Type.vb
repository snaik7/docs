﻿Imports System.Xml.Serialization
Imports System.ServiceModel
Imports Arvest.Common

Namespace ClairMailCore.MBankingInterface
    '<XmlInclude(GetType(DirectionsType_Request)),
    ' XmlInclude(GetType(LocationGeoCodeType_Request)),
    ' XmlInclude(GetType(LocationType_Request)),
    ' XmlInclude(GetType(PaymentPayees_Type)),
    ' XmlInclude(GetType(RecentPayments_Type)),
    ' XmlInclude(GetType(ScheduledPayments_Type)),
    ' XmlInclude(GetType(CancelPayment_Type)),
    ' XmlInclude(GetType(Pay_Type)),
    ' XmlInclude(GetType(AuthenticateUserNoLookupRequest_Type)),
    ' XmlInclude(GetType(AuthenticateUserRequest_Type)),
    ' XmlInclude(GetType(ValidateUserRequest_Type)),
    ' XmlInclude(GetType(UserProfileRequest_Type)),
    ' XmlInclude(GetType(UserRequest_Type)),
    ' XmlInclude(GetType(RecentTransfersType_Request)),
    ' XmlInclude(GetType(CancelTransferType_Request)),
    ' XmlInclude(GetType(ScheduledTransfersType_Request)),
    ' XmlInclude(GetType(TransferType_Request)),
    ' XmlInclude(GetType(AuthorizeTransferType_Request)),
    ' XmlInclude(GetType(TransactionHistoryType_Request)),
    ' XmlInclude(GetType(BalanceType_Request)),
    ' XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
    <XmlInclude(GetType(AuthenticateUserRequest_Type)),
     XmlInclude(GetType(UserProfileRequest_Type)),
     XmlInclude(GetType(UserRequest_Type)),
     XmlInclude(GetType(RecentTransfersType_Request)),
     XmlInclude(GetType(ScheduledTransfersType_Request)),
     XmlInclude(GetType(TransferType_Request)),
     XmlInclude(GetType(TransactionHistoryType_Request)),
     XmlInclude(GetType(BalanceType_Request)),
     XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
    Partial Public Class Request_Type

        <XmlElement(Order:=0)>
        <XmlSerializeOptions(length:=20)>
        Public Property request_id As String

        <XmlElement(Order:=1)>
        Public Property channel_id As ChannelType_Enum = ChannelType_Enum.MWEB

        <XmlElement(Order:=2)>
        <XmlSerializeOptions(length:=20)>
        Public Property extUserId As String

        <XmlElement(Order:=3)>
        <XmlSerializeOptions(datetimeFormat:="MM/dd/yyyy")>
        Public Property timestamp As Date = Date.Now

        <XmlElement(Order:=4)>
        <XmlSerializeOptions(tagName:="execOnRecov")>
        Public Property executeOnRecovery As Boolean

        <XmlElement(Order:=5)>
        Public Property locale As LocaleType_Enum = LocaleType_Enum.en_US
    End Class
End Namespace