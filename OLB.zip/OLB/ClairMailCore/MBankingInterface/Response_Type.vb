﻿Imports System.Xml.Serialization
Imports Arvest.Common

Namespace ClairMailCore.MBankingInterface
    <XmlInclude(GetType(AuthenticateUserResponse_Type)),
     XmlInclude(GetType(UserProfileResponse_Type)),
     XmlInclude(GetType(UserResponse_Type)),
     XmlInclude(GetType(RecentTransfersType_Response)),
     XmlInclude(GetType(ScheduledTransfersType_Response)),
     XmlInclude(GetType(TransferType_Response)),
     XmlInclude(GetType(TransactionHistoryType_Response)),
     XmlInclude(GetType(BalanceType_Response)),
     XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
    Public Class Response_Type

        <XmlElement(Order:=0)>
        Public Property status As StatusType_Enum = StatusType_Enum.SUCCESS

        <XmlElement(Order:=1)>
        Public Property locale As LocaleType_Enum = LocaleType_Enum.en_US

        <XmlElement("message", GetType(String), Order:=2)>
        Public Property message As String

        <XmlElement(GetType(Error_Type), Order:=3)>
        <XmlSerializeOptions(tagName:="error")>
        Public Property err As Error_Type
    End Class
End Namespace


