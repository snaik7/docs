﻿Imports Arvest.WCF.OLB.ClairMailCore.MBankingInterface
Imports System.Xml.Serialization

Namespace ClairMailCore.MBankingInterface
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
    Public Class ProcessRDCResponse_Type
        Inherits Response_Type

        <XmlElement([Namespace]:="http://validationservice.arvest.com/")>
        Property confirmationNumber As String

        <XmlElement([Namespace]:="http://validationservice.arvest.com/")>
        Property requestDuration As Long
    End Class
End Namespace