﻿Imports System.ServiceModel

Namespace ClairMailCore.MBankingInterface
    <MessageContract(Wrappername:="http://validationservice.arvest.com/")>
    Public Enum ReturnType
        Success
        [Error]
    End Enum
End Namespace

