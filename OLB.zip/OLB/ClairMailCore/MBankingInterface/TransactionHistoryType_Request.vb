﻿Imports System.Xml.Serialization
Imports Arvest.WCF.OLB.ClairMailCore.MBankingModel.Account
Imports Arvest.Common

Namespace ClairMailCore.MBankingInterface
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
    Partial Public Class TransactionHistoryType_Request
        Inherits Request_Type

        <XmlElement([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account", Order:=0)>
        Public Property account As Account_Type

        <XmlElement(Order:=1)>
        Public Property maxTrans As Integer

        <XmlElement([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account", Order:=2)>
        <XmlSerializeOptions(tagName:="filterParam")>
        Public Property filterParameters As FilterParameters_Type
    End Class
End Namespace

