﻿Imports System.Xml.Serialization
Imports Arvest.WCF.OLB.ClairMailCore.MBankingModel.Account
Imports Arvest.Common

Namespace ClairMailCore.MBankingInterface
    <XmlType([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingInterface")>
    Partial Public Class RecentTransfersType_Request
        Inherits Request_Type

        <XmlElement([Namespace]:="http://schemas.clairmail.com/2009/01/MBankingModel/Account", Order:=0)>
        <XmlSerializeOptions(tagName:="account")>
        Public Property account As Account_Type

        <XmlElement(Order:=1)>
        Public Property maxTrans As Integer
    End Class
End Namespace
