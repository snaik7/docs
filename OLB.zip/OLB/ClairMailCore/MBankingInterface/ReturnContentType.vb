﻿Imports System.ServiceModel

Namespace ClairMailCore.MBankingInterface
    <MessageContract()>
    Public Class ReturnContentType
        <MessageBodyMember([Namespace]:="http://validationservice.arvest.com/")>
        Property successType As SuccessType
    End Class
End Namespace

