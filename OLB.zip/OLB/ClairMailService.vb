﻿Imports System.Configuration
Imports System.Diagnostics
Imports System.Reflection
Imports System.ServiceModel
Imports System.Text.RegularExpressions
Imports System.Web
Imports System.Xml
Imports System.Linq
Imports System.Text
Imports System.Collections.Generic

Imports Arvest.Authentication
Imports Arvest.Authentication.DataContracts.Responses

Imports Arvest.Common
Imports Arvest.Common.DataAccess.DB2i
Imports Arvest.Common.WCF

Imports Arvest.ServiceReferences.Axm

Imports Arvest.WCF.OLB.ClairMailCore.MBankingInterface
Imports Arvest.WCF.OLB.ClairMailCore.MBankingModel.Account
Imports Arvest.WCF.OLB.ClairMailCore.Request
Imports Arvest.WCF.OLB.ClairMailCore.Response

Imports Arvest.WCF.OLB.DataAcess.D3
Imports Arvest.WCF.OLB.DataAcess.D3.DataAcessObjects

Imports Arvest.WCF.OLB.HostContracts
Imports Arvest.WCF.OLB.MobilePaymentWebService
Imports Arvest.WCF.OLB.RDC

Imports AuthInvalidPasswordException = Arvest.Authentication.InvalidPasswordException
Imports AuthLockedUserException = Arvest.Authentication.LockedUserException
Imports AuthUserNotFoundException = Arvest.Authentication.UserNotFoundException

Imports AxmInvalidPasswordException = Arvest.ServiceReferences.Axm.InvalidPasswordException
Imports AxmLockedUserException = Arvest.ServiceReferences.Axm.LockedUserException
Imports AxmUserNotFoundException = Arvest.ServiceReferences.Axm.UserNotFoundException

<ServiceBehavior(Namespace:="http://arvest.com/", ConcurrencyMode:=ConcurrencyMode.Multiple)>
Public Class ClairMailService
    Implements ClairMailContract, IWCFContract

    Private Const alogentProvider As String = "AlogentMobileDepositAuthorizationProvider"


    Private Shared endpointConfigurationName As String = ConfigurationManager.AppSettings("endpointConfigurationName")

    Private Shared hostTimeout As TimeSpan = TimeSpan.FromSeconds(Integer.Parse(ConfigurationManager.AppSettings("hostTimeout")))

    Private Shared log As New ArvestTraceSource(GetType(ClairMailService))
    Private Shared memoLog As New ArvestTraceSource(GetType(ClairMailService), RDCAction.memoPostDeposit.ToString)
    Private Shared duplicateDepositLog As New ArvestTraceSource(GetType(ClairMailService), RDCAction.isDuplicateDeposit.ToString)

    Private Shared connSwitch As New ConnectionSwitch(New ConnectionInfo With {.ConnectionStringSettings = ConfigurationManager.ConnectionStrings("AS400"),
                                                                               .Schema = "ABOLIB"},
                                                      New ConnectionInfo With {.ConnectionStringSettings = ConfigurationManager.ConnectionStrings("AS400ATM"),
                                                                               .Schema = "ABOSERVICE"},
                                                      TimeSpan.FromSeconds(Integer.Parse(ConfigurationManager.AppSettings("connectionSwitchInterval"))))

    Sub New()
        Trace.CorrelationManager.ActivityId = Guid.NewGuid
    End Sub

    Public Function AuthenticateUser(ByVal request As AuthenticateUserRequest) As AuthenticateUserResponse Implements ClairMailContract.authenticateUser
        Dim userName As String
        Dim password As String

        If request Is Nothing Then
            Return CreateError(Of AuthenticateUserResponse)(Error_Type.USER_NOT_FOUND)
        End If

        With request.authenticateUserRequest
            userName = .userName
            password = .password
        End With

        If String.IsNullOrEmpty(userName) Then
            Return CreateError(Of AuthenticateUserResponse)(Error_Type.USER_NOT_FOUND)
        End If

        If String.IsNullOrEmpty(password) Then
            Return CreateError(Of AuthenticateUserResponse)(Error_Type.INVALID_PASSWORD)
        End If

        Try
            Dim verifyMobileUser As VerifyMobileUserResponse = Authenticator.VerifyMobileUser(userName)

            Dim extUserId As String

            'If user is registered for D3, authenticate against AxM. Else, authenticate against S1.
            If verifyMobileUser IsNot Nothing AndAlso verifyMobileUser.IsRegisteredForD3 Then
                Try
                    Authenticator.AuthenticateUser(userName, password)
                Catch ex As AxmUserNotFoundException
                    Return CreateError(Of AuthenticateUserResponse)(Error_Type.USER_NOT_FOUND)
                Catch ex As AxmLockedUserException
                    Return CreateError(Of AuthenticateUserResponse)(Error_Type.USER_LOCKED)
                Catch ex As AxmInvalidPasswordException
                    Return CreateError(Of AuthenticateUserResponse)(Error_Type.INVALID_PASSWORD)
                Catch ex As ExpiredPasswordException
                    Return CreateError(Of AuthenticateUserResponse)(Error_Type.EXPIRED_PASSWORD)
                Catch ex As ExpiredAccountException
                    Return CreateError(Of AuthenticateUserResponse)(Error_Type.USER_LOCKED)
                End Try

                extUserId = verifyMobileUser.ExternalConsumerId
            ElseIf verifyMobileUser IsNot Nothing AndAlso verifyMobileUser.IsOptedOutForD3 Then
                Return CreateError(Of AuthenticateUserResponse)(Error_Type.USER_LOCKED)
            Else
                Try
                    extUserId = Authenticator.AuthenticateS1User(userName, password)
                Catch ex As AuthUserNotFoundException
                    Return CreateError(Of AuthenticateUserResponse)(Error_Type.USER_NOT_FOUND)
                Catch ex As AuthLockedUserException
                    Return CreateError(Of AuthenticateUserResponse)(Error_Type.USER_LOCKED)
                Catch ex As AuthInvalidPasswordException
                    Return CreateError(Of AuthenticateUserResponse)(Error_Type.INVALID_PASSWORD)
                Catch ex As ResetPasswordException
                    Return CreateError(Of AuthenticateUserResponse)(Error_Type.EXPIRED_PASSWORD)
                End Try
            End If

            AuthenticateUser = New AuthenticateUserResponse

            AuthenticateUser.authenticateUserResponse.extUserId = extUserId

            Return AuthenticateUser
        Catch ex As Exception
            ex.AddData("request", request, {"password"})

            Return CreateError(Of AuthenticateUserResponse)(ex)
        End Try
    End Function

    Public Function AuthenticateUserRSA(ByVal request As AuthenticateUserRSARequest) As AuthenticateUserRSAResponse Implements ClairMailContract.authenticateUserRSA
        If request Is Nothing Then
            Return CreateError(Of AuthenticateUserRSAResponse)(Error_Type.USER_NOT_FOUND)
        End If

        Dim userName As String = request.authenticateUserRequest.userName

        If String.IsNullOrEmpty(userName) Then
            Return CreateError(Of AuthenticateUserRSAResponse)(Error_Type.USER_NOT_FOUND)
        End If

        Try
            Dim verifyMobileUse As VerifyMobileUserResponse = Authenticator.VerifyMobileUser(userName)

            If verifyMobileUse Is Nothing Then
                Return CreateError(Of AuthenticateUserRSAResponse)(Error_Type.USER_NOT_FOUND)
            End If

            AuthenticateUserRSA = New AuthenticateUserRSAResponse

            With AuthenticateUserRSA.authenticateUserRSAResponse
                .extUserId = verifyMobileUse.ExternalConsumerId
                .extUserRSAId = verifyMobileUse.AdaptiveAuthId
            End With

            Return AuthenticateUserRSA
        Catch ex As Exception
            ex.AddData("request", request, {"password"})

            Return CreateError(Of AuthenticateUserRSAResponse)(ex)
        End Try
    End Function

    Public Function GetBalance(ByVal request As GetBalanceRequest) As GetBalanceResponse Implements ClairMailContract.getBalance
        Return SendToHostWrapper(Of GetBalanceResponse)(request, "MOBGETBAL(?, ?)", "getBalanceReq")
    End Function

    Public Function GetRecentTransfers(ByVal request As GetRecentTransfersRequest) As GetRecentTransfersResponse Implements ClairMailContract.getRecentTransfers
        Throw New NotImplementedException
    End Function

    Public Function GetScheduledTransfers(ByVal request As GetScheduledTransfersRequest) As GetScheduledTransfersResponse Implements ClairMailContract.getScheduledTransfers
        Throw New NotImplementedException
    End Function

    Public Function GetTransactionHistory(ByVal request As GetTransactionHistoryRequest) As GetTransactionHistoryResponse Implements ClairMailContract.getTransactionHistory
        Return SendToHostWrapper(Of GetTransactionHistoryResponse)(request, "MOBGETHIST(?)", "getTHistReq")
    End Function

    Public Function GetUser(ByVal request As GetUserRequest) As GetUserResponse Implements ClairMailContract.getUser
        GetUser = SendToHostWrapper(Of GetUserResponse)(request, "MOBGETUSER(?)", "getUserReq")

        If GetUser.GetUserResponse.status = StatusType_Enum.FAIL OrElse GetUser.AxmId = "0" Then
            Return GetUser
        End If

        Try
            GetUser.GetUserResponse.person.ExtBillPaySubscriberID = D3DataAcess.GetSubscriberId(GetUser.AxmId)
        Catch ex As Exception
            ex.AddData("request", request)

            Return CreateError(Of GetUserResponse)(ex)
        End Try

        Return GetUser
    End Function

    Public Function GetUserProfile(ByVal request As GetUserProfileRequest) As GetUserProfileResponse Implements ClairMailContract.getUserProfile
        GetUserProfile = SendToHostWrapper(Of GetUserProfileResponse)(request, "MOBGETUPRF(?, ?)", "getUserPrReq")

        If GetUserProfile.GetUserProfileResponse.status = StatusType_Enum.FAIL OrElse GetUserProfile.AxmId = "0" Then
            Return GetUserProfile
        End If

        Try
            Dim d3Data As D3User = D3DataAcess.GetD3User(GetUserProfile.AxmId)

            GetUserProfile.GetUserProfileResponse.profile.extBillPaySubscriberID = d3Data.SubscriberId

            For Each account As Account_Type In GetUserProfile.GetUserProfileResponse.profile.registeredAccounts
                Dim tempAccount As Account = Nothing

                If d3Data.Accounts.TryGetValue(account.accountId.number, tempAccount) Then
                    account.displayName = tempAccount.Nickname
                    account.displayAccountOk = tempAccount.IsVisible
                    account.accountId.number = tempAccount.Account
                Else
                    account.accountId.number = Right(account.accountId.number, 16).TrimStart({"0"c})
                End If
            Next
        Catch ex As Exception
            ex.AddData("request", request)

            Return CreateError(Of GetUserProfileResponse)(ex)
        End Try

        Return GetUserProfile
    End Function

    Public Function Transfer(ByVal request As TransferRequest) As TransferResponse Implements ClairMailContract.transfer
        Return SendToHostWrapper(Of TransferResponse)(request, "MOBXFER(?)", "xsferReq")
    End Function

    Public Function RemoteDeposit(ByVal request As RemoteDepositRequest) As RemoteDepositResponse Implements ClairMailContract.remoteDeposit
        If request Is Nothing Then
            Throw New ArgumentNullException("request").DoNotTrace()
        End If

        Dim rdcRequest As ProcessRDCRequest_Type = request.processRDCRequest

        If rdcRequest Is Nothing Then
            Throw New ArgumentNullException("processRDCRequest").DoNotTrace()
        End If

        Dim extUserId As String = rdcRequest.extUserId
        Dim frontImage As String = rdcRequest.frontImage
        Dim backImage As String = rdcRequest.backImage
        Dim frontImageAsByte() As Byte
        Dim backImageAsByte() As Byte
        Dim account As Account_Type = rdcRequest.account
        Dim amount As Amount_Type = rdcRequest.amount
        Dim accountNumber As Long?
        Dim accntType As AccountType
        Dim amountValue As Decimal?
        Dim deviceId As String = (From prop In rdcRequest.properties
                                  Where prop.key = "DeviceId"
                                  Select prop.value).FirstOrDefault

        If account IsNot Nothing Then
            Dim accountId As AccountId_Type = account.accountId

            If accountId IsNot Nothing Then
                Dim _accountNumber As String = accountId.number

                If Not String.IsNullOrEmpty(_accountNumber) AndAlso IsNumeric(_accountNumber) Then
                    accountNumber = Long.Parse(_accountNumber)
                End If

                'Default to DDA
                [Enum].TryParse(accountId.type, accntType)
            End If
        End If

        If amount IsNot Nothing Then
            Dim _amountValue As String = amount.value

            If Not String.IsNullOrEmpty(_amountValue) AndAlso IsNumeric(_amountValue) Then
                amountValue = Decimal.Parse(_amountValue)
            End If
        End If

        ''added to log channel_id
        'Dim _channelID As ChannelType_Enum = rdcRequest.channel_id
        'Dim channelID As String = _channelID.ToString()
        'Dim arvGO As Integer
        'Dim monitise As Integer
        'Select Case channelID
        '    Case "MWEB"
        '        arvGO = 1
        '        monitise = 0
        '    Case "MCLIENT"
        '        arvGO = 0
        '        monitise = 1
        '    Case Else
        '        arvGO = 0
        '        monitise = 0
        'End Select

        Dim transactionId As Long = RDCLog.CreateTransaction(extUserId, accountNumber, accntType, amountValue, deviceId, rdcRequest.channel_id)

        If frontImage Is Nothing Then
            Return CreateRDCError(transactionId, RDCError.INVALID_FRONT_IMAGE)
        End If

        If backImage Is Nothing Then
            Return CreateRDCError(transactionId, RDCError.INVALID_BACK_IMAGE)
        End If

        If accountNumber Is Nothing Then
            Return CreateRDCError(transactionId, RDCError.INVALID_ACCOUNT)
        End If

        If amountValue Is Nothing Then
            Return CreateRDCError(transactionId, RDCError.INVALID_AMOUNT)
        End If

        'If accntType Is Nothing Then
        '    Return CreateRDCError(transactionId, RDCError.INVALID_ACCOUNT_TYPE)
        'End If

        Try
            frontImageAsByte = Convert.FromBase64String(frontImage)
        Catch ex As FormatException
            Return CreateRDCError(transactionId, RDCError.RECAPTURE_FRONT("Can not convert frontImage from Base-64 string." & ex.GetMessages()))
        End Try

        Try
            backImageAsByte = Convert.FromBase64String(backImage)
        Catch ex As FormatException
            Return CreateRDCError(transactionId, RDCError.RECAPTURE_BACK("Can not convert backImage from Base-64 string." & ex.GetMessages()))
        End Try

        RDCLog.Log(transactionId, RDCAction.remoteDeposit, TraceEventType.Information, "Performing velocity check.")

        Dim rdcHostResponse As RDCHostResponse

        Try
            Dim info As ConnectionInfo = connSwitch.ActiveConnectionInfo

            rdcHostResponse = SendXmlToDB2(Of RDCHostResponse)(New With
                                                               {
                                                                    .userId = extUserId,
                                                                    .depositAmount = amountValue.ToString,
                                                                    .transactionId = transactionId
                                                               },
                                                               info.ConnectionStringSettings,
                                                               String.Format("Call {0}.MOBVELO(?)", info.Schema), "request", hostTimeout)
        Catch ex As TimeoutException
            log.TraceError(ex.GetStackTraces())

            Return CreateRDCError(transactionId, RDCError.TIMEOUT("Host", "Volcity check timed out."))
        Catch ex As Exception
            ex.Source = "Host"

            Return CreateRDCError(transactionId, ex)
        End Try

        Dim velocityMessage As String = rdcHostResponse.message

        If rdcHostResponse.accept = False Then
            Select Case rdcHostResponse.code
                Case 320001
                    Return CreateRDCError(transactionId, RDCError.DAILY_VELOCITY(velocityMessage))
                Case 320002
                    Return CreateRDCError(transactionId, RDCError.MONTHLY_VELOCITY(velocityMessage))
                Case Else
                    log.TraceError("remoteDeposit: {0}, Velocity Not Accepted; {1} '{2}'", transactionId, rdcHostResponse.code, velocityMessage)

                    Return CreateRDCError(transactionId, RDCError.HOST_ERROR(rdcHostResponse.code.ToString, velocityMessage))
            End Select
        End If

        RDCLog.Log(transactionId, RDCAction.remoteDeposit, TraceEventType.Information, velocityMessage)

        Dim depositRequest As New Deposit_Submit_Request With {.ApiVersion = New ApiVersionType,
                                                               .UiCulture = UiCultureType.enUS,
                                                               .AuthorizationProvider = alogentProvider,
                                                               .SingleItemDeposit = New SingleItemDepositType}

        With depositRequest.ApiVersion
            .Major = 1
            .Minor = 0
        End With

        With depositRequest.SingleItemDeposit
            .DepositorId = extUserId
            .MasterUserId = transactionId.ToString
            .DepositAccount = New DepositAccountType
            .Cheque = New ChequeType

            .SourceDevice = New SourceDeviceType With {.Type = "Phone",
                                                       .Id = rdcRequest.properties(0).value}

            With .DepositAccount
                .AccountNumber = accountNumber.ToString

                Select Case accntType
                    Case AccountType.DDA
                        .TransactionCode = "215"
                        .RT = "502303215"
                    Case AccountType.SAV
                        .TransactionCode = "116"
                        .RT = "502306116"
                End Select

                '.RT = 502303115 for when we deposit images on statements
            End With

            With .Cheque
                .Amount = CDec(amountValue)

                Dim imageFormat As ImageType

                If Not [Enum].TryParse(rdcRequest.imageFormat, True, imageFormat) Then
                    imageFormat = ImageType.JPEG
                End If

                .ImageFront = New ItemImageDefinitionType With {.Type = imageFormat,
                                                                .Image = frontImageAsByte}
                .ImageRear = New ItemImageDefinitionType With {.Type = imageFormat,
                                                               .Image = backImageAsByte}
            End With
        End With

        RDCLog.Log(transactionId, RDCAction.remoteDeposit, TraceEventType.Information, "Calling Allogent Deposit_Submit")

        Dim depositResponse As Deposit_Submit_Response
        Dim requestDuration As Double = Now.Ticks

        Try
            depositResponse = WCFUtil.UseClient(AddressOf (New MobilePaymentWebServiceClient(endpointConfigurationName)).Deposit_Submit, depositRequest)

            requestDuration = (Now.Ticks - requestDuration) / 10000000
        Catch ex As EndpointNotFoundException
            AddAlogentRequestToExceptionData(ex, depositRequest)

            log.TraceError(ex.GetStackTraces())

            Return CreateRDCError(transactionId, RDCError.COM_ERROR(ex.GetMessages()))
        Catch ex As FaultException When ex.Message.EndsWith("It appears you submitted 2 images of front of check.  Please retake both front and rear photos..")
            Return CreateRDCError(transactionId, RDCError.RECAPTURE_BACK(ex.Message))
        Catch ex As FaultException When ex.Message.ToLower.Contains("please retake")
            Return CreateRDCError(transactionId, RDCError.RECAPTURE_FRONT(ex.Message))
        Catch ex As FaultException When ex.Message = "Please enter the Amount field" OrElse
            ex.Message.EndsWith("The amount you entered did not match the amount detected. Please re-enter amount and retake photo..")

            Return CreateRDCError(transactionId, RDCError.RESUBMIT_AMOUNT(ex.Message))
        Catch ex As FaultException When ex.Message = "The document may have been submitted in a previous transaction." OrElse
            ex.Message.Contains("This check has already been submitted. We cannot accept it again") OrElse
            ex.Message = "Duplicate check detected."

            duplicateDepositLog.TraceError("Transaction Id: {2} {0} {1}" &
                                           "User Id: {3} {0} {1}" &
                                           "Account: {4} {0} {1}" &
                                           "Account Type: {5} {0} {1}" &
                                           "Amount: {6} {0} {1}" &
                                           "Response Message: {7}",
                                           vbCrLf, vbTab,
                                           transactionId,
                                           extUserId,
                                           accountNumber,
                                           accntType,
                                           Format(amountValue, "C"),
                                           ex.Message)

            Return CreateRDCError(transactionId, RDCError.DUPLICATE(ex.Message))
        Catch ex As FaultException When ex.Message.EndsWith("Canadian checks are not allowed in the deposit.") OrElse
            ex.Message.Contains("Only United States Checks can be processed")

            Return CreateRDCError(transactionId, RDCError.FOREIGN(ex.Message))
        Catch ex As FaultException When ex.Message = "Error in the application."
            Return CreateRDCError(transactionId, RDCError.COM_ERROR(ex.GetMessages()))
        Catch ex As FaultException When ex.Message = "The image processing service (Mitek) failed to convert JPEG images to TIFF format.Request Result: 0," &
            " IQA Message: Could not find endorsement on back of check: make sure check is endorsed! Retake photo.."

            Return CreateRDCError(transactionId, RDCError.RECAPTURE_BACK(ex.GetMessages()))
        Catch ex As FaultException When ex.Message = "Timed out waiting for response from application server."
            AddAlogentRequestToExceptionData(ex, depositRequest)

            log.TraceError(ex.GetStackTraces())

            Return CreateRDCError(transactionId, RDCError.TIMEOUT("Alogent", ex.Message))
        Catch ex As TimeoutException
            AddAlogentRequestToExceptionData(ex, depositRequest)

            log.TraceError(ex.GetStackTraces())

            Return CreateRDCError(transactionId, RDCError.TIMEOUT("Alogent", ex.Message))
        Catch ex As Exception
            ex.Source = "Alogent"
            AddAlogentRequestToExceptionData(ex, depositRequest)

            Return CreateRDCError(transactionId, ex)
        End Try

        If depositResponse.Result = ResultType.Failed Then
            Return CreateRDCError(transactionId, RDCError.DEPOSIT_FAILED)
        End If

        If depositResponse.Result = ResultType.PendingReview Then
            Return CreateRDCError(transactionId, RDCError.DEPOSIT_PENDING)
        End If

        Dim confirmationNumber As String = depositResponse.Transaction.TransactionId

        RDCLog.Log(transactionId, RDCAction.remoteDeposit, TraceEventType.Information,
                   String.Format("Deposit Success. transactionId: '{0}', itemSequenceNumber: '{1}', requestDuration: '{2}'",
                                 confirmationNumber, depositResponse.Transaction.ItemSequenceNumber, requestDuration), True)

        RemoteDeposit = New RemoteDepositResponse With {.remoteDepositResponse = New ProcessRDCResponse_Type}

        With RemoteDeposit.remoteDepositResponse
            .confirmationNumber = confirmationNumber
            .requestDuration = CLng(requestDuration)
        End With

        Return RemoteDeposit
    End Function

    Public Function IsDuplicateDeposit(ByVal request As DuplicateDepositRequest) As Boolean Implements ClairMailContract.isDuplicateDeposit
        ThrowIfNull(request, "request")

        Dim transactionId As Long = Long.Parse(request.masterUserId)
        Dim checkNumber As String = If(request.checkNumber, String.Empty).Trim
        Dim outOfAccount As String = If(request.outOfAccount, String.Empty).Trim
        Dim routingNumber As String = If(request.routingNumber, String.Empty).Trim

        RDCLog.Log(transactionId, RDCAction.isDuplicateDeposit, TraceEventType.Information, String.Format("Calling Duplicate Check. checkNumber: '{0}', " &
                                                                                                          "outOfAccount: '{1}', routingNumber: '{2}'",
                                                                                                          checkNumber, outOfAccount, routingNumber))

        request.checkNumber = checkNumber
        request.outOfAccount = outOfAccount
        request.routingNumber = routingNumber

        Dim message As String = Nothing
        Dim eventType As TraceEventType

        Try
            Try
                Long.Parse(checkNumber)
            Catch ex As Exception When TypeOf ex Is FormatException OrElse TypeOf ex Is OverflowException
                Throw New FormatException(String.Format("Cannot convert checkNumber '{0}' to Long.", checkNumber), ex).DoNotTrace
            End Try

            Dim info As ConnectionInfo = connSwitch.ActiveConnectionInfo

            Dim rdcHostResponse As RDCHostResponse = SendXmlToDB2(Of RDCHostResponse)(request, info.ConnectionStringSettings,
                                                                                      String.Format("Call {0}.MOBDUPCHK(?)", info.Schema), "request",
                                                                                      hostTimeout)

            Dim code As Integer = rdcHostResponse.code

            IsDuplicateDeposit = Not rdcHostResponse.accept

            message = String.Format("{0}, {1}", code, rdcHostResponse.message)

            If code <> 0 AndAlso code <> 320003 AndAlso code <> 320004 AndAlso code <> 20004 Then
                eventType = TraceEventType.Error

                log.TraceError("isDuplicateDeposit. accept: '{0}', code: '{1}', message: '{2}'",
                                    rdcHostResponse.accept, code, rdcHostResponse.message)
            Else
                eventType = TraceEventType.Information
            End If

            Return IsDuplicateDeposit
        Catch ex As Exception
            message = ex.GetMessages()
            eventType = TraceEventType.Error

            Throw ex.PreserveStackTrace()
        Finally
            RDCLog.Log(transactionId, RDCAction.isDuplicateDeposit, eventType, message)
        End Try
    End Function

    Public Sub MemoPostDeposit(ByVal request As MemoPostDepositRequest) Implements ClairMailContract.memoPostDeposit
        ThrowIfNull(request, "request")

        Dim transactionId As Long = Long.Parse(request.masterUserId)

        RDCLog.Log(transactionId, RDCAction.memoPostDeposit, TraceEventType.Information, "Calling Memo Post")

        Dim rdcHostResponse As RDCHostResponse
        Dim message As String = Nothing
        Dim eventType As TraceEventType

        Try
            Dim info As ConnectionInfo = connSwitch.ActiveConnectionInfo

            rdcHostResponse = SendXmlToDB2(Of RDCHostResponse)(request,
                                                               info.ConnectionStringSettings,
                                                               String.Format("Call {0}.MOBMEMOPST(?)", info.Schema),
                                                               "request", hostTimeout)

            Dim code As Integer = rdcHostResponse.code

            message = String.Format("{0}, {1}", code, rdcHostResponse.message)

            If rdcHostResponse.accept = True Then
                eventType = TraceEventType.Information
            Else
                Dim ex As New Exception(message) With {.Source = "Host"}

                If code = 2 Then
                    ex.DoNotTrace()
                End If

                Throw ex
            End If
        Catch ex As Exception
            message = ex.GetMessages()
            eventType = TraceEventType.Error

            memoLog.TraceError("Transaction Id: {2} {0} {1}" &
                               "Account: {3} {0} {1}" &
                               "Account Type: {4} {0} {1}" &
                               "Amount: {5} {0} {1}" &
                               "ISN: {6} {0} {1}" &
                               "Host Response Message: {7}",
                               vbCrLf, vbTab,
                               transactionId,
                               request.intoAccount,
                               request.intoAcctType,
                               Format(request.depositAmount, "C"),
                               request.isn,
                               message)

            Throw ex.PreserveStackTrace()
        Finally
            RDCLog.Log(transactionId, RDCAction.memoPostDeposit, eventType, message)
        End Try
    End Sub

    Public Function IsServerAlive() As Boolean Implements IWCFContract.IsServerAlive
        Return True
    End Function

    Public Function PendingItems(ByVal request As CB_GetMemoPostTransactionsRequest) As CB_GetMemoPostTransactionsResponse Implements ClairMailContract.PendingItems
        request.AcctId = Left(Clean.CleanData(request.AcctId), 12)

        If request.AcctId.Length = 0 Then
            Return ErrorResponse(Of CB_GetMemoPostTransactionsResponse)("5", "Invalid Account Number", "Error", "Client")
        End If

        If Not [Enum].IsDefined(GetType(CorAcctType), request.AcctType) Then
            Return ErrorResponse(Of CB_GetMemoPostTransactionsResponse)("6", "Invalid Acct Type", "Error", "Client")
        End If

        Dim builder As New StringBuilder

        Try
            Dim info As ConnectionInfo = connSwitch.ActiveConnectionInfo

            Dim parameters As Object() =
            {
                request.AcctId,
                request.AcctType.ToString
            }

            Dim returnObjs As IEnumerable(Of Object) = ArvestDB2iSqlCommand.ExecuteOutputParmeters(
                info.ConnectionStringSettings,
                "CALL ABOLIB.PENDINGITM(?, ?, ?, ?, ?, ?, ?)",
                parameters,
                hostTimeout:=hostTimeout,
                defaultValue:=String.Empty)

            For Each xmlData As String In returnObjs
                builder.Append(xmlData)
            Next

            Dim response As New CB_GetMemoPostTransactionsResponse

            response.AcctBasic = (New ArvestXmlSerializer()).Deserialize(Of List(Of CB_GetMemoPostTransactionResponseList))(
                builder.ToString.Replace("&", "&amp;"),
                serializeOptions:=New XmlSerializeOptionsAttribute With {.ArrayElementName = "Trans"})

            If response.AcctBasic Is Nothing Then
                response.AcctBasic = New List(Of CB_GetMemoPostTransactionResponseList)
            End If

            Return response
        Catch ex As Exception
            ex.Data.Add("request", (New ArvestXmlSerializer).Serialize(request, New XmlWriterSettings With {.OmitXmlDeclaration = True}))

            Return ErrorResponse(Of CB_GetMemoPostTransactionsResponse)("3", "Problem Sending Host Communications", "Error", "HOST", ex)
        End Try
    End Function

    Private Function ErrorResponse(Of T As {New, ErrorResponse})(ByVal errNum As String, ByVal errDesc As String,
                                                                       Optional ByVal severity As String = Nothing,
                                                                       Optional ByVal source As String = Nothing, Optional ByVal ex As Exception = Nothing) As T
        If ex IsNot Nothing Then
            log.TraceError(ex.GetStackTraces)
        End If

        Return New T With {
                           .ErrNum = errNum,
                           .ErrDesc = errDesc,
                           .Severity = If(severity, String.Empty),
                           .Source = If(source, String.Empty)
                          }
    End Function

    Private Shared Function SendToHostWrapper(Of TResponse As New)(ByVal request As Object, ByVal procedureName As String, ByVal rootXml As String) As TResponse
        Try
            SanitizeProperties(request, Function(input As String) As String
                                            If input Is Nothing Then
                                                Return Nothing
                                            End If

                                            Return HttpUtility.HtmlDecode(input)
                                        End Function)

            Dim requestProp As PropertyInfo = request.GetType.GetProperties()(0)

            'Catch usernames with special characters for authUser and authUserRSA to avoid conversion exceptions when sending to host
            If GetType(AuthenticateUserRequest_Type).Equals(requestProp.PropertyType) Then
                Dim authRequest As AuthenticateUserRequest_Type = CType(requestProp.GetValue(request, Nothing), AuthenticateUserRequest_Type)

                If authRequest IsNot Nothing Then
                    If authRequest.userName IsNot Nothing AndAlso HasSpecialCharacter(authRequest.userName) Then
                        Return CreateError(Of TResponse)(Error_Type.USER_NOT_FOUND)
                    ElseIf authRequest.password IsNot Nothing AndAlso HasSpecialCharacter(authRequest.password) Then
                        Return CreateError(Of TResponse)(Error_Type.INVALID_PASSWORD)
                    End If
                End If
            End If

            Dim info As ConnectionInfo = connSwitch.ActiveConnectionInfo

            SendToHostWrapper = SendXmlToDB2(Of TResponse)(request,
                                                           info.ConnectionStringSettings,
                                                           String.Format("Call {0}.{1}", info.Schema, procedureName),
                                                           rootXml, hostTimeout)

            Dim responseType As Response_Type = CType(GetType(TResponse).GetProperties()(0).GetValue(SendToHostWrapper, Nothing), Response_Type)

            If responseType IsNot Nothing AndAlso responseType.err IsNot Nothing AndAlso responseType.err.errorCode IsNot Nothing AndAlso
                responseType.err.errorCode = "20000" Then

                Dim xml As String = FilterXml(request,
                                              (New ArvestXmlSerializer).Serialize(request, New XmlWriterSettings With {.OmitXmlDeclaration = True}, rootXml))

                log.TraceWarning("SQL error 20000 occurred: {0}" & vbCrLf &
                                      vbTab & "XML sent to host: {1}", responseType.err.errorMessage, xml)

                responseType.err.errorMessage = "System is currently unavailable please try again later."
            End If

            Return SendToHostWrapper
        Catch ex As Exception
            If ex.Data.Contains("XML sent to host") Then
                ex.Data("XML sent to host") = FilterXml(request, CStr(ex.Data("XML sent to host")))
            End If

            If ex.Data.Contains("XML returned from host") Then
                ex.Data("XML returned from host") = FilterXml(request, CStr(ex.Data("XML returned from host")))
            End If

            ex.Source = "Host"

            Return CreateError(Of TResponse)(ex)
        End Try
    End Function

    Private Shared Function FilterXml(ByVal request As Object, ByVal xmlData As String) As String
        If TypeOf request Is AuthenticateUserRequest Then
            Return Regex.Replace(xmlData, "<password>.*</password>", "<password>*</password>")
        End If

        Return xmlData
    End Function

    Private Shared Function CreateRDCError(ByVal transactionId As Long, ByVal ex As Exception) As RemoteDepositResponse
        RDCLog.Log(transactionId, RDCAction.remoteDeposit, TraceEventType.Error, ex.GetMessages(), False)

        Return CreateError(Of RemoteDepositResponse)(ex)
    End Function

    Private Shared Function CreateRDCError(ByVal transactionId As Long, ByVal err As RDCError) As RemoteDepositResponse
        RDCLog.Log(transactionId, RDCAction.remoteDeposit, TraceEventType.Error, err.logMessage, False)

        Return CreateError(Of RemoteDepositResponse)(err.err)
    End Function

    Private Shared Function CreateError(Of T As New)(ByVal ex As Exception) As T
        log.TraceError(ex.GetStackTraces())

        Return CreateError(Of T)(New Error_Type(Nothing, ex.Source, ex.GetMessages()))
    End Function

    Private Shared Function CreateError(Of T As New)(ByVal err As Error_Type) As T
        CreateError = New T

        Dim responseProp As PropertyInfo = CreateError.GetType.GetProperties()(0) 'Every response object should only have 1 property of Response_Type
        Dim responsePropInstance As Response_Type = CType(responseProp.PropertyType.GetConstructor({}).Invoke(Nothing), Response_Type)

        responseProp.SetValue(CreateError, responsePropInstance, Nothing)

        responsePropInstance.err = err
        responsePropInstance.status = StatusType_Enum.FAIL

        Return CreateError
    End Function

    Private Shared Sub AddAlogentRequestToExceptionData(ByVal ex As Exception, ByVal request As Deposit_Submit_Request)
        Dim data As Collections.IDictionary = ex.Data

        With request.SingleItemDeposit
            data.Add("request.SingleItem.DepositDepositorId", .DepositorId)
            data.Add("request.SingleItem.MasterUserId", .MasterUserId)
            data.Add("request.SingleItem.SourceDevice.Id", .SourceDevice.Id)

            With .DepositAccount
                data.Add("request.SingleItem.DepositAccount.AccountNumber", .AccountNumber)
                data.Add("request.SingleItem.DepositAccount.TransactionCode", .TransactionCode)
            End With

            With .Cheque
                data.Add("request.SingleItem.Cheque.Amount", .Amount)
                data.Add("request.SingleItem.Cheque.ImageFront.Image", ImageAsString(.ImageFront.Image))
                data.Add("request.SingleItem.Cheque.ImageRear.Image", ImageAsString(.ImageRear.Image))
            End With
        End With
    End Sub

    Private Shared Function ImageAsString(ByVal image() As Byte) As String
        Return If(image Is Nothing, "Image Is Nothing", image.LongLength & " bytes")
    End Function

    Private Shared Function HasSpecialCharacter(ByVal value As String) As Boolean
        For Each letter In value
            If AscW(letter) > 255 Then
                Return True
            End If
        Next

        Return False
    End Function
End Class
