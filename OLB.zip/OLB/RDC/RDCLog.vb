﻿Imports Arvest.Common

Imports System.Data.OleDb
Imports System.Net
Imports System.Configuration
Imports System.Diagnostics
Imports System.Threading.Tasks
Imports System.Collections.Generic
Imports Arvest.WCF.OLB.ClairMailCore.MBankingInterface

Namespace RDC
    Class RDCLog
        Private Shared traceLog As New ArvestTraceSource(GetType(ClairMailService))

        Private Shared connectionString As ConnectionStringSettings = ConfigurationManager.ConnectionStrings("WCFLOGDB")
        Private Shared arvGo As Integer
        Private Shared Monitise As Integer

        Shared Function CreateTransaction(ByVal userId As String, ByVal account As Long?, ByVal accountType As AccountType, ByVal amount As Decimal?, ByVal duId As String, channelId As ChannelType_Enum) As Long
            Dim transactionId As Long
            GetChannelId(channelId)


            Try
                transactionId = CLng(ArvestSqlCommand.ExecuteScalar(Of Decimal)(connectionString,
                                                                                "INSERT INTO MOB_RDC_TRAN (USER_ID, ACCT, ACCT_TYP, AMT, DUID, Monitise, ArvGo)" &
                                                                                "VALUES (?, ?, ?, ?, ?, ?, ?); " &
                                                                                "SELECT @@IDENTITY",
                                                                                {userId, account, accountType.ToString, amount, duId, Monitise, arvGo}))
            Catch ex As Exception
                traceLog.TraceError(ex.GetStackTraces)

                transactionId = CLng(Util.CreateRandom().NextDouble * 999999999999999)

                traceLog.TraceInformation("{0}, '{1}', {2}, {3}, {4}", transactionId, userId, account, accountType.ToString, amount)
            End Try

            Return transactionId
        End Function

        Shared Sub Log(ByVal transactionId As Long, ByVal action As RDCAction, ByVal eventType As TraceEventType, ByVal message As String, Optional ByVal isAccepted As Boolean? = Nothing)
            Task.Factory.StartNew(Sub()
                                      Try
                                          Dim sql As String = "INSERT INTO MOB_RDC_LOG (HOST_N, MOB_RDC_ACT_I, MOB_RDC_TRAN_I, MOB_RDC_EVNT_I, MSG) " &
                                                              "SELECT ?, MOB_RDC_ACT.MOB_RDC_ACT_I, ?, MOB_RDC_EVNT.MOB_RDC_EVNT_I, ? " &
                                                              "FROM MOB_RDC_ACT, MOB_RDC_EVNT " &
                                                              "WHERE MOB_RDC_ACT.ACTION = ?" &
                                                              " AND MOB_RDC_EVNT.EVENT_TYP = ?;"

                                          Dim parameters As New List(Of Object)({Dns.GetHostName(), transactionId, message, action.ToString, eventType.ToString})

                                          Dim expectedRowsAffected As Integer

                                          If isAccepted IsNot Nothing Then
                                              sql &= "UPDATE MOB_RDC_TRAN " &
                                                     "SET ACCEPTED = ? " &
                                                     "WHERE MOB_RDC_TRAN_I = ?;"

                                              parameters.Add(isAccepted)
                                              parameters.Add(transactionId)

                                              expectedRowsAffected = 2
                                          Else
                                              expectedRowsAffected = 1
                                          End If

                                          ArvestSqlCommand.ExecuteNonQuery(connectionString, sql, parameters, expectedRowsAffected:=expectedRowsAffected)
                                      Catch ex As Exception
                                          traceLog.TraceError(ex.GetStackTraces)

                                          'Ignore errors that occur.  Don't stop the application from running. Log message to standard logging
                                          traceLog.TraceInformation("{0}, {1}, {2}, {3}", transactionId, action.ToString, eventType.ToString, message)
                                      End Try
                                  End Sub)
        End Sub
        Shared Sub GetChannelId(channelId As ChannelType_Enum)
            'MCD Reporting/Logging CO: 
            Select Case channelId
                Case ChannelType_Enum.MWEB
                    arvGo = 1
                    Monitise = 0
                Case ChannelType_Enum.MCLIENT
                    arvGo = 0
                    Monitise = 1
                Case Else
                    arvGo = 0
                    Monitise = 0
            End Select
        End Sub
    End Class
End Namespace

