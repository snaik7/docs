﻿
Namespace RDC
    Enum RDCAction
        remoteDeposit

        isDuplicateDeposit

        memoPostDeposit
    End Enum
End Namespace

