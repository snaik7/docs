﻿Imports Arvest.WCF.OLB.ClairMailCore.MBankingInterface
Imports Arvest.Common

Namespace RDC
    Class RDCError
        Property err As Error_Type

        Property logMessage As String

        Sub New()

        End Sub

        Sub New(ByVal errorCode As String, ByVal errorSource As String, ByVal errorMessage As String, ByVal logMessage As String)
            err = New Error_Type With {.errorCode = errorCode,
                                       .errorSource = errorSource,
                                       .errorMessage = errorMessage}
            Me.logMessage = logMessage
        End Sub

        Shared ReadOnly Property INVALID_FRONT_IMAGE As RDCError
            Get
                Return New RDCError("R1000", "WCF", "required.checkdeposit.checkfront.image", "Front image is nothing.")
            End Get
        End Property

        Shared ReadOnly Property INVALID_BACK_IMAGE As RDCError
            Get
                Return New RDCError("R1002", "WCF", "required.checkdeposit.checkback.image", "Back image is nothing.")
            End Get
        End Property

        Shared ReadOnly Property INVALID_ACCOUNT As RDCError
            Get
                Return New RDCError("R1004", "WCF", "required.checkdeposit.to.account", "Account number is nothing.")
            End Get
        End Property

        Shared ReadOnly Property INVALID_AMOUNT As RDCError
            Get
                Return New RDCError("R1006", "WCF", "required.amount", "Amount is nothing.")
            End Get
        End Property

        Shared ReadOnly Property RECAPTURE_FRONT(ByVal logMessage As String) As RDCError
            Get
                Return New RDCError("R2000", "Alogent", "label.check.recapture.front.image", logMessage)
            End Get
        End Property

        Shared ReadOnly Property RECAPTURE_BACK(ByVal logMessage As String) As RDCError
            Get
                Return New RDCError("R2002", "Alogent", "label.check.recapture.back.image", logMessage)
            End Get
        End Property

        Shared ReadOnly Property RESUBMIT_AMOUNT(ByVal logMessage As String) As RDCError
            Get
                Return New RDCError("R2004", "Alogent", "label.check.resubmit.amount", logMessage)
            End Get
        End Property

        Shared ReadOnly Property DUPLICATE(ByVal logMessage As String) As RDCError
            Get
                Return New RDCError("R2006", "Alogent", "process.duplicate.check", logMessage)
            End Get
        End Property

        Shared ReadOnly Property FOREIGN(ByVal logMessage As String) As RDCError
            Get
                Return New RDCError("R2008", "Alogent", "process.foreign.check", logMessage)
            End Get
        End Property

        Shared ReadOnly Property DAILY_VELOCITY(ByVal logMessage As String) As RDCError
            Get
                Return New RDCError("R2022", "Host", "process.daily.amount.threshold.exceeded", logMessage)
            End Get
        End Property

        Shared ReadOnly Property MONTHLY_VELOCITY(ByVal logMessage As String) As RDCError
            Get
                Return New RDCError("R2024", "Host", "process.monthly.amount.threshold.exceeded", logMessage)
            End Get
        End Property

        Shared ReadOnly Property TIMEOUT(ByVal errorSource As String, ByVal logMessage As String) As RDCError
            Get
                Return New RDCError("R3000", errorSource, "communication.checkdeposit.timeout", logMessage)
            End Get
        End Property

        Shared ReadOnly Property COM_ERROR(ByVal logMessage As String) As RDCError
            Get
                Return New RDCError("R3002", "Alogent", "communication.checkdeposit.connectionfailed", logMessage)
            End Get
        End Property

        Shared ReadOnly Property DEPOSIT_FAILED As RDCError
            Get
                Return New RDCError(Nothing, "Alogent", "Deposit Failed", "Deposit Failed.")
            End Get
        End Property

        Shared ReadOnly Property DEPOSIT_PENDING As RDCError
            Get
                Return New RDCError(Nothing, "Alogent", "Deposit Pending", "Deposit Pending Review.")
            End Get
        End Property

        Shared ReadOnly Property HOST_ERROR(ByVal errorCode As String, ByVal message As String) As RDCError
            Get
                Return New RDCError(errorCode, "Host", message, message)
            End Get
        End Property
    End Class
End Namespace