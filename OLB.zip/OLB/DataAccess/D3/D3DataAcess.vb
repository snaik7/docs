﻿Imports System.Collections.Generic
Imports System.Configuration
Imports System.Data

Imports Arvest.Common

Imports Arvest.WCF.OLB.DataAcess.D3.DataAcessObjects

Namespace DataAcess.D3
    Class D3DataAcess

        Private Shared d3ConnectionString As ConnectionStringSettings = ConfigurationManager.ConnectionStrings("D3DB")

        Shared Function FindMapId(Of T)(ByVal axmId As String, read As Func(Of IDataReader, T)) As T
            Using command As New ArvestSqlCommand(d3ConnectionString)
                Using reader As IDataReader = command.ExecuteReader("EXEC dbo.ARV_FINDMAPID ?", {axmId})
                    Return read(reader)
                End Using
            End Using
        End Function

        Shared Function GetSubscriberId(ByVal axmId As String) As String
            Return FindMapId(axmId,
                             Function(reader As IDataReader) As String
                                 If reader.Read Then
                                     reader.GetString(5)
                                 End If

                                 Return Nothing
                             End Function)
        End Function

        Shared Function GetD3User(ByVal axmId As String) As D3User
            Return FindMapId(axmId,
                            Function(reader As IDataReader) As D3User
                                Dim subscriberId As String = Nothing
                                Dim accounts As New Dictionary(Of String, Account)

                                While reader.Read
                                    If String.IsNullOrEmpty(subscriberId) Then
                                        subscriberId = reader.GetString(5)
                                    End If

                                    accounts.Add(reader.GetString(3),
                                                 New Account With
                                                 {
                                                     .Nickname = reader.GetString(1, String.Empty),
                                                     .IsVisible = reader.GetInt32(2) = 1,
                                                     .Account = reader.GetString(6)
                                                 })
                                End While

                                Return New D3User With
                                       {
                                           .SubscriberId = If(subscriberId = String.Empty, Nothing, subscriberId),
                                           .Accounts = accounts
                                       }
                            End Function)
        End Function
    End Class
End Namespace
