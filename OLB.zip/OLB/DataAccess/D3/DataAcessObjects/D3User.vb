﻿Imports System.Collections.Generic

Namespace DataAcess.D3.DataAcessObjects
    Class D3User
        Property SubscriberId As String

        Property Accounts As New Dictionary(Of String, Account)
    End Class
End Namespace
