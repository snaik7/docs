﻿Namespace DataAcess.D3.DataAcessObjects
    Class Account
        Property Nickname As String

        Property IsVisible As Boolean

        Property Account As String
    End Class
End Namespace

