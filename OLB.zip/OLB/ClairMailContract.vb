﻿Imports System.ServiceModel
Imports Arvest.WCF.OLB.ClairMailCore
Imports Arvest.WCF.OLB.ClairMailCore.Request
Imports Arvest.WCF.OLB.ClairMailCore.Response
Imports Arvest.Common
Imports Arvest.Common.WCF

<ServiceContract(Namespace:="http://arvest.com/")>
Public Interface ClairMailContract
    Inherits IWCFContract

    <OperationContract()>
    Function authenticateUserRSA(ByVal request As AuthenticateUserRSARequest) As AuthenticateUserRSAResponse

    <OperationContract()>
    Function authenticateUser(ByVal request As AuthenticateUserRequest) As AuthenticateUserResponse

    <OperationContract()>
    Function getBalance(ByVal request As GetBalanceRequest) As GetBalanceResponse

    <OperationContract()>
    Function getRecentTransfers(ByVal request As GetRecentTransfersRequest) As GetRecentTransfersResponse

    <OperationContract()>
    Function getScheduledTransfers(ByVal request As GetScheduledTransfersRequest) As GetScheduledTransfersResponse

    <OperationContract()>
    Function getTransactionHistory(ByVal request As GetTransactionHistoryRequest) As GetTransactionHistoryResponse

    <OperationContract()>
    Function getUser(ByVal request As GetUserRequest) As GetUserResponse

    <OperationContract()>
    Function getUserProfile(ByVal request As GetUserProfileRequest) As GetUserProfileResponse

    <OperationContract()>
    Function transfer(ByVal request As TransferRequest) As TransferResponse

    <OperationContract()>
    Function remoteDeposit(ByVal request As RemoteDepositRequest) As RemoteDepositResponse

    <OperationContract()>
    Function isDuplicateDeposit(ByVal request As DuplicateDepositRequest) As Boolean

    <OperationContract()>
    Sub memoPostDeposit(ByVal request As MemoPostDepositRequest)

    <OperationContract()>
    Function PendingItems(ByVal _request As CB_GetMemoPostTransactionsRequest) As CB_GetMemoPostTransactionsResponse
End Interface
