﻿Imports System.Runtime.Serialization
Imports Arvest.Common

<DataContract()>
Public Class DuplicateDepositRequest
    <DataMember()>
    <XmlSerializeOptions(tagName:="transactionId")>
    Property masterUserId As String

    <DataMember()>
    Property outOfAccount As String

    <DataMember()>
    Property routingNumber As String

    <DataMember()>
    Property checkNumber As String

    <DataMember()>
    Property depositAmount As Decimal

    <DataMember()>
    <XmlSerializeOptions(omit:=True)>
    Property isn As Long
End Class
