﻿Imports System.Runtime.Serialization
Imports Arvest.Common

<DataContract()>
Public Class MemoPostDepositRequest
    <DataMember()>
    <XmlSerializeOptions(tagName:="transactionId")>
    Property masterUserId As String

    <DataMember()>
    Property intoAccount As Long

    <DataMember()>
    Property intoAcctType As AccountType

    <DataMember()>
    Property depositAmount As Decimal

    <DataMember()>
    <XmlSerializeOptions(omit:=True)>
    Property isn As Long
End Class
