﻿Imports System.Runtime.Serialization

<DataContract()>
Public Enum AccountType
    <EnumMember()>
    DDA

    <EnumMember()>
    SAV
End Enum
