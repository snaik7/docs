﻿Imports System.Configuration
Imports System.Runtime.Serialization
Imports System.ServiceModel

<MessageContract()> _
Public Class CB_GetMemoPostTransactionsRequest

    '<MessageBodyMember()> _
    'Property RqUID As String = String.Empty

    <MessageBodyMember()> _
    Property AcctId As String = String.Empty

    <MessageBodyMember()> _
    Property AcctType As CorAcctType

    '<MessageBodyMember()> _
    'Property ProdSubType As String = String.Empty

    '<MessageBodyMember()> _
    'Property BankId As String = String.Empty

    '<MessageBodyMember()> _
    'Property StartDt As String = String.Empty

    '<MessageBodyMember()> _
    'Property EndDt As String = String.Empty

    '<MessageBodyMember()> _
    'Property LowCurAmt As String = String.Empty

    '<MessageBodyMember()> _
    'Property HighCurAmt As String = String.Empty

    '<MessageBodyMember()> _
    'Property ChkNumStart As String = String.Empty

    '<MessageBodyMember()> _
    'Property chkNumEnd As String = String.Empty

    '<MessageBodyMember()> _
    'Property IncMemoPostCode As String = String.Empty


End Class
