﻿Imports System.Collections.Generic
Imports System.ServiceModel

<MessageContract()>
Public Class CB_GetMemoPostTransactionsResponse
    Inherits ErrorResponse

    <MessageBodyMember()>
    Property AcctBasic As List(Of CB_GetMemoPostTransactionResponseList)
End Class
