﻿Imports System.ServiceModel
Imports System.Runtime.Serialization

<MessageContract()>
Public Enum CorAcctType
    <EnumMember()>
    DDA

    <EnumMember()>
    SAV

    <EnumMember()>
    CDS

    <EnumMember()>
    IRA

    <EnumMember()>
    LON

    <EnumMember()>
    CCR

    <EnumMember()>
    CDR

    <EnumMember()>
    AMS

    <EnumMember()>
    EFA

    <EnumMember()>
    EFL
End Enum