﻿Imports System.ServiceModel
Imports Arvest.Common

<MessageContract()>
Public Class CB_GetMemoPostTransactionResponseList
    <MessageBodyMember()>
    <XmlSerializeOptions(TagName:="Amount")>
    Property Amt As String = String.Empty

    <MessageBodyMember()>
    <XmlSerializeOptions(TagName:="TranDate", DateTimeFormat:="MM/dd/yy")>
    Property TranDt As DateTime

    <MessageBodyMember()>
    <XmlSerializeOptions(TagName:="DrCr")>
    Property TrnCode As String

    <MessageBodyMember()>
    <XmlSerializeOptions(TagName:="Desc")>
    Property TranDesc As String = String.Empty

    <MessageBodyMember()>
    <XmlSerializeOptions(TagName:="AvailBal")>
    Property AvailBal As Decimal
End Class
