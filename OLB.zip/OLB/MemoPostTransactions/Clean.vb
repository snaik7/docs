﻿Imports System.Text
Imports System.Globalization

Public Class Clean
    Public Shared Function CleanData(ByVal value As String) As String
        Dim builder As New StringBuilder(value)

        builder.Replace("'", "''")
        builder.Replace(ControlChars.Quote, "")
        builder.Replace(";", "")
        builder.Replace("<", "")
        builder.Replace(">", "")
        builder.Replace("\", "")

        Return builder.ToString.Trim
    End Function

    Public Shared Function Format400Date(ByVal inDate As String) As DateTime
        Dim val As String = inDate

        val = val.Replace("/", "")

        Select Case val.Length
            Case 5
                val = "0" & val
            Case 7
                val = "0" & val
                val = val.Substring(0, 4) & val.Substring(6, 2)
            Case 8
                val = val.Substring(0, 4) & val.Substring(6, 2)
        End Select

        val = val.Substring(0, 2) & "/" & val.Substring(2, 2) & "/" & val.Substring(4, 2)

        Return DateTime.ParseExact(val, "MM/dd/yy", CultureInfo.CurrentCulture, DateTimeStyles.None)
    End Function

    Public Shared Function Format400DateJulian(ByVal inDate As String) As DateTime
        Return DateTime.ParseExact("01/01/" & inDate.Substring(0, 4),
                                   "MM/dd/yyyy",
                                   CultureInfo.CurrentCulture).AddDays(CDbl(inDate.Substring(4, inDate.Length - 4)))
    End Function

    Public Shared Function FormatXML(ByVal value As String) As String
        Dim builder As New StringBuilder(value)

        builder.Replace("&", "&amp;")
        builder.Replace("<", "&lt;")
        builder.Replace(">", "&gt;")
        builder.Replace(ControlChars.Quote, "&quot;")
        builder.Replace("'", "&apos;")

        'remove control characters
        For i = 0 To 8
            builder.Replace(Chr(i), "")
        Next

        builder.Replace(Chr(11), "")
        builder.Replace(Chr(12), "")

        For i = 14 To 31
            builder.Replace(Chr(i), "")
        Next

        builder.Replace(Chr(127), "")

        Return builder.ToString.Trim
    End Function
End Class
