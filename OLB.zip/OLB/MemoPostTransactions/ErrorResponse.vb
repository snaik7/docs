﻿Imports System.ServiceModel

<MessageContract()>
Public Class ErrorResponse
    <MessageBodyMember()>
    Property Severity As String = String.Empty

    <MessageBodyMember()>
    Property ErrNum As String = String.Empty

    <MessageBodyMember()>
    Property ErrDesc As String = String.Empty

    <MessageBodyMember()>
    Property Source As String = String.Empty
End Class
