﻿Imports Arvest.Common

Namespace HostContracts
    Class RDCHostResponse
        <XmlSerializeOptions(StringFormat:="TRUE!FALSE")>
        Public Property accept As Boolean

        Public Property code As Integer

        Public Property message As String
    End Class
End Namespace